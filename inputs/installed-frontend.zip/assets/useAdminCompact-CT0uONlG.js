import{u as t}from"./useMediaQuery-DUqTryDR.js";const u="(max-width: 767px)";function o(){return t(u)}export{o as u};
