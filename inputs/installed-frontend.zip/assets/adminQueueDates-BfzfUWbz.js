import{e as n}from"./adminPresentation-DbnESiBS.js";function r(a,e){return{...a?{from:n(a)??a}:{},...e?{to:n(e,!0)??e}:{}}}export{r as a};
