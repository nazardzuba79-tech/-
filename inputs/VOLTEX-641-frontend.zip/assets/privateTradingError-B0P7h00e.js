import{c as s}from"./index-C3McTRZr.js";/**
 * @license lucide-react v1.34.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const i=[["path",{d:"M15 3h6v6",key:"1q9fwt"}],["path",{d:"M10 14 21 3",key:"gplh6r"}],["path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6",key:"a6xqqp"}]],c=s("external-link",i);class d extends Error{constructor(r,t,a,e){super(r),this.status=t,this.code=a,this.detail=e,this.name="PrivateTradingError"}}export{c as E,d as P};
