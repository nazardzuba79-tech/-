import{u as t}from"./useMediaQuery-D_hVVf0V.js";const u="(max-width: 767px)";function o(){return t(u)}export{o as u};
