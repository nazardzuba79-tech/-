var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// src/index.js
var JSON_HEADERS = {
  "content-type": "application/json; charset=utf-8",
  "access-control-allow-origin": "*",
  "access-control-allow-methods": "GET, HEAD, OPTIONS",
  "access-control-allow-headers": "content-type"
};
var EDGE_TTL_SECONDS = 15;
var SLOW_EDGE_TTL_SECONDS = 6 * 60 * 60;
var BOOK_LEVELS = 25;
var SYMBOL_RE = /^[A-Z0-9]{1,28}USDT$/;
var OKX_BAR = {
  "1": "1m",
  "3": "3m",
  "5": "5m",
  "15": "15m",
  "30": "30m",
  "60": "1H",
  "120": "2H",
  "240": "4H",
  "360": "6H",
  "720": "12H",
  "D": "1D",
  "W": "1W",
  "M": "1M"
};
var SPOT_INTERVAL_MINUTES = { "1m": "1", "5m": "5", "15m": "15", "1h": "60", "4h": "240", "1d": "1440", "1w": "10080" };
var KRAKEN_ASSET = { BTC: "XBT", DOGE: "XDG" };
var SPOT_SLUG_RE = /^[A-Z0-9]{1,32}-[A-Z0-9]{2,12}$/;
var CFD_SYMBOLS = { XAUUSD: "XAUUSD", XAGUSD: "XAGUSD", XPTUSD: "XPTUSD", XPDUSD: "XPDUSD", WTIUSD: "USOIL", XBRUSD: "UKOIL", EURUSD: "EURUSD", GBPUSD: "GBPUSD", USDJPY: "USDJPY", AUDUSD: "AUDUSD", USDCAD: "USDCAD", USDCHF: "USDCHF", NZDUSD: "NZDUSD" };
var CFD_NAMES = {
  XAUUSD: "Gold Spot",
  XAGUSD: "Silver Spot",
  XPTUSD: "Platinum Spot",
  XPDUSD: "Palladium Spot",
  WTIUSD: "Crude Oil WTI Spot",
  XBRUSD: "Brent Spot",
  EURUSD: "Euro vs US Dollar",
  GBPUSD: "British Pound vs US Dollar",
  USDJPY: "US Dollar vs Japanese Yen",
  AUDUSD: "Australian Dollar vs US Dollar",
  USDCAD: "US Dollar vs Canadian Dollar",
  USDCHF: "US Dollar vs Swiss Franc",
  NZDUSD: "New Zealand Dollar vs US Dollar"
};
var DERIV_PUBLIC_WS_URL = "wss://api.derivws.com/trading/v1/options/ws/public";
var DERIV_CFD_IDS = {
  EURUSD: "frxEURUSD",
  GBPUSD: "frxGBPUSD",
  USDJPY: "frxUSDJPY",
  AUDUSD: "frxAUDUSD",
  USDCAD: "frxUSDCAD",
  USDCHF: "frxUSDCHF",
  NZDUSD: "frxNZDUSD",
  XAUUSD: "frxXAUUSD",
  XAGUSD: "frxXAGUSD",
  XPTUSD: "frxXPTUSD",
  XPDUSD: "frxXPDUSD"
};
var EIA_OIL = {
  WTIUSD: { providerSymbol: "RWTC", title: "Cushing, OK WTI Spot Price FOB", file: "RWTCD.htm" },
  XBRUSD: { providerSymbol: "RBRTE", title: "Europe Brent Spot Price FOB", file: "RBRTED.htm" }
};
var FRANKFURTER_FX = {
  EURUSD: { quote: "EUR", invert: true },
  GBPUSD: { quote: "GBP", invert: true },
  USDJPY: { quote: "JPY", invert: false },
  AUDUSD: { quote: "AUD", invert: true },
  USDCAD: { quote: "CAD", invert: false },
  USDCHF: { quote: "CHF", invert: false },
  NZDUSD: { quote: "NZD", invert: true }
};
var CFD_INTERVALS = /* @__PURE__ */ new Set(["1m", "5m", "15m", "30m", "1h", "4h", "1d"]);
function json(body, status = 200, extra = {}) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      ...JSON_HEADERS,
      "cache-control": status === 200 ? `public, max-age=${EDGE_TTL_SECONDS}, s-maxage=${EDGE_TTL_SECONDS}, stale-while-revalidate=30` : "no-store",
      ...extra
    }
  });
}
__name(json, "json");
function validPositiveDecimal(value) {
  return typeof value === "string" && value.length <= 64 && /^\d+(?:\.\d+)?$/.test(value) && Number.isFinite(Number(value)) && Number(value) > 0;
}
__name(validPositiveDecimal, "validPositiveDecimal");
function normalizeBookRows(rows) {
  if (!Array.isArray(rows)) throw new Error("book_shape");
  const seen = /* @__PURE__ */ new Set();
  const out = [];
  for (const row of rows) {
    if (!Array.isArray(row) || row.length < 2 || !validPositiveDecimal(row[0]) || !validPositiveDecimal(row[1])) {
      throw new Error("book_level");
    }
    const price = row[0];
    if (seen.has(price)) throw new Error("book_duplicate");
    seen.add(price);
    out.push({ price, quantity: row[1] });
    if (out.length >= BOOK_LEVELS) break;
  }
  return out;
}
__name(normalizeBookRows, "normalizeBookRows");
async function publicJson(url) {
  const response = await fetch(url, {
    method: "GET",
    headers: { accept: "application/json" },
    redirect: "follow"
  });
  if (!response.ok) throw new Error(`provider_http_${response.status}`);
  return response.json();
}
__name(publicJson, "publicJson");
async function publicText(url) {
  const response = await fetch(url, {
    method: "GET",
    headers: { accept: "text/html" },
    redirect: "follow"
  });
  if (!response.ok) throw new Error(`provider_http_${response.status}`);
  const body = await response.text();
  if (body.length > 2e6) throw new Error("provider_body_too_large");
  return body;
}
__name(publicText, "publicText");
async function firstPublicJson(urls) {
  let lastError;
  for (const url of urls) {
    try {
      return await publicJson(url);
    } catch (error) {
      lastError = error;
    }
  }
  throw lastError ?? new Error("provider_unavailable");
}
__name(firstPublicJson, "firstPublicJson");
function urlWith(host, path, params) {
  const url = new URL(path, host);
  for (const [key, value] of Object.entries(params)) url.searchParams.set(key, String(value));
  return url.toString();
}
__name(urlWith, "urlWith");
function bybitUrl(path, params) {
  return [
    urlWith("https://api.bybit.com", path, params),
    urlWith("https://api.bytick.com", path, params)
  ];
}
__name(bybitUrl, "bybitUrl");
function okxInstId(symbol) {
  if (!SYMBOL_RE.test(symbol)) throw new Error("symbol_invalid");
  return `${symbol.slice(0, -4)}-USDT-SWAP`;
}
__name(okxInstId, "okxInstId");
function symbolFromOkx(instId) {
  const match = /^([A-Z0-9]{1,28})-USDT-SWAP$/.exec(instId || "");
  return match ? `${match[1]}USDT` : null;
}
__name(symbolFromOkx, "symbolFromOkx");
async function bybitBook(symbol) {
  const body = await firstPublicJson(bybitUrl("/v5/market/orderbook", { category: "linear", symbol, limit: "50" }));
  if (body?.retCode !== 0 || body?.result?.s !== symbol) throw new Error("bybit_book_identity");
  const bids = normalizeBookRows(body.result.b), asks = normalizeBookRows(body.result.a);
  if (!bids.length || !asks.length || Number(bids[0].price) >= Number(asks[0].price)) throw new Error("bybit_book");
  const updateId = Number(body.result.u), providerTime = Number(body.time);
  if (!Number.isSafeInteger(updateId) || updateId < 1) throw new Error("bybit_book_update");
  return {
    available: true,
    symbol,
    source: "bybit",
    fetchedAt: Date.now(),
    providerTime: Number.isFinite(providerTime) && providerTime > 0 ? providerTime : Date.now(),
    stale: false,
    updateId,
    bids,
    asks
  };
}
__name(bybitBook, "bybitBook");
async function okxBook(symbol) {
  const body = await publicJson(urlWith("https://www.okx.com", "/api/v5/market/books", { instId: okxInstId(symbol), sz: "25" }));
  const row = body?.code === "0" && Array.isArray(body.data) ? body.data[0] : null;
  if (!row) throw new Error("okx_book_shape");
  const bids = normalizeBookRows(row.bids), asks = normalizeBookRows(row.asks);
  if (!bids.length || !asks.length || Number(bids[0].price) >= Number(asks[0].price)) throw new Error("okx_book");
  const providerTime = Number(row.ts);
  if (!Number.isSafeInteger(providerTime) || providerTime <= 0) throw new Error("okx_book_time");
  return {
    available: true,
    symbol,
    source: "okx",
    fetchedAt: Date.now(),
    providerTime,
    stale: false,
    updateId: providerTime,
    bids,
    asks
  };
}
__name(okxBook, "okxBook");
async function futuresBook(symbol) {
  try {
    return await bybitBook(symbol);
  } catch {
    return okxBook(symbol);
  }
}
__name(futuresBook, "futuresBook");
async function bybitTrades(symbol) {
  const body = await firstPublicJson(bybitUrl("/v5/market/recent-trade", { category: "linear", symbol, limit: "30" }));
  if (body?.retCode !== 0 || body?.result?.category !== "linear" || !Array.isArray(body?.result?.list)) throw new Error("bybit_trade_shape");
  const seen = /* @__PURE__ */ new Set();
  const trades = body.result.list.map((row) => {
    if (row?.symbol !== symbol || !["Buy", "Sell"].includes(row.side) || typeof row.execId !== "string" || !row.execId || seen.has(row.execId) || !validPositiveDecimal(row.price) || !validPositiveDecimal(row.size) || !Number.isSafeInteger(Number(row.time)) || Number(row.time) <= 0) throw new Error("bybit_trade_identity");
    seen.add(row.execId);
    return { id: row.execId, price: row.price, quantity: row.size, time: Number(row.time), side: row.side === "Buy" ? "BUY" : "SELL" };
  }).slice(0, 30).sort((a, b) => b.time - a.time);
  return { symbol, source: "bybit", trades };
}
__name(bybitTrades, "bybitTrades");
async function okxTrades(symbol) {
  const body = await publicJson(urlWith("https://www.okx.com", "/api/v5/market/trades", { instId: okxInstId(symbol), limit: "30" }));
  if (body?.code !== "0" || !Array.isArray(body.data)) throw new Error("okx_trade_shape");
  const seen = /* @__PURE__ */ new Set();
  const trades = body.data.map((row) => {
    if (!row || row.instId !== okxInstId(symbol) || typeof row.tradeId !== "string" || !row.tradeId || seen.has(row.tradeId) || !validPositiveDecimal(row.px) || !validPositiveDecimal(row.sz) || !["buy", "sell"].includes(row.side) || !Number.isSafeInteger(Number(row.ts)) || Number(row.ts) <= 0) throw new Error("okx_trade_identity");
    seen.add(row.tradeId);
    return { id: `okx:${row.tradeId}`, price: row.px, quantity: row.sz, time: Number(row.ts), side: row.side === "buy" ? "BUY" : "SELL" };
  }).slice(0, 30).sort((a, b) => b.time - a.time);
  return { symbol, source: "okx", trades };
}
__name(okxTrades, "okxTrades");
async function futuresTrades(symbol) {
  try {
    return await bybitTrades(symbol);
  } catch {
    return okxTrades(symbol);
  }
}
__name(futuresTrades, "futuresTrades");
async function bybitTickers() {
  const body = await firstPublicJson(bybitUrl("/v5/market/tickers", { category: "linear" }));
  if (body?.retCode !== 0 || body?.result?.category !== "linear" || !Array.isArray(body?.result?.list)) throw new Error("bybit_ticker_shape");
  return { ...body, source: "bybit" };
}
__name(bybitTickers, "bybitTickers");
async function okxTickers() {
  const body = await publicJson(urlWith("https://www.okx.com", "/api/v5/market/tickers", { instType: "SWAP" }));
  if (body?.code !== "0" || !Array.isArray(body.data)) throw new Error("okx_ticker_shape");
  const list = [];
  let newest = 0;
  for (const row of body.data) {
    const symbol = symbolFromOkx(row?.instId);
    if (!symbol || !validPositiveDecimal(row.last)) continue;
    const last = Number(row.last), open = Number(row.open24h);
    const change = Number.isFinite(open) && open > 0 ? last / open - 1 : null;
    const ts = Number(row.ts);
    if (Number.isFinite(ts)) newest = Math.max(newest, ts);
    list.push({
      symbol,
      lastPrice: row.last,
      bid1Price: validPositiveDecimal(row.bidPx) ? row.bidPx : null,
      ask1Price: validPositiveDecimal(row.askPx) ? row.askPx : null,
      highPrice24h: validPositiveDecimal(row.high24h) ? row.high24h : null,
      lowPrice24h: validPositiveDecimal(row.low24h) ? row.low24h : null,
      price24hPcnt: change === null ? null : String(change),
      volume24h: null,
      turnover24h: null,
      indexPrice: null,
      markPrice: null,
      fundingRate: null,
      openInterest: null,
      openInterestValue: null
    });
  }
  if (!list.length) throw new Error("okx_ticker_empty");
  return { retCode: 0, time: newest || Date.now(), source: "okx", result: { category: "linear", list } };
}
__name(okxTickers, "okxTickers");
async function futuresTickers() {
  try {
    return await bybitTickers();
  } catch {
    return okxTickers();
  }
}
__name(futuresTickers, "futuresTickers");
var KLINE_INTERVALS = /* @__PURE__ */ new Set(["1", "3", "5", "15", "30", "60", "120", "240", "360", "720", "D", "W", "M"]);
async function bybitCandles(symbol, interval, limitRaw, endRaw) {
  const params = { category: "linear", symbol, interval, limit: String(limitRaw) };
  if (endRaw !== null) params.end = endRaw;
  const body = await firstPublicJson(bybitUrl("/v5/market/kline", params));
  if (body?.retCode !== 0 || body?.result?.category !== "linear" || body?.result?.symbol !== symbol || !Array.isArray(body?.result?.list)) {
    throw new Error("bybit_candle_shape");
  }
  return { ...body, source: "bybit" };
}
__name(bybitCandles, "bybitCandles");
async function okxCandles(symbol, interval, limitRaw, endRaw) {
  const bar = OKX_BAR[interval];
  if (!bar) throw new Error("okx_candle_interval");
  const params = { instId: okxInstId(symbol), bar, limit: String(Math.min(300, limitRaw)) };
  if (endRaw !== null) params.after = endRaw;
  const body = await publicJson(urlWith("https://www.okx.com", "/api/v5/market/candles", params));
  if (body?.code !== "0" || !Array.isArray(body.data)) throw new Error("okx_candle_shape");
  const list = body.data.map((row) => {
    if (!Array.isArray(row) || row.length < 6 || row.slice(0, 6).some((v) => typeof v !== "string" || !/^\d+(?:\.\d+)?$/.test(v))) {
      throw new Error("okx_candle_row");
    }
    return row.slice(0, 6);
  });
  if (!list.length) throw new Error("okx_candle_empty");
  return { retCode: 0, time: Date.now(), source: "okx", result: { category: "linear", symbol, list } };
}
__name(okxCandles, "okxCandles");
async function futuresCandles(symbol, searchParams) {
  const interval = searchParams.get("interval") || "";
  const limitRaw = Number(searchParams.get("limit") || "320");
  const endRaw = searchParams.get("end");
  if (!KLINE_INTERVALS.has(interval) || !Number.isSafeInteger(limitRaw) || limitRaw < 1 || limitRaw > 1e3) throw new RangeError("invalid_candle_query");
  if (endRaw !== null && (!/^\d+$/.test(endRaw) || !Number.isSafeInteger(Number(endRaw)) || Number(endRaw) <= 0)) throw new RangeError("invalid_candle_end");
  try {
    return await bybitCandles(symbol, interval, limitRaw, endRaw);
  } catch {
    return okxCandles(symbol, interval, limitRaw, endRaw);
  }
}
__name(futuresCandles, "futuresCandles");
function decimalOrNull(value) {
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}
__name(decimalOrNull, "decimalOrNull");
function bybitTickerRows(category, body, now = Date.now()) {
  if (body?.retCode !== 0 || body?.result?.category !== category || !Array.isArray(body?.result?.list)) throw new Error("ticker_shape");
  const rows = [];
  const provider = body?.source === "okx" ? "okx" : "bybit";
  for (const raw of body.result.list) {
    if (!raw || typeof raw.symbol !== "string" || !raw.symbol.endsWith("USDT")) continue;
    const base = raw.symbol.slice(0, -4), last = decimalOrNull(raw.lastPrice);
    if (!(last > 0)) continue;
    const change = decimalOrNull(raw.price24hPcnt), linear = category === "linear";
    rows.push({
      id: `${linear ? "linear_perpetual" : "spot"}:${raw.symbol}`,
      pair: `${base}/USDT`,
      symbol: `${base}/USDT`,
      providerSymbol: raw.symbol,
      provider,
      marketType: linear ? "linear_perpetual" : "spot",
      volumeAsset: base,
      turnoverAsset: "USDT",
      baseAsset: base,
      quoteAsset: "USDT",
      settleAsset: linear ? "USDT" : null,
      lastPrice: last,
      bidPrice: decimalOrNull(raw.bid1Price),
      askPrice: decimalOrNull(raw.ask1Price),
      high24h: decimalOrNull(raw.highPrice24h),
      low24h: decimalOrNull(raw.lowPrice24h),
      volume24h: decimalOrNull(raw.volume24h),
      quoteVolume24h: decimalOrNull(raw.turnover24h),
      changePercent24h: change === null ? null : change * 100,
      indexPrice: linear ? decimalOrNull(raw.indexPrice) : null,
      markPrice: linear ? decimalOrNull(raw.markPrice) : null,
      fundingRate: linear ? decimalOrNull(raw.fundingRate) : null,
      fundingIntervalMinutes: null,
      openInterest: linear ? decimalOrNull(raw.openInterest) : null,
      openInterestValue: linear ? decimalOrNull(raw.openInterestValue) : null,
      providerEventAt: decimalOrNull(body.time),
      sequence: null,
      receivedAt: now,
      fetchedAt: now,
      stale: false
    });
  }
  return rows;
}
__name(bybitTickerRows, "bybitTickerRows");
async function okxSpotTickers() {
  const body = await publicJson(urlWith("https://www.okx.com", "/api/v5/market/tickers", { instType: "SPOT" }));
  if (body?.code !== "0" || !Array.isArray(body.data)) throw new Error("okx_spot_ticker_shape");
  const list = [];
  let newest = 0;
  for (const row of body.data) {
    const match = /^([A-Z0-9]{1,28})-USDT$/.exec(row?.instId || "");
    if (!match || !validPositiveDecimal(row.last)) continue;
    const last = Number(row.last), open = Number(row.open24h), ts = Number(row.ts);
    if (Number.isFinite(ts)) newest = Math.max(newest, ts);
    list.push({
      symbol: `${match[1]}USDT`,
      lastPrice: row.last,
      bid1Price: validPositiveDecimal(row.bidPx) ? row.bidPx : null,
      ask1Price: validPositiveDecimal(row.askPx) ? row.askPx : null,
      highPrice24h: validPositiveDecimal(row.high24h) ? row.high24h : null,
      lowPrice24h: validPositiveDecimal(row.low24h) ? row.low24h : null,
      price24hPcnt: Number.isFinite(open) && open > 0 ? String(last / open - 1) : null,
      volume24h: validPositiveDecimal(row.vol24h) ? row.vol24h : null,
      turnover24h: validPositiveDecimal(row.volCcy24h) ? row.volCcy24h : null
    });
  }
  if (!list.length) throw new Error("okx_spot_ticker_empty");
  return { retCode: 0, time: newest || Date.now(), source: "okx", result: { category: "spot", list } };
}
__name(okxSpotTickers, "okxSpotTickers");
async function spotTickerBody() {
  try {
    const body = await firstPublicJson(bybitUrl("/v5/market/tickers", { category: "spot" }));
    if (body?.retCode !== 0 || body?.result?.category !== "spot" || !Array.isArray(body?.result?.list)) throw new Error("bybit_spot_ticker_shape");
    return { ...body, source: "bybit" };
  } catch {
    return okxSpotTickers();
  }
}
__name(spotTickerBody, "spotTickerBody");
async function publicMarketSnapshot() {
  const [spot, linear] = await Promise.all([spotTickerBody(), futuresTickers()]);
  const now = Date.now(), rows = [...bybitTickerRows("spot", spot, now), ...bybitTickerRows("linear", linear, now)];
  if (!rows.length) throw new Error("empty_market_snapshot");
  return { version: 1, type: "snapshot", epoch: "market-edge-v7", revision: Math.floor(now / 1e3), sentAt: now, status: "live", rows, _display: { mode: "snapshot" } };
}
__name(publicMarketSnapshot, "publicMarketSnapshot");
function spotIdentity(slug) {
  if (!SPOT_SLUG_RE.test(slug)) throw new RangeError("invalid_spot_pair");
  const [base, quote] = slug.split("-");
  return { base, quote, pair: `${base}/${quote}`, kraken: `${KRAKEN_ASSET[base] ?? base}${KRAKEN_ASSET[quote] ?? quote}` };
}
__name(spotIdentity, "spotIdentity");
function krakenResultValue(body) {
  if (!body || !Array.isArray(body.error) || body.error.length || !body.result || typeof body.result !== "object") throw new Error("kraken_shape");
  const key = Object.keys(body.result).find((name) => name !== "last");
  if (!key) throw new Error("kraken_empty");
  return body.result[key];
}
__name(krakenResultValue, "krakenResultValue");
async function spotBook(slug) {
  const { pair, kraken } = spotIdentity(slug);
  const query = new URLSearchParams({ pair: kraken, count: String(BOOK_LEVELS) });
  const body = await publicJson(`https://api.kraken.com/0/public/Depth?${query}`);
  const raw = krakenResultValue(body);
  const map = /* @__PURE__ */ __name((rows) => {
    if (!Array.isArray(rows)) throw new Error("kraken_book_shape");
    return rows.slice(0, BOOK_LEVELS).map((row) => {
      if (!Array.isArray(row) || !validPositiveDecimal(row[0]) || !validPositiveDecimal(row[1])) throw new Error("kraken_book_level");
      return { price: row[0], quantity: row[1] };
    });
  }, "map");
  const bids = map(raw.bids).sort((a, b) => Number(b.price) - Number(a.price));
  const asks = map(raw.asks).sort((a, b) => Number(a.price) - Number(b.price));
  if (!bids.length || !asks.length || Number(bids[0].price) >= Number(asks[0].price)) throw new Error("kraken_book_unusable");
  const newest = Math.max(...[...raw.bids ?? [], ...raw.asks ?? []].slice(0, BOOK_LEVELS * 2).map((row) => Number(row?.[2]) * 1e3).filter((value) => Number.isFinite(value) && value > 0), 0);
  return { available: true, pair, bids, asks, timestamp: newest || Date.now(), fetchedAt: Date.now(), stale: false, source: "kraken" };
}
__name(spotBook, "spotBook");
async function spotTrades(slug) {
  const { base, quote, pair } = spotIdentity(slug), symbol = `${base}${quote}`;
  try {
    const body = await firstPublicJson(bybitUrl("/v5/market/recent-trade", { category: "spot", symbol, limit: "30" }));
    if (body?.retCode !== 0 || body?.result?.category !== "spot" || !Array.isArray(body?.result?.list)) throw new Error("spot_trade_shape");
    return { pair, source: "bybit", trades: body.result.list.slice(0, 30).map((row) => ({
      id: row.execId,
      price: row.price,
      quantity: row.size,
      side: row.side === "Buy" ? "BUY" : "SELL",
      time: Number(row.time)
    })).filter((row) => row.id && validPositiveDecimal(row.price) && validPositiveDecimal(row.quantity) && Number.isSafeInteger(row.time) && row.time > 0) };
  } catch {
    const body = await publicJson(urlWith("https://www.okx.com", "/api/v5/market/trades", { instId: `${base}-${quote}`, limit: "30" }));
    if (body?.code !== "0" || !Array.isArray(body.data)) throw new Error("okx_spot_trade_shape");
    return { pair, source: "okx", trades: body.data.map((row) => ({
      id: `okx:${row.tradeId}`,
      price: row.px,
      quantity: row.sz,
      side: row.side === "buy" ? "BUY" : "SELL",
      time: Number(row.ts)
    })).filter((row) => row.id !== "okx:undefined" && validPositiveDecimal(row.price) && validPositiveDecimal(row.quantity) && Number.isSafeInteger(row.time) && row.time > 0).slice(0, 30) };
  }
}
__name(spotTrades, "spotTrades");
async function spotCandles(slug, searchParams) {
  const { base, quote, pair, kraken } = spotIdentity(slug);
  const interval = searchParams.get("interval") || "", krakenInterval = SPOT_INTERVAL_MINUTES[interval];
  const limit = Number(searchParams.get("limit") || "520");
  if (!krakenInterval || !Number.isSafeInteger(limit) || limit < 1 || limit > 720) throw new RangeError("invalid_spot_candle_query");
  try {
    const query = new URLSearchParams({ pair: kraken, interval: krakenInterval });
    const raw = krakenResultValue(await publicJson(`https://api.kraken.com/0/public/OHLC?${query}`));
    if (!Array.isArray(raw)) throw new Error("kraken_candle_shape");
    const candles = raw.map((row) => {
      if (!Array.isArray(row) || row.length < 7) throw new Error("kraken_candle_row");
      const v = [Number(row[0]), Number(row[1]), Number(row[2]), Number(row[3]), Number(row[4]), Number(row[6])];
      if (!v.every(Number.isFinite) || v[0] <= 0 || Math.min(...v.slice(1, 5)) <= 0 || v[2] < Math.max(v[1], v[4]) || v[3] > Math.min(v[1], v[4])) throw new Error("kraken_candle_values");
      return { time: v[0], open: v[1], high: v[2], low: v[3], close: v[4], volume: Math.max(0, v[5]) };
    }).sort((a, b) => a.time - b.time).slice(-limit);
    if (!candles.length) throw new Error("kraken_candle_empty");
    return { source: "kraken", pair, interval, candles };
  } catch {
    const provider = { "1m": "1", "5m": "5", "15m": "15", "1h": "60", "4h": "240", "1d": "D", "1w": "W" }[interval];
    const symbol = `${base}${quote}`;
    const body = await firstPublicJson(bybitUrl("/v5/market/kline", { category: "spot", symbol, interval: provider, limit: String(Math.min(1e3, limit)) }));
    if (body?.retCode !== 0 || body?.result?.category !== "spot" || body?.result?.symbol !== symbol || !Array.isArray(body?.result?.list)) throw new Error("spot_candle_fallback_shape");
    const candles = body.result.list.map((row) => ({ time: Number(row[0]) / 1e3, open: Number(row[1]), high: Number(row[2]), low: Number(row[3]), close: Number(row[4]), volume: Number(row[5]) })).filter((row) => [row.time, row.open, row.high, row.low, row.close, row.volume].every(Number.isFinite) && row.time > 0 && Math.min(row.open, row.high, row.low, row.close) > 0).sort((a, b) => a.time - b.time).slice(-limit);
    if (!candles.length) throw new Error("spot_candle_fallback_empty");
    return { source: "bybit", pair, interval, candles };
  }
}
__name(spotCandles, "spotCandles");
async function spotTickers() {
  const body = await spotTickerBody();
  return { source: `${body.source || "bybit"}-edge`, tickers: bybitTickerRows("spot", body).map((row) => ({
    pair: row.pair,
    lastPrice: String(row.lastPrice),
    bidPrice: row.bidPrice == null ? "" : String(row.bidPrice),
    askPrice: row.askPrice == null ? "" : String(row.askPrice),
    high24h: row.high24h == null ? "" : String(row.high24h),
    low24h: row.low24h == null ? "" : String(row.low24h),
    volume24h: row.volume24h == null ? "" : String(row.volume24h),
    quoteVolume24h: row.quoteVolume24h == null ? "" : String(row.quoteVolume24h),
    changePercent24h: row.changePercent24h == null ? "" : String(row.changePercent24h)
  })) };
}
__name(spotTickers, "spotTickers");
function cfdMissingRow(symbol) {
  return {
    symbol,
    name: CFD_NAMES[symbol] ?? symbol,
    price: null,
    status: "unavailable",
    stale: false,
    marketClosed: false,
    displayOnly: true,
    executionAllowed: false,
    provider: "cloudflare-multisource",
    providerSymbol: CFD_SYMBOLS[symbol] ?? symbol,
    providerTimestamp: null,
    fetchedAt: null,
    asOf: null,
    maxQuoteAgeMs: 12e4
  };
}
__name(cfdMissingRow, "cfdMissingRow");
function cfdPositive(value) {
  const n = Number(value);
  return Number.isFinite(n) && n > 0 ? n : null;
}
__name(cfdPositive, "cfdPositive");
function cfdEpochMs(value) {
  const n = Number(value);
  return Number.isFinite(n) && n > 0 ? n < 1e10 ? Math.trunc(n * 1e3) : Math.trunc(n) : null;
}
__name(cfdEpochMs, "cfdEpochMs");
async function cfdBiquoteQuotes() {
  const out = /* @__PURE__ */ new Map(), url = new URL("https://biquote.io/api/latest");
  for (const provider of Object.values(CFD_SYMBOLS)) url.searchParams.append("symbols", provider);
  let raw;
  try {
    raw = await publicJson(url.toString());
  } catch {
    return out;
  }
  const now = Date.now();
  for (const [symbol, providerSymbol] of Object.entries(CFD_SYMBOLS)) {
    const row = raw?.[providerSymbol], price = cfdPositive(row?.mid);
    if (price === null) continue;
    const at = typeof row?.timestamp === "string" && !/^\d+(?:\.\d+)?$/.test(row.timestamp) ? Date.parse(row.timestamp) : cfdEpochMs(row?.timestamp);
    const change = Number(row?.dayDiffPercent);
    const bid = cfdPositive(row?.bid), ask = cfdPositive(row?.ask);
    out.set(symbol, {
      symbol,
      name: CFD_NAMES[symbol] ?? symbol,
      price: String(price),
      ...Number.isFinite(change) ? { changePercent24h: String(change) } : {},
      ...bid !== null && ask !== null && ask >= bid ? { bid: String(bid), ask: String(ask) } : {},
      status: row?.marketState === "closed" ? "market_closed" : row?.stale === true ? "stale" : "sampled",
      stale: row?.stale === true,
      marketClosed: row?.marketState === "closed",
      displayOnly: true,
      executionAllowed: false,
      provider: "biquote",
      providerSymbol,
      providerTimestamp: Number.isFinite(at) ? at : null,
      fetchedAt: now,
      asOf: Number.isFinite(at) ? at : now,
      maxQuoteAgeMs: 12e4
    });
  }
  return out;
}
__name(cfdBiquoteQuotes, "cfdBiquoteQuotes");
async function cfdDerivQuotes(symbols) {
  const targets = symbols.filter((symbol) => DERIV_CFD_IDS[symbol]);
  const out = /* @__PURE__ */ new Map();
  if (!targets.length || typeof WebSocket !== "function") return out;
  const providerToSymbol = new Map(targets.map((symbol) => [DERIV_CFD_IDS[symbol], symbol]));
  await new Promise((resolve) => {
    let settled = false, ws;
    const finish = /* @__PURE__ */ __name(() => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      try {
        if (ws && ws.readyState < 2) ws.close(1e3, "snapshot");
      } catch {
      }
      resolve();
    }, "finish");
    const timer = setTimeout(finish, 1800);
    try {
      ws = new WebSocket(DERIV_PUBLIC_WS_URL);
    } catch {
      finish();
      return;
    }
    ws.addEventListener("open", () => {
      for (const symbol of targets) {
        try {
          ws.send(JSON.stringify({ ticks: DERIV_CFD_IDS[symbol], subscribe: 1, req_id: `cfd:${symbol}` }));
        } catch {
        }
      }
    });
    ws.addEventListener("message", (event) => {
      let raw;
      try {
        raw = JSON.parse(typeof event.data === "string" ? event.data : "");
      } catch {
        return;
      }
      if (raw?.msg_type !== "tick" || !raw.tick) return;
      const providerSymbol = typeof raw.tick.symbol === "string" ? raw.tick.symbol : "", symbol = providerToSymbol.get(providerSymbol);
      const price = cfdPositive(raw.tick.quote), at = cfdEpochMs(raw.tick.epoch), now = Date.now();
      if (!symbol || price === null || at === null || at > now + 1e3) return;
      const stale = now - at > 12e4;
      out.set(symbol, {
        symbol,
        name: CFD_NAMES[symbol] ?? symbol,
        price: String(price),
        status: stale ? "stale" : "sampled",
        stale,
        marketClosed: false,
        displayOnly: true,
        executionAllowed: false,
        provider: "deriv",
        providerSymbol,
        providerTimestamp: at,
        fetchedAt: now,
        asOf: at,
        maxQuoteAgeMs: 12e4
      });
      if (out.size === targets.length) finish();
    });
    ws.addEventListener("error", finish, { once: true });
    ws.addEventListener("close", finish, { once: true });
  });
  return out;
}
__name(cfdDerivQuotes, "cfdDerivQuotes");
var EIA_MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
function eiaPlain(html) {
  return html.replace(/<[^>]*>/g, " ").replace(/&nbsp;|&#160;|&#xA0;/gi, " ").replace(/&amp;/g, "&").replace(/\s+/g, " ").trim();
}
__name(eiaPlain, "eiaPlain");
function eiaNumber(value) {
  return /^[+-]?(?:\d+(?:\.\d*)?|\.\d+)$/.test(value) && Number.isFinite(Number(value)) ? Number(value) : null;
}
__name(eiaNumber, "eiaNumber");
function parseEiaOil(html, symbol, receivedAt) {
  const meta = EIA_OIL[symbol], plain = eiaPlain(html);
  if (!meta || !plain.includes(meta.title) || !plain.includes("Dollars per Barrel")) return null;
  let latest = null;
  for (const row of html.matchAll(/<tr\b[^>]*>([\s\S]*?)<\/tr>/gi)) {
    const cells = [...row[1].matchAll(/<td\b[^>]*>([\s\S]*?)<\/td>/gi)].map((cell) => eiaPlain(cell[1]));
    if (cells.length !== 6) continue;
    const m = cells[0].match(/^(\d{4})\s+([A-Z][a-z]{2})-\s*(\d{1,2})\s+to\s+([A-Z][a-z]{2})-\s*(\d{1,2})$/);
    if (!m) continue;
    const month = EIA_MONTHS.indexOf(m[2]);
    if (month < 0) continue;
    const start = Date.UTC(Number(m[1]), month, Number(m[3]));
    if (new Date(start).getUTCDay() !== 1) continue;
    for (let day = 0; day < 5; day++) {
      const price = eiaNumber(cells[day + 1]);
      if (price === null) continue;
      const at = start + day * 864e5;
      if (at > receivedAt + 864e5) continue;
      if (!latest || at > latest.at) latest = { at, price };
    }
  }
  if (!latest) return null;
  return {
    symbol,
    name: CFD_NAMES[symbol] ?? symbol,
    price: String(latest.price),
    status: "market_closed",
    stale: true,
    marketClosed: true,
    displayOnly: true,
    executionAllowed: false,
    provider: "eia",
    providerSymbol: meta.providerSymbol,
    providerTimestamp: latest.at,
    fetchedAt: receivedAt,
    asOf: latest.at,
    maxQuoteAgeMs: 864e5
  };
}
__name(parseEiaOil, "parseEiaOil");
async function cfdEiaOilQuotes(symbols) {
  const out = /* @__PURE__ */ new Map(), targets = symbols.filter((symbol) => EIA_OIL[symbol]);
  await Promise.all(targets.map(async (symbol) => {
    try {
      const meta = EIA_OIL[symbol], now = Date.now(), html = await publicText(`https://www.eia.gov/dnav/pet/hist/${meta.file}`), row = parseEiaOil(html, symbol, now);
      if (row) out.set(symbol, row);
    } catch {
    }
  }));
  return out;
}
__name(cfdEiaOilQuotes, "cfdEiaOilQuotes");
async function cfdFrankfurterQuotes(symbols) {
  const targets = symbols.filter((symbol) => FRANKFURTER_FX[symbol]);
  const out = /* @__PURE__ */ new Map();
  if (!targets.length) return out;
  const quotes = [...new Set(targets.map((symbol) => FRANKFURTER_FX[symbol].quote))].join(",");
  let body;
  try {
    body = await publicJson(`https://api.frankfurter.dev/v2/rates?base=usd&quotes=${encodeURIComponent(quotes.toLowerCase())}`);
  } catch {
    return out;
  }
  if (!Array.isArray(body)) return out;
  const rates = new Map(body.flatMap((row) => typeof row?.quote === "string" && cfdPositive(row.rate) !== null ? [[row.quote.toUpperCase(), { rate: Number(row.rate), date: row.date }]] : []));
  const now = Date.now();
  for (const symbol of targets) {
    const meta = FRANKFURTER_FX[symbol], entry = rates.get(meta.quote);
    if (!entry) continue;
    const price = meta.invert ? 1 / entry.rate : entry.rate;
    if (!Number.isFinite(price) || price <= 0) continue;
    const at = typeof entry.date === "string" ? Date.parse(`${entry.date}T00:00:00Z`) : NaN;
    out.set(symbol, {
      symbol,
      name: CFD_NAMES[symbol] ?? symbol,
      price: String(price),
      status: "stale",
      stale: true,
      marketClosed: false,
      displayOnly: true,
      executionAllowed: false,
      provider: "frankfurter",
      providerSymbol: `USD/${meta.quote}`,
      providerTimestamp: Number.isFinite(at) ? at : null,
      fetchedAt: now,
      asOf: Number.isFinite(at) ? at : now,
      maxQuoteAgeMs: 864e5
    });
  }
  return out;
}
__name(cfdFrankfurterQuotes, "cfdFrankfurterQuotes");
async function cfdTickers() {
  const merged = await cfdBiquoteQuotes();
  let missing = Object.keys(CFD_SYMBOLS).filter((symbol) => !merged.has(symbol));
  if (missing.length) {
    const deriv = await cfdDerivQuotes(missing);
    for (const [symbol, row] of deriv) if (!merged.has(symbol)) merged.set(symbol, row);
  }
  missing = Object.keys(CFD_SYMBOLS).filter((symbol) => !merged.has(symbol));
  if (missing.some((symbol) => EIA_OIL[symbol])) {
    const eia = await cfdEiaOilQuotes(missing);
    for (const [symbol, row] of eia) if (!merged.has(symbol)) merged.set(symbol, row);
  }
  missing = Object.keys(CFD_SYMBOLS).filter((symbol) => !merged.has(symbol));
  if (missing.some((symbol) => FRANKFURTER_FX[symbol])) {
    const fx = await cfdFrankfurterQuotes(missing);
    for (const [symbol, row] of fx) if (!merged.has(symbol)) merged.set(symbol, row);
  }
  const tickers = Object.keys(CFD_SYMBOLS).map((symbol) => merged.get(symbol) ?? cfdMissingRow(symbol));
  return {
    source: "cloudflare-cfd-multisource",
    configured: true,
    sources: [...new Set(tickers.filter((row) => row.price !== null).map((row) => row.provider))],
    tickers
  };
}
__name(cfdTickers, "cfdTickers");
async function cfdCandles(symbol, searchParams) {
  const provider = CFD_SYMBOLS[symbol], interval = searchParams.get("interval") || "15m";
  const limit = Math.max(20, Math.min(500, Number(searchParams.get("limit") || "240")));
  if (!provider || !CFD_INTERVALS.has(interval) || !Number.isSafeInteger(limit)) throw new RangeError("invalid_cfd_candle_request");
  const url = new URL(`https://biquote.io/api/${encodeURIComponent(provider)}/ohlc`);
  url.searchParams.set("interval", interval);
  url.searchParams.set("limit", String(limit));
  const raw = await publicJson(url.toString());
  if (!raw || raw.symbol !== provider || raw.interval !== interval || !Array.isArray(raw.bars)) throw new Error("cfd_candle_shape");
  return { ...raw, symbol, fetchedAt: Date.now() };
}
__name(cfdCandles, "cfdCandles");
async function cachedPublic(request, loader, ttlSeconds = EDGE_TTL_SECONDS) {
  const cache2 = globalThis.caches?.default;
  const key = new Request(request.url, { method: "GET" });
  if (cache2) {
    const hit = await cache2.match(key);
    if (hit) return hit;
  }
  const payload = await loader();
  const body = ttlSeconds === SLOW_EDGE_TTL_SECONDS && payload && typeof payload === "object" && !Array.isArray(payload) ? { ...payload, _display: { mode: "snapshot", capturedAt: Date.now(), refreshMs: ttlSeconds * 1e3 } } : payload;
  const response = json(body, 200, {
    "cache-control": `public, max-age=${ttlSeconds}, s-maxage=${ttlSeconds}, stale-while-revalidate=${Math.min(ttlSeconds, 300)}`
  });
  if (cache2) await cache2.put(key, response.clone());
  return response;
}
__name(cachedPublic, "cachedPublic");
var index_default = {
  async fetch(request) {
    const url = new URL(request.url);
    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: JSON_HEADERS });
    if (request.method !== "GET" && request.method !== "HEAD") return json({ ok: false, error: "method_not_allowed" }, 405);
    try {
      let response;
      if (url.pathname === "/health") {
        response = json({ ok: true, service: "voltex-market-edge", version: "public-display-edge-v10" }, 200, { "cache-control": "no-store" });
      } else {
        const book = url.pathname.match(/^\/market\/display\/futures-book\/([A-Z0-9]{1,28}USDT)$/);
        const trades = url.pathname.match(/^\/market\/display\/futures-trades\/([A-Z0-9]{1,28}USDT)$/);
        const candles = url.pathname.match(/^\/market\/display\/futures-candles\/([A-Z0-9]{1,28}USDT)$/);
        const spotBookMatch = url.pathname.match(/^\/market\/display\/spot-book\/([A-Z0-9]{1,32}-[A-Z0-9]{2,12})$/);
        const spotTradesMatch = url.pathname.match(/^\/market\/display\/spot-trades\/([A-Z0-9]{1,32}-[A-Z0-9]{2,12})$/);
        const spotCandlesMatch = url.pathname.match(/^\/market\/display\/spot-candles\/([A-Z0-9]{1,32}-[A-Z0-9]{2,12})$/);
        const cfdCandlesMatch = url.pathname.match(/^\/cfd\/display\/candles\/([A-Z0-9]{3,12})$/);
        if (url.pathname === "/market/display") response = await cachedPublic(request, publicMarketSnapshot, SLOW_EDGE_TTL_SECONDS);
        else if (url.pathname === "/market/display/spot-tickers") response = await cachedPublic(request, spotTickers);
        else if (spotBookMatch) response = await cachedPublic(request, () => spotBook(spotBookMatch[1]));
        else if (spotTradesMatch) response = await cachedPublic(request, () => spotTrades(spotTradesMatch[1]));
        else if (spotCandlesMatch) response = await cachedPublic(request, () => spotCandles(spotCandlesMatch[1], url.searchParams));
        else if (url.pathname === "/cfd/display/tickers") response = await cachedPublic(request, cfdTickers, SLOW_EDGE_TTL_SECONDS);
        else if (cfdCandlesMatch) response = await cachedPublic(request, () => cfdCandles(cfdCandlesMatch[1], url.searchParams), SLOW_EDGE_TTL_SECONDS);
        else if (book) response = await cachedPublic(request, () => futuresBook(book[1]));
        else if (trades) response = await cachedPublic(request, () => futuresTrades(trades[1]));
        else if (url.pathname === "/market/display/futures-tickers") response = await cachedPublic(request, futuresTickers);
        else if (candles) response = await cachedPublic(request, () => futuresCandles(candles[1], url.searchParams));
        else return json({ ok: false, error: "not_found" }, 404);
      }
      return request.method === "HEAD" ? new Response(null, { status: response.status, headers: response.headers }) : response;
    } catch {
      return json({ ok: false, error: "market_data_unavailable" }, 503);
    }
  }
};

// ../../src/services/testMarkets/neurix.ts
var NRX_LISTING_AT = Date.parse("2026-10-03T13:00:00Z");
var NRX_TWO_WEEK_SCENARIO = Object.freeze({
  version: 3,
  // Owner update 2026-10-03: first impulse begins this evening. All targets
  // remain listing-relative to 0.80 USDT; already shown history stays intact.
  from: Date.parse("2026-10-03T18:00:00Z"),
  // 21:00 Kyiv
  firstTargetAt: Date.parse("2026-10-03T21:00:00Z"),
  // 00:00 Kyiv
  breakoutAt: Date.parse("2026-10-04T05:00:00Z"),
  // 08:00 Kyiv
  secondTargetAt: Date.parse("2026-10-04T09:00:00Z"),
  // 12:00 Kyiv
  thirdTargetAt: Date.parse("2026-10-04T13:00:00Z"),
  // 16:00 Kyiv
  rangeEndAt: Date.parse("2026-10-06T13:00:00Z"),
  // 48h upper range
  selloffEndAt: Date.parse("2026-10-06T19:00:00Z"),
  // six-hour selloff
  endAt: Date.parse("2026-10-17T18:00:00Z"),
  // fourteen days from activation
  firstGainPercent: 840,
  secondGainPercent: 1745,
  thirdGainPercent: 7217,
  rangeFraction: 0.2,
  selloffFraction: 0.6
});
var NRX_BALANCE_SELLOFF_SCENARIO = Object.freeze({
  mode: "range-selloff-range",
  version: 5,
  from: Date.parse("2026-10-06T17:00:00Z"),
  // 20:00 Kyiv; prospective release gate
  rangeEndAt: Date.parse("2026-10-06T17:30:00Z"),
  // pump exhaustion, no growth trend
  selloffEndAt: Date.parse("2026-10-06T23:30:00Z"),
  // six-hour -60% correction
  rangeFraction: 0.2,
  selloffFraction: 0.6
});
var NEURIX = Object.freeze({
  symbol: "NRX",
  name: "NEURIX",
  quote: "USDT",
  pair: "NRX/USDT",
  isTestAsset: true,
  isTradable: true,
  listingArmed: true,
  listingAt: NRX_LISTING_AT,
  initialPrice: 0.8,
  seed: "neurix-2026-10-03",
  // Owner (2026-10-03): a live post-listing market on 15m/1h/4h — price
  // discovery, impulse legs, corrections with flushes that are bought back,
  // accumulation ranges — with the same block and day anchors as before.
  // From the listing itself: nothing has been shown or traded before it.
  // Release MUST be live (Hetzner API and the market-edge Worker) before this
  // instant; otherwise move it to the next full hour after the release.
  marketStructure: { from: NRX_LISTING_AT },
  scheduledScenario: NRX_BALANCE_SELLOFF_SCENARIO
});

// ../../src/services/testMarkets/simulationRandom.ts
function fnv1a(text) {
  let h = 2166136261;
  for (let i = 0; i < text.length; i++) {
    h ^= text.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}
__name(fnv1a, "fnv1a");
function mulberry32(state) {
  let a = state >>> 0;
  return () => {
    a = a + 1831565813 | 0;
    let t = Math.imul(a ^ a >>> 15, 1 | a);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}
__name(mulberry32, "mulberry32");
function seededRandom(seed, ...labels) {
  return mulberry32(fnv1a([seed, ...labels].join("|")));
}
__name(seededRandom, "seededRandom");
function normal(random) {
  let u = random();
  while (u <= Number.EPSILON) u = random();
  const z = Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * random());
  return Math.max(-3.2, Math.min(3.2, z));
}
__name(normal, "normal");

// ../../src/services/testMarkets/simulationScenarioControls.ts
var HOUR = 36e5;
var MINUTE = 6e4;
var TICK = 1e4;
var frequencies = { rare: 0.18, moderate: 0.5, often: 0.84 };
var smooth = /* @__PURE__ */ __name((x) => x * x * (3 - 2 * x), "smooth");
function noise(seed, label, at, period) {
  const slot = Math.floor(at / period), part = at / period - slot;
  const a = seededRandom(seed, label, slot)() * 2 - 1, b = seededRandom(seed, label, slot + 1)() * 2 - 1;
  return a + (b - a) * smooth(part);
}
__name(noise, "noise");
function piecewise(u, points) {
  const i = Math.max(0, points.findIndex((point, index) => index > 0 && u <= point[0]) - 1);
  const a = points[i], b = points[Math.min(points.length - 1, i + 1)];
  return a[1] + (b[1] - a[1]) * smooth((u - a[0]) / (b[0] - a[0]));
}
__name(piecewise, "piecewise");
function progress(scenario, u) {
  if (u <= 0) return 0;
  if (u >= 1) return 1;
  switch (scenario) {
    case "WAVES":
      return u + 0.09 * Math.sin(6 * Math.PI * u);
    case "FREQUENT_PULLBACKS":
      return u + 0.07 * Math.sin(14 * Math.PI * u) * Math.sin(Math.PI * u);
    case "COMPRESSION_BREAKOUT":
      return piecewise(u, [[0, 0], [0.55, 0.075], [0.73, 0.8], [1, 1]]);
    case "STAIRCASE":
      return piecewise(u, [[0, 0], [0.1, 0.2], [0.28, 0.2], [0.4, 0.48], [0.62, 0.48], [0.73, 0.8], [0.89, 0.8], [1, 1]]);
    case "SLOW_START":
      return u * u;
    case "FAST_START":
      return 1 - (1 - u) * (1 - u);
    case "FALSE_BREAKOUT":
      return piecewise(u, [[0, 0], [0.23, 0.52], [0.42, 0.18], [0.6, 0.32], [1, 1]]);
    case "DEEP_RECOVERY":
      return piecewise(u, [[0, 0], [0.39, 0.76], [0.62, 0.35], [1, 1]]);
    case "LONG_WICKS":
      return u + (0.055 * Math.sin(10 * Math.PI * u) + 0.022 * Math.sin(26 * Math.PI * u)) * Math.sin(Math.PI * u);
    default:
      return u;
  }
}
__name(progress, "progress");
function stageAt(config, at) {
  let start = config.from, open = Number(config.initialPrice);
  for (const [index, stage] of config.controls.stages.entries()) {
    const end = start + stage.durationHours * HOUR, close = Number(stage.targetPrice);
    if (at < end) return { start, end, open, close, regime: stage.type === "range" ? "consolidation" : stage.type === "pullback" ? "pullback" : "impulse", index };
    start = end;
    open = close;
  }
  return { start, end: Infinity, open, close: open, regime: "consolidation", index: config.controls.stages.length };
}
__name(stageAt, "stageAt");
function baseline(config, stage, at) {
if(config.controls.terminalPeak==='bounded-v1' && stage.index===config.controls.stages.length) return stage.open*(1-.04*(1-Math.exp(-(at-stage.start)/HOUR)));

  if (stage.open === stage.close) return stage.open;
  const u = (at - stage.start) / (stage.end - stage.start);
  const travelled = progress(config.controls.scenario, u);
  return stage.open * Math.exp(Math.log(stage.close / stage.open) * travelled);
}
__name(baseline, "baseline");
function displaced(base, shift, cap) {
  const odds = base / (cap - base);
  const next = odds * Math.exp(shift);
  return cap * next / (1 + next);
}
__name(displaced, "displaced");
function priceAt(config, seed, at) {
  if (at <= config.from) return Number(config.initialPrice);
  const p = stageAt(config, at);
  if (at === p.start) return p.open;
  const c = config.controls, t = at - p.start, cap = Number(c.maxPrice);
  const label = `scenario-controls-v2:${p.index}`;
  const envelope = Math.min(1, t / (5 * MINUTE), (p.end - at) / (5 * MINUTE));
  let base = baseline(config, p, at);
  const lastStage = c.stages[c.stages.length - 1];
  if (c.scenario === "DEEP_RECOVERY" && c.afterGrowth === "range" && p.index === c.stages.length && lastStage.type === "recovery" && p.open === cap) {
    base = cap * (1 - .06 * smooth(Math.min(1, t / HOUR)));
  }
  const duration = c.pullbacks.durationMinutes * MINUTE;
  const spacing = duration * { rare: 5, moderate: 3, often: 1.4 }[c.pullbacks.frequency];
  const slot = Math.floor(t / spacing), eventStart = p.start + slot * spacing + 2 * MINUTE;
  const random = seededRandom(seed, label, "drawdown", slot);
  const occurs = random() < frequencies[c.pullbacks.frequency] || c.pullbacks.frequency === "rare" && slot % 6 === 1;
  if (occurs && eventStart + duration < p.end - 5 * MINUTE) {
    const u = (at - eventStart) / duration;
    if (u > 0 && u < 1) {
      const peak = baseline(config, p, eventStart);
      const depth = (Number(c.pullbacks.minDepthPercent) + random() * (Number(c.pullbacks.maxDepthPercent) - Number(c.pullbacks.minDepthPercent))) / 100;
      const trough = peak * (1 - depth), end = baseline(config, p, eventStart + duration);
      base = u <= 0.38 ? peak + (trough - peak) * smooth(u / 0.38) : trough + (end - trough) * smooth((u - 0.38) / 0.62);
    }
  }
  const intensity = { low: 8e-3, medium: 0.026, high: 0.055 }[c.candles.intensity];
  const cluster = 0.25 + 0.75 * (noise(seed, label + ":cluster", t, 89 * MINUTE) + 1) / 2;
  const paused = (noise(seed, label + ":pause", t, 23 * MINUTE) + 1) / 2 < frequencies[c.candles.pauseFrequency] * 0.5;
  const amplitude = intensity * (paused ? 0.12 : 1) * cluster;
  const move = noise(seed, label + ":medium", t, 13 * MINUTE) * amplitude + noise(seed, label + ":fast", t, 83e3) * amplitude * (0.5 + c.candles.diversity) + noise(seed, label + ":micro", t, 31e3) * amplitude * 0.4 * c.candles.diversity;
  const range = p.regime === "consolidation" ? noise(seed, label + ":range", t, 137 * MINUTE) * intensity * 2.5 : 0;
  if(c.terminalPeak==='bounded-v1' && base===cap) return cap;
return displaced(base, envelope * (move + range), cap);


}
__name(priceAt, "priceAt");
var historicalOpenIndexes = [];
function findHistoricalOpenIndex(program, anchor) {
  const at = historicalOpenIndexes.findIndex((entry2) => entry2.program === program && entry2.anchor === anchor);
  if (at < 0) return void 0;
  const [entry] = historicalOpenIndexes.splice(at, 1);
  historicalOpenIndexes.push(entry);
  return entry;
}
__name(findHistoricalOpenIndex, "findHistoricalOpenIndex");
function buildHistoricalOpenIndex(program, anchor) {
  if (!Number.isFinite(anchor) || anchor <= 0 || !Object.isFrozen(program) || !Object.isFrozen(program.clips) || !program.clips.every((clip) => Object.isFrozen(clip) && Object.isFrozen(clip.bars) && clip.bars.every((bar) => Object.isFrozen(bar)))) return void 0;
  const total = program.clips.reduce((sum, clip) => sum + clip.bars.length, 0);
  if (total < 24 || total > 4800) return void 0;
  const opens = new Float64Array(total + 1), bars = [];
  let offset = 0, clipAnchor = anchor;
  for (const clip of program.clips) {
    let open = clipAnchor, factor = 1;
    for (const bar of clip.bars) {
      opens[offset++] = open;
      bars.push(bar);
      const multiplier = 1 + bar[2] / 1e6;
      open *= multiplier;
      factor *= multiplier;
    }
    clipAnchor *= factor;
  }
  opens[total] = clipAnchor;
  const entry = { program, anchor, opens, bars };
  if (historicalOpenIndexes.length === 4) historicalOpenIndexes.shift();
  historicalOpenIndexes.push(entry);
  return entry;
}
__name(buildHistoricalOpenIndex, "buildHistoricalOpenIndex");
function lastFactor(clip) {
  return clip.bars.reduce((factor, bar) => factor * (1 + bar[2] / 1e6), 1);
}
__name(lastFactor, "lastFactor");
function historicalReplayHour(program, anchor, hour, seed) {
  if (!Number.isSafeInteger(hour) || hour < 0) throw new Error("\u0427\u0430\u0441 \u0438\u0441\u0442\u043E\u0440\u0438\u0438 \u0434\u043E\u043B\u0436\u0435\u043D \u0431\u044B\u0442\u044C \u043D\u0435\u043E\u0442\u0440\u0438\u0446\u0430\u0442\u0435\u043B\u044C\u043D\u044B\u043C");
  let indexed = findHistoricalOpenIndex(program, anchor);
  if (!indexed) {
    indexed = buildHistoricalOpenIndex(program, anchor);
  }
  let open = anchor, remaining = hour;
  let found = null;
  if (indexed) {
    open = indexed.opens[Math.min(hour, indexed.bars.length)];
    found = indexed.bars[hour] ?? null;
  } else {
    for (const clip of program.clips) {
      if (remaining < clip.bars.length) {
        for (let i = 0; i < remaining; i++) open *= 1 + clip.bars[i][2] / 1e6;
        found = clip.bars[remaining];
        break;
      }
      open *= lastFactor(clip);
      remaining -= clip.bars.length;
    }
  }
  if (!Number.isFinite(open) || open <= 0) throw new Error("\u0418\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u0446\u0435\u043D\u0430 \u043D\u0435 \u043F\u0440\u0435\u0434\u0441\u0442\u0430\u0432\u0438\u043C\u0430");
  const ticks = [];
  let last = open;
  const hash = Array.from(seed + ":" + hour).reduce((h, ch) => (h * 33 ^ ch.charCodeAt(0)) >>> 0, 5381);
  const upFirst = (hash & 1) === 0;
  const [high, low, close] = found ? [open * (1 + found[0] / 1e6), open * (1 + found[1] / 1e6), open * (1 + found[2] / 1e6)] : [open * 1.004, open * 0.996, open];
  const stops = upFirst ? [[0, open], [120, high], [240, low], [360, close]] : [[0, open], [120, low], [240, high], [360, close]];
  for (let t = 1; t <= 360; t++) {
    const index = t <= 120 ? 0 : t <= 240 ? 1 : 2;
    const [t0, p0] = stops[index], [t1, p1] = stops[index + 1];
    const fraction = (t - t0) / (t1 - t0);
    const price = t === 360 ? close : p0 * Math.exp(Math.log(p1 / p0) * fraction);
    const move = Math.abs(Math.log(price / last));
    const quoteVolume = 20 + Math.min(300, move * 2e4) + hash % 17;
    ticks.push({
      price,
      high: Math.max(last, price),
      low: Math.min(last, price),
      quoteVolume,
      volume: quoteVolume / ((price + last) / 2)
    });
    last = price;
  }
  const delta = Math.log(close / open);
  return { open, ticks, regime: delta > 1e-3 ? "impulse" : delta < -1e-3 ? "pullback" : "consolidation" };
}
__name(historicalReplayHour, "historicalReplayHour");
function controlledScenarioHour(config, seed, hour) {
  const stagesEnd = config.controls.stages.reduce((total, stage) => total + stage.durationHours, 0);
  if (config.controls.afterGrowth === "historical" && config.controls.historical && hour >= stagesEnd) {
    const anchor = Number(config.controls.stages[config.controls.stages.length - 1].targetPrice);
    return historicalReplayHour(config.controls.historical, anchor, hour - stagesEnd, seed);
  }
  const start = config.from + hour * HOUR, cap = Number(config.controls.maxPrice);
  const open = priceAt(config, seed, start), ticks = [];
  let previous = open;
  for (let i = 0; i < 360; i++) {
    const at = start + (i + 1) * TICK, price = priceAt(config, seed, at);
    const random = seededRandom(seed, "scenario-controls-v2:tick", at);
    const top = Math.max(previous, price), bottom = Math.min(previous, price), move = Math.abs(Math.log(price / previous));
    const c = config.controls;
    const shadowScale = { short: 5e-4, normal: 2e-3, pronounced: 8e-3 }[c.wicks.length];
    const strong = random() < frequencies[c.wicks.longFrequency] * 0.15;
    const activity = 0.4 + random() * (1 + c.candles.diversity);
    const shadow = shadowScale * activity * (strong ? 2 + random() * 5 : random());
    const high = top + (cap - top) * (1 - Math.exp(-shadow * top / cap * random()));
    const low = bottom * Math.exp(-shadow * random());
    const quoteVolume = (25 + random() * 190) * activity * (1 + Math.min(12, 140 * move));
    ticks.push({ price, high, low, volume: quoteVolume / ((previous + price) / 2), quoteVolume });
    previous = price;
  }
  return { open, ticks, regime: stageAt(config, start + HOUR / 2).regime };
}
__name(controlledScenarioHour, "controlledScenarioHour");

// ../../src/shared/listingScenarioControls.ts
var LISTING_SCENARIOS = ["CALM", "WAVES", "FREQUENT_PULLBACKS", "COMPRESSION_BREAKOUT", "STAIRCASE", "SLOW_START", "FAST_START", "FALSE_BREAKOUT", "DEEP_RECOVERY", "LONG_WICKS"];
function validateHistoricalMoveProgram(program) {
  if (!program || program.version !== 1 || !Array.isArray(program.clips) || program.clips.length < 1 || program.clips.length > 3)
    throw new Error("\u0414\u043E\u0431\u0430\u0432\u044C\u0442\u0435 \u043E\u0442 \u043E\u0434\u043D\u043E\u0433\u043E \u0434\u043E \u0442\u0440\u0451\u0445 \u0438\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u043E\u0442\u0440\u0435\u0437\u043A\u043E\u0432");
  let count = 0;
  for (const clip of program.clips) {
    if (!["BTC/USDT", "ETH/USDT", "SOL/USDT"].includes(clip.source) || clip.resolution !== "1h" || clip.provenance !== "USER_SUPPLIED_UNVERIFIED" || !/^\d{4}-\d\d-\d\dT\d\d:00:00\.000Z$/.test(clip.sourceStart) || !Number.isFinite(Date.parse(clip.sourceStart)) || new Date(clip.sourceStart).toISOString() !== clip.sourceStart)
      throw new Error("\u041D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u043E\u0435 \u0438\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u043E\u0435 \u0434\u0432\u0438\u0436\u0435\u043D\u0438\u0435 \u0438\u043B\u0438 \u0438\u0441\u0442\u043E\u0447\u043D\u0438\u043A");
    if (!Array.isArray(clip.bars) || clip.bars.length < 24 || clip.bars.length > 2400)
      throw new Error("\u041E\u0442\u0440\u0435\u0437\u043E\u043A \u0434\u043E\u043B\u0436\u0435\u043D \u0441\u043E\u0434\u0435\u0440\u0436\u0430\u0442\u044C \u043E\u0442 24 \u0434\u043E 2400 \u043F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u044B\u0445 \u0447\u0430\u0441\u043E\u0432");
    count += clip.bars.length;
    for (const bar of clip.bars) {
      if (!Array.isArray(bar) || bar.length !== 3 || !bar.every(Number.isSafeInteger))
        throw new Error("\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u044B\u0435 \u0438\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u043A\u043E\u044D\u0444\u0444\u0438\u0446\u0438\u0435\u043D\u0442\u044B OHLC");
      const [hi, lo, close] = bar;
      if (hi < Math.max(0, close) || lo > Math.min(0, close) || lo <= -1e6 || hi > 4e6 || close <= -1e6 || close > 4e6)
        throw new Error("\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0435 \u0433\u0440\u0430\u043D\u0438\u0446\u044B \u0438\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u043E\u0439 \u0441\u0432\u0435\u0447\u0438");
    }
  }
  if (count > 4800) throw new Error("\u041D\u0435 \u0431\u043E\u043B\u0435\u0435 4800 \u0447\u0430\u0441\u043E\u0432 \u0432 \u0446\u0435\u043F\u043E\u0447\u043A\u0435");
}
__name(validateHistoricalMoveProgram, "validateHistoricalMoveProgram");
function historicalReplayBounds(program, anchor) {
  validateHistoricalMoveProgram(program);
  if (!(anchor > 0) || !Number.isFinite(anchor)) throw new Error("\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u0430\u044F \u0446\u0435\u043D\u0430 \u0441\u043E\u0435\u0434\u0438\u043D\u0435\u043D\u0438\u044F");
  let close = anchor, min = anchor, max = anchor;
  for (const clip of program.clips) for (const [h, l, c] of clip.bars) {
    min = Math.min(min, close * (1 + l / 1e6));
    max = Math.max(max, close * (1 + h / 1e6));
    close *= 1 + c / 1e6;
    if (!Number.isFinite(close) || close < 1e-8 || close > 1e9)
      throw new Error("\u0418\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u0438\u0439 \u043E\u0442\u0440\u0435\u0437\u043E\u043A \u0432\u044B\u0445\u043E\u0434\u0438\u0442 \u0437\u0430 \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u043C\u0443\u044E \u0442\u043E\u0447\u043D\u043E\u0441\u0442\u044C \u0446\u0435\u043D\u044B");
  }
  return { min, max, close };
}
__name(historicalReplayBounds, "historicalReplayBounds");
function normalizeScenarioDecimal(input) {
  const text = input.trim().replace(",", ".");
  if (!/^\d{1,18}(?:\.\d{1,10})?$/.test(text)) throw new RangeError("\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u043F\u043E\u043B\u043E\u0436\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0435 \u0447\u0438\u0441\u043B\u043E, \u043D\u0435 \u0431\u043E\u043B\u0435\u0435 10 \u0437\u043D\u0430\u043A\u043E\u0432 \u043F\u043E\u0441\u043B\u0435 \u0437\u0430\u043F\u044F\u0442\u043E\u0439");
  const [whole, fraction = ""] = text.split(".");
  const clean = fraction.replace(/0+$/, "");
  return `${BigInt(whole)}${clean ? `.${clean}` : ""}`;
}
__name(normalizeScenarioDecimal, "normalizeScenarioDecimal");
var SCALE = 10000000000n;
function units(input) {
  const [whole, fraction = ""] = normalizeScenarioDecimal(input).split(".");
  return BigInt(whole) * SCALE + BigInt(fraction.padEnd(10, "0"));
}
__name(units, "units");
function decimal(value) {
  const negative = value < 0n;
  const absolute = negative ? -value : value;
  const fraction = (absolute % SCALE).toString().padStart(10, "0").replace(/0+$/, "");
  return `${negative ? "-" : ""}${absolute / SCALE}${fraction ? `.${fraction}` : ""}`;
}
__name(decimal, "decimal");
function exactPriceFromGain(initialPrice, gainPercent) {
  return decimal(units(initialPrice) * (100n * SCALE + units(gainPercent)) / (100n * SCALE));
}
__name(exactPriceFromGain, "exactPriceFromGain");
function legacyValidateScenarioControls(program, initialPrice) {
  const initial = units(initialPrice), cap = units(program.maxPrice), first = units(exactPriceFromGain(initialPrice, program.first24hGainPercent));
  for (const value of [initialPrice, program.maxPrice, ...program.stages.map((stage) => stage.targetPrice)]) {
    const canonical = normalizeScenarioDecimal(value);
    if (Number(value) < 1e-8 || Number(value) > 1e9 || normalizeScenarioDecimal(Number(value).toFixed(10)) !== canonical) {
      throw new RangeError("\u0426\u0435\u043D\u0430 \u043D\u0435 \u043F\u043E\u043C\u0435\u0449\u0430\u0435\u0442\u0441\u044F \u0432 \u0442\u043E\u0447\u043D\u043E\u0441\u0442\u044C \u0430\u043A\u0442\u0438\u0432\u0430: \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u043E\u0442 0,00000001 \u0434\u043E 1000000000 \u0441 \u043C\u0435\u043D\u044C\u0448\u0438\u043C \u0447\u0438\u0441\u043B\u043E\u043C \u0437\u043D\u0430\u043A\u043E\u0432");
    }
  }
  if (initial <= 0n || cap <= initial) throw new RangeError("\u041C\u0430\u043A\u0441\u0438\u043C\u0430\u043B\u044C\u043D\u0430\u044F \u0446\u0435\u043D\u0430 \u0434\u043E\u043B\u0436\u043D\u0430 \u0431\u044B\u0442\u044C \u0432\u044B\u0448\u0435 \u043D\u0430\u0447\u0430\u043B\u044C\u043D\u043E\u0439 \u0446\u0435\u043D\u044B");
  if (first >= cap) throw new RangeError("\u0426\u0435\u043B\u044C \u0437\u0430 \u043F\u0435\u0440\u0432\u044B\u0435 \u0441\u0443\u0442\u043A\u0438 \u0432\u044B\u0448\u0435 \u043C\u0430\u043A\u0441\u0438\u043C\u0430\u043B\u044C\u043D\u043E\u0439 \u0446\u0435\u043D\u044B");
  if (Number(program.first24hGainPercent) <= 0 || Number(program.first24hGainPercent) > 1e5) throw new RangeError("\u0420\u043E\u0441\u0442 \u0437\u0430 \u043F\u0435\u0440\u0432\u044B\u0435 \u0441\u0443\u0442\u043A\u0438 \u0434\u043E\u043B\u0436\u0435\u043D \u0431\u044B\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435 \u043D\u0443\u043B\u044F \u0438 \u043D\u0435 \u0432\u044B\u0448\u0435 100000%");
  if (units(program.pullbacks.minDepthPercent) > units(program.pullbacks.maxDepthPercent)) throw new RangeError("\u041C\u0438\u043D\u0438\u043C\u0430\u043B\u044C\u043D\u0430\u044F \u0433\u043B\u0443\u0431\u0438\u043D\u0430 \u043E\u0442\u043A\u0430\u0442\u0430 \u043D\u0435 \u043C\u043E\u0436\u0435\u0442 \u0431\u044B\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435 \u043C\u0430\u043A\u0441\u0438\u043C\u0430\u043B\u044C\u043D\u043E\u0439");
  let elapsed = 0, previous = initial, foundDayOne = false;
  for (const [index, stage] of program.stages.entries()) {
    elapsed += stage.durationHours;
    const target = units(stage.targetPrice);
    const terminalPeak = program.scenario === "DEEP_RECOVERY" && program.afterGrowth === "range" && index === program.stages.length - 1 && stage.type === "recovery" && target === cap;
    if (target <= 0n || (!terminalPeak && (target > cap * 97n / 100n || target + 2n >= cap))) throw new RangeError("\u0426\u0435\u043B\u044C \u044D\u0442\u0430\u043F\u0430 \u0434\u043E\u043B\u0436\u043D\u0430 \u043E\u0441\u0442\u0430\u0432\u043B\u044F\u0442\u044C \u043D\u0435 \u043C\u0435\u043D\u0435\u0435 3% \u0434\u043E \u043C\u0430\u043A\u0441\u0438\u043C\u0430\u043B\u044C\u043D\u043E\u0439 \u0446\u0435\u043D\u044B \u0434\u043B\u044F \u043A\u043E\u043B\u0435\u0431\u0430\u043D\u0438\u0439 \u0438 \u0442\u0435\u043D\u0435\u0439");
    if ((stage.type === "growth" || stage.type === "recovery") && target <= previous) throw new RangeError("\u0426\u0435\u043D\u0430 \u0432 \u043A\u043E\u043D\u0446\u0435 \u0440\u043E\u0441\u0442\u0430 \u0438\u043B\u0438 \u0432\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u0438\u044F \u0434\u043E\u043B\u0436\u043D\u0430 \u0431\u044B\u0442\u044C \u0432\u044B\u0448\u0435 \u0446\u0435\u043D\u044B \u0432 \u043D\u0430\u0447\u0430\u043B\u0435 \u044D\u0442\u0430\u043F\u0430");
    if (stage.type === "range" && target !== previous) throw new RangeError("\u0414\u043B\u044F \u0431\u043E\u043A\u043E\u0432\u0438\u043A\u0430 \u0446\u0435\u043D\u0430 \u0432 \u043D\u0430\u0447\u0430\u043B\u0435 \u0438 \u043A\u043E\u043D\u0446\u0435 \u044D\u0442\u0430\u043F\u0430 \u0434\u043E\u043B\u0436\u043D\u0430 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0442\u044C");
    if (stage.type === "pullback" && target >= previous) throw new RangeError("\u0426\u0435\u043D\u0430 \u0432 \u043A\u043E\u043D\u0446\u0435 \u043E\u0442\u043A\u0430\u0442\u0430 \u0434\u043E\u043B\u0436\u043D\u0430 \u0431\u044B\u0442\u044C \u043D\u0438\u0436\u0435 \u0446\u0435\u043D\u044B \u0432 \u043D\u0430\u0447\u0430\u043B\u0435 \u044D\u0442\u0430\u043F\u0430");
    if (elapsed === 24) {
      foundDayOne = true;
      if (target !== first) throw new RangeError("\u0426\u0435\u043B\u044C \u044D\u0442\u0430\u043F\u0430 \u0432 \u043A\u043E\u043D\u0446\u0435 \u043F\u0435\u0440\u0432\u044B\u0445 \u0441\u0443\u0442\u043E\u043A \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442 \u0441 \u0440\u043E\u0441\u0442\u043E\u043C \u0437\u0430 \u043F\u0435\u0440\u0432\u044B\u0435 24 \u0447\u0430\u0441\u0430");
    }
    previous = target;
  }
  if (!foundDayOne) throw new RangeError("\u041E\u0434\u0438\u043D \u0438\u0437 \u044D\u0442\u0430\u043F\u043E\u0432 \u0434\u043E\u043B\u0436\u0435\u043D \u0437\u0430\u043A\u0430\u043D\u0447\u0438\u0432\u0430\u0442\u044C\u0441\u044F \u0440\u043E\u0432\u043D\u043E \u0447\u0435\u0440\u0435\u0437 24 \u0447\u0430\u0441\u0430 \u0441 \u0446\u0435\u043B\u044C\u044E \u043F\u0435\u0440\u0432\u044B\u0445 \u0441\u0443\u0442\u043E\u043A");
  if (elapsed < 24 || elapsed > 720) throw new RangeError("\u041E\u0431\u0449\u0430\u044F \u043F\u0440\u043E\u0434\u043E\u043B\u0436\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0440\u043E\u0441\u0442\u0430 \u0434\u043E\u043B\u0436\u043D\u0430 \u0431\u044B\u0442\u044C \u043E\u0442 24 \u0434\u043E 720 \u0447\u0430\u0441\u043E\u0432");
  if (program.afterGrowth === "historical") {
    if (!program.historical) throw new RangeError("\u0414\u043B\u044F \u0438\u0441\u0442\u043E\u0440\u0438\u0438 \u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u0435 CSV \u0441 \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u044B\u043C\u0438 \u0447\u0430\u0441\u043E\u0432\u044B\u043C\u0438 \u0441\u0432\u0435\u0447\u0430\u043C\u0438");
    validateHistoricalMoveProgram(program.historical);
    if (program.stages[program.stages.length - 1]?.type !== "pullback")
      throw new RangeError("\u041F\u0435\u0440\u0435\u0434 \u0438\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u0438\u043C \u0441\u0446\u0435\u043D\u0430\u0440\u0438\u0435\u043C \u043D\u0435\u043E\u0431\u0445\u043E\u0434\u0438\u043C \u0437\u0430\u043A\u043B\u044E\u0447\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0439 \u044D\u0442\u0430\u043F \u043F\u0430\u0434\u0435\u043D\u0438\u044F");
    const bounds = historicalReplayBounds(program.historical, Number(program.stages[program.stages.length - 1].targetPrice));
    if (bounds.max >= Number(program.maxPrice) * 0.995)
      throw new RangeError("\u0418\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u0438\u0439 \u043E\u0442\u0440\u0435\u0437\u043E\u043A \u043F\u0440\u0435\u0432\u044B\u0448\u0430\u0435\u0442 \u043E\u0431\u0449\u0438\u0439 \u043B\u0438\u043C\u0438\u0442 \u0446\u0435\u043D\u044B: \u0432\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0434\u0440\u0443\u0433\u043E\u0439 \u0444\u0440\u0430\u0433\u043C\u0435\u043D\u0442");
    if (bounds.min < 1e-8)
      throw new RangeError("\u0418\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u043E\u0435 \u0434\u0432\u0438\u0436\u0435\u043D\u0438\u0435 \u0432\u044B\u0445\u043E\u0434\u0438\u0442 \u0437\u0430 \u0442\u043E\u0447\u043D\u043E\u0441\u0442\u044C \u0430\u043A\u0442\u0438\u0432\u0430");
  } else if (program.historical) {
    throw new RangeError("\u0418\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u0441\u0432\u0435\u0447\u0438 \u0434\u043E\u043B\u0436\u043D\u044B \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u0442\u044C\u0441\u044F \u0442\u043E\u043B\u044C\u043A\u043E \u0432 \u0438\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u043E\u043C \u0440\u0435\u0436\u0438\u043C\u0435");
  }
}
__name(validateScenarioControls, "validateScenarioControls");

// ../../src/services/testMarkets/simulationSchedule.ts
function isRangeSelloffRangeScenario(c) {
  return c.mode === "range-selloff-range";
}
__name(isRangeSelloffRangeScenario, "isRangeSelloffRangeScenario");
var TICK2 = 1e4;
var MINUTE2 = 6e4;
var HOUR2 = 60 * MINUTE2;
function validateScheduledScenario(c, listingAt) {
  if (c.mode === "scenario-controls-v2") {
    if (c.version !== 2 || c.from !== listingAt || !Number.isSafeInteger(listingAt) || listingAt % TICK2 !== 0) throw new RangeError("\u041D\u0435\u0432\u0435\u0440\u043D\u043E\u0435 \u0432\u0440\u0435\u043C\u044F \u043D\u0430\u0447\u0430\u043B\u0430 \u0441\u0446\u0435\u043D\u0430\u0440\u0438\u044F");
    validateScenarioControls(c.controls, c.initialPrice);
    return;
  }
  const commonInvalid = !Number.isSafeInteger(c.version) || c.version < 1 || !Number.isFinite(listingAt) || !Number.isFinite(c.rangeFraction) || c.rangeFraction <= 0 || c.rangeFraction >= 1;
  if (c.mode === "capped-growth-range") {
    const times2 = [c.from, c.firstTargetAt, c.peakAt];
    if (commonInvalid || c.from !== listingAt || times2.some((t, i) => !Number.isSafeInteger(t) || t % TICK2 !== 0 || i > 0 && t <= times2[i - 1]) || c.firstTargetAt !== listingAt + 24 * HOUR2 || c.peakAt < c.firstTargetAt + 24 * HOUR2 || !Number.isFinite(c.firstGainPercent) || c.firstGainPercent <= 0 || !Number.isFinite(c.maxGainPercent) || c.maxGainPercent <= c.firstGainPercent) {
      throw new RangeError("Invalid bounded demo scenario");
    }
    return;
  }
  const selloffInvalid = !Number.isFinite(c.selloffFraction) || c.selloffFraction <= 0 || c.selloffFraction >= 1;
  if (isRangeSelloffRangeScenario(c)) {
    const times2 = [c.from, c.rangeEndAt, c.selloffEndAt];
    if (commonInvalid || selloffInvalid || times2.some((t, i) => !Number.isSafeInteger(t) || t % TICK2 !== 0 || t < listingAt || i > 0 && t <= times2[i - 1])) {
      throw new RangeError("Invalid scheduled simulation configuration");
    }
    return;
  }
  const times = [c.from, c.firstTargetAt, c.breakoutAt, c.secondTargetAt, c.thirdTargetAt, c.rangeEndAt, c.selloffEndAt, c.endAt];
  if (commonInvalid || selloffInvalid || times.some((t, i) => !Number.isSafeInteger(t) || t % TICK2 !== 0 || t < listingAt || i > 0 && t <= times[i - 1]) || !Number.isFinite(c.firstGainPercent) || c.firstGainPercent <= -100 || !Number.isFinite(c.secondGainPercent) || c.secondGainPercent <= c.firstGainPercent || !Number.isFinite(c.thirdGainPercent) || c.thirdGainPercent <= c.secondGainPercent) {
    throw new RangeError("Invalid scheduled simulation configuration");
  }
}
__name(validateScheduledScenario, "validateScheduledScenario");
var contexts = /* @__PURE__ */ new Map();
function context(c, seed, listingAt, listingPrice, anchor) {
  validateScheduledScenario(c, listingAt);
  if (![listingPrice, anchor].every((p) => Number.isFinite(p) && p > 0)) throw new RangeError("Invalid scenario price");
  const key = JSON.stringify([c, seed, listingAt, listingPrice, anchor]);
  const cached = contexts.get(key);
  if (cached) return cached;
  let terminal;
  let rows;
  if (c.mode === "capped-growth-range") {
    const first = listingPrice * (1 + c.firstGainPercent / 100);
    terminal = listingPrice * (1 + c.maxGainPercent / 100) * 0.94;
    rows = [
      ["launch", c.from, c.firstTargetAt, anchor, first, "impulse", false],
      ["discovery-range", c.firstTargetAt, c.firstTargetAt + 6 * HOUR2, first, first, "consolidation", true],
      ["maturing-rise", c.firstTargetAt + 6 * HOUR2, c.peakAt, first, terminal, "impulse", false],
      ["terminal-range", c.peakAt, Infinity, terminal, terminal, "consolidation", true]
    ];
  } else if (isRangeSelloffRangeScenario(c)) {
    terminal = anchor * (1 - c.selloffFraction);
    if (!Number.isFinite(terminal) || terminal <= 0) throw new RangeError("Invalid scenario target");
    rows = [
      ["growth-stop-range", c.from, c.rangeEndAt, anchor, anchor, "consolidation", true],
      ["selloff", c.rangeEndAt, c.selloffEndAt, anchor, terminal, "pullback", false],
      // After the fall the market remains permanently balanced around the new level.
      ["terminal-range", c.selloffEndAt, Infinity, terminal, terminal, "consolidation", true]
    ];
  } else {
    const first = listingPrice * (1 + c.firstGainPercent / 100);
    const second = listingPrice * (1 + c.secondGainPercent / 100);
    const third = listingPrice * (1 + c.thirdGainPercent / 100);
    terminal = third * (1 - c.selloffFraction);
    if (![first, second, third, terminal].every((p) => Number.isFinite(p) && p > 0)) throw new RangeError("Invalid scenario target");
    rows = [
      ["first-rise", c.from, c.firstTargetAt, anchor, first, "impulse", false],
      ["first-range", c.firstTargetAt, c.breakoutAt, first, first, "consolidation", true],
      ["second-rise", c.breakoutAt, c.secondTargetAt, first, second, "impulse", false],
      ["third-rise", c.secondTargetAt, c.thirdTargetAt, second, third, "impulse", false],
      ["second-range", c.thirdTargetAt, c.rangeEndAt, third, third, "consolidation", true],
      ["selloff", c.rangeEndAt, c.selloffEndAt, third, terminal, "pullback", false],
      ["final-range", c.selloffEndAt, c.endAt, terminal, terminal, "consolidation", true],
      ["terminal-range", c.endAt, Infinity, terminal, terminal, "consolidation", true]
    ];
  }
  const phases = rows.map(([name, from, to, open, close, regime, range]) => {
    const vertices = [{ at: from, price: open }];
    if (!range) {
      const random = seededRandom(seed, "scheduled-structure", c.version, name, from);
      const n = Math.max(6, Math.ceil((to - from) / (18 * MINUTE2)));
      const weights = Array.from({ length: n }, (_, i) => i > 0 && i < n - 1 && random() < 0.28 ? -(0.25 + random() * 0.65) : 0.3 + random() * 1.8);
      const sum = weights.reduce((a, b) => a + b, 0);
      if (sum <= 0.5) weights[n - 1] += 0.5 - sum;
      const total = weights.reduce((a, b) => a + b, 0);
      let progress2 = 0;
      for (let i = 1; i <= n; i++) {
        progress2 += weights[i - 1] / total;
        vertices.push({
          at: from + (to - from) * i / n,
          price: i === n ? close : open * Math.exp(Math.log(close / open) * progress2)
        });
      }
    } else vertices.push({ at: to, price: close });
    return { name, from, to, open, close, regime, range, vertices };
  });
  const out = { phases, terminal };
  contexts.set(key, out);
  if (contexts.size > 32) contexts.delete(contexts.keys().next().value);
  return out;
}
__name(context, "context");
function noise2(seed, label, at, interval) {
  const position = at / interval;
  const slot = Math.floor(position);
  const u = position - slot;
  const a = seededRandom(seed, label, slot)() * 2 - 1;
  const b = seededRandom(seed, label, slot + 1)() * 2 - 1;
  return a + (b - a) * u * u * (3 - 2 * u);
}
__name(noise2, "noise");
function excursion(seed, name, elapsed, range = false) {
  const window = 47 * MINUTE2;
  const slot = Math.floor(elapsed / window);
  const random = seededRandom(seed, "scheduled-excursion", name, slot);
  if (random() > 0.58) return 0;
  const start = (2 + random() * 22) * MINUTE2;
  const duration = (4 + random() * 13) * MINUTE2;
  const u = (elapsed - slot * window - start) / duration;
  if (u <= 0 || u >= 1) return 0;
  const down = random() < 0.76;
  let depth = 0.025 + random() * (down ? 0.105 : 0.06);
  const turn = 0.12 + random() * 0.24;
  if (range) {
    const large = random() < 0.24;
    depth = large ? down ? 0.18 + random() * 0.14 : 0.12 + random() * 0.08 : 0.025 + random() * 0.085;
  }
  const height = u < turn ? u / turn : (1 - u) / (1 - turn);
  return (down ? -1 : 1) * depth * Math.pow(height, 0.8);
}
__name(excursion, "excursion");
function phaseAt(ctx, at) {
  return ctx.phases.find((p) => at >= p.from && at < p.to);
}
__name(phaseAt, "phaseAt");
function priceAt2(c, seed, ctx, anchor, at) {
  if (at <= c.from) return anchor;
  const p = phaseAt(ctx, at);
  if (at === p.from) return p.open;
  const t = at - p.from;
  const envelope = Math.min(1, t / (8 * MINUTE2), (p.to - at) / (8 * MINUTE2));
  const label = `${c.version}:${p.name}:${p.from}`;
  const slow = noise2(seed, label + ":slow", t, 83 * MINUTE2);
  const medium = noise2(seed, label + ":medium", t, 17 * MINUTE2);
  const fast = noise2(seed, label + ":fast", t, 13e4);
  const shock = excursion(seed, label, t, p.range);
  if (p.range) {
    const width = c.rangeFraction * (0.35 + 0.65 * (noise2(seed, label + ":volatility", t, 167 * MINUTE2) + 1) / 2);
    const centre = c.rangeFraction * 0.2 * noise2(seed, label + ":centre", t, 263 * MINUTE2);
    const base = 0.78 * slow + 0.17 * medium + 0.05 * fast;
    const displacement = centre + Math.log1p(width * base) + shock * (c.rangeFraction / 0.2);
    return p.open * Math.exp(envelope * displacement);
  }
  const i = Math.min(
    p.vertices.length - 2,
    Math.floor(t / (p.to - p.from) * (p.vertices.length - 1))
  );
  const a = p.vertices[i], b = p.vertices[i + 1];
  const u = (at - a.at) / (b.at - a.at);
  const baseline2 = a.price * Math.exp(Math.log(b.price / a.price) * u);
  const micro = noise2(seed, label + ":micro", t, 37e3);
  const minuteMove = Math.abs(Math.log(b.price / a.price)) * MINUTE2 / (b.at - a.at);
  const fastAmplitude = Math.min(0.09, Math.max(0.028, minuteMove * 6));
  return baseline2 * Math.exp(envelope * (0.026 * medium + fastAmplitude * fast + fastAmplitude * 0.45 * micro + shock));
}
__name(priceAt2, "priceAt");
function scheduledScenarioHour(c, seed, listingAt, initialPrice, hour, anchorPrice, originalOpen, original) {
  if (!Number.isSafeInteger(hour) || hour < 0 || original.length !== 360) throw new RangeError("A scenario needs one complete canonical hour");
  if (c.mode === "scenario-controls-v2") {
    validateScheduledScenario(c, listingAt);
    return controlledScenarioHour(c, seed, hour);
  }
  const ctx = context(c, seed, listingAt, initialPrice, anchorPrice);
  const start = listingAt + hour * HOUR2;
  const cap = c.mode === "capped-growth-range" ? initialPrice * (1 + c.maxGainPercent / 100) : Infinity;
  const open = Math.min(cap, start <= c.from ? originalOpen : priceAt2(c, seed, ctx, anchorPrice, start));
  const ticks = [];
  let previous = open;
  for (let i = 0; i < 360; i++) {
    const at = start + (i + 1) * TICK2;
    if (at <= c.from) {
      ticks.push(original[i]);
      previous = original[i].price;
      continue;
    }
    const price = Math.min(cap, priceAt2(c, seed, ctx, anchorPrice, at));
    const p = phaseAt(ctx, at - 1);
    const random = seededRandom(seed, "scheduled-tick", c.version, at);
    const move = Math.abs(Math.log(price / previous));
    const shadow = (1e-4 + random() * 9e-4) * (1 + Math.min(4, move * 45));
    const endpointEnvelope = p ? Math.min(1, (at - p.from) / MINUTE2, (p.to - at) / MINUTE2) : 0;
    const longWick = random() < 0.035 ? 2e-3 + random() * 0.01 : 0;
    let high = Math.max(previous, price) * (1 + (shadow * random() + longWick * random()) * endpointEnvelope);
    let low = Math.min(previous, price) * (1 - (shadow * random() + longWick * random()) * endpointEnvelope);
    high = Math.min(cap, high);
    const activity = p?.range ? 0.68 : p?.regime === "pullback" ? 1.45 : 1.15;
    const quoteVolume = (25 + random() * 190) * activity * (1 + Math.min(12, 140 * move));
    const volume = quoteVolume / ((previous + price) / 2);
    ticks.push({ price, high, low, volume, quoteVolume });
    previous = price;
  }
  return { open, ticks, regime: phaseAt(ctx, start + HOUR2 / 2)?.regime ?? "consolidation" };
}
__name(scheduledScenarioHour, "scheduledScenarioHour");

// ../../src/services/testMarkets/simulationRealism.ts
var SIMULATION_PROFILES = ["CALM_TREND", "IMPULSE_TREND", "PULLBACK_TREND", "COMPRESSION_BREAKOUT"];
function isSimulationProfile(value) {
  return typeof value === "string" && SIMULATION_PROFILES.includes(value);
}
__name(isSimulationProfile, "isSimulationProfile");
function profileForOrdinal(ordinal) {
  if (!Number.isSafeInteger(ordinal) || ordinal < 0) throw new RangeError("ordinal must be a non-negative integer");
  return SIMULATION_PROFILES[ordinal % SIMULATION_PROFILES.length];
}
__name(profileForOrdinal, "profileForOrdinal");
var profile = /* @__PURE__ */ __name((params) => Object.freeze(params), "profile");
var REALISM_PROFILES = Object.freeze({
  /** Smooth trend: small and medium candles, short shadows, rare impulses, short pauses. */
  CALM_TREND: profile({
    trendPatterns: { steady: 0.72, burst: 0.14, pullback: 0.08, compression: 0.06 },
    counterPatterns: { steady: 0.8, burst: 0.1, pullback: 0.1, compression: 0 },
    breakoutAfterRange: 0.15,
    impulseShare: [0.22, 0.34],
    impulseEarliestSlot: 2,
    pullbackDepth: [0.1, 0.22],
    pullbackLength: [2, 3],
    compressionDuration: [4, 6],
    compressionNoise: 0.6,
    breakoutShare: [0.28, 0.42],
    bodyNoise: 0.75,
    rangeNoise: 0.3,
    bodyVariety: 0.3,
    shadowSize: [0.1, 0.4],
    shadowChance: 0.4,
    longWickChance: 0.05,
    rejectionChance: 0.03,
    sweepChance: 0.03,
    afterImpulseWickChance: 0.2,
    wickSizeFactor: 0.55,
    tickWickFactor: 0.3,
    maxWick: 0.06,
    localVolatilityFactor: 0.2,
    tailChance: 0.03,
    tailFactor: 1.6
  }),
  /** Strong trend candles: a few ordinary bars, then an impulse; consolidation → breakout; occasional big wicks. */
  IMPULSE_TREND: profile({
    trendPatterns: { steady: 0.1, burst: 0.42, pullback: 0.23, compression: 0.25 },
    counterPatterns: { steady: 0.35, burst: 0.35, pullback: 0.2, compression: 0.1 },
    breakoutAfterRange: 0.55,
    impulseShare: [0.38, 0.62],
    impulseEarliestSlot: 3,
    pullbackDepth: [0.18, 0.35],
    pullbackLength: [2, 3],
    compressionDuration: [4, 7],
    compressionNoise: 0.4,
    breakoutShare: [0.45, 0.65],
    bodyNoise: 0.9,
    rangeNoise: 0.6,
    bodyVariety: 0.75,
    shadowSize: [0.3, 1.1],
    shadowChance: 0.7,
    longWickChance: 0.22,
    rejectionChance: 0.1,
    sweepChance: 0.15,
    afterImpulseWickChance: 0.6,
    wickSizeFactor: 1.35,
    tickWickFactor: 0.45,
    maxWick: 0.11,
    localVolatilityFactor: 0.4,
    tailChance: 0.07,
    tailFactor: 2.2
  }),
  /** The trend holds, but through short counter-trend runs, false breakouts, rejections and long shadows. */
  PULLBACK_TREND: profile({
    trendPatterns: { steady: 0.12, burst: 0.16, pullback: 0.6, compression: 0.12 },
    counterPatterns: { steady: 0.35, burst: 0.25, pullback: 0.35, compression: 0.05 },
    breakoutAfterRange: 0.25,
    impulseShare: [0.3, 0.5],
    impulseEarliestSlot: 2,
    pullbackDepth: [0.25, 0.5],
    pullbackLength: [2, 4],
    compressionDuration: [4, 6],
    compressionNoise: 0.5,
    breakoutShare: [0.35, 0.55],
    bodyNoise: 1,
    rangeNoise: 0.7,
    bodyVariety: 0.5,
    shadowSize: [0.3, 1.2],
    shadowChance: 0.75,
    longWickChance: 0.28,
    rejectionChance: 0.16,
    sweepChance: 0.1,
    afterImpulseWickChance: 0.45,
    wickSizeFactor: 1.5,
    tickWickFactor: 0.5,
    maxWick: 0.13,
    localVolatilityFactor: 0.35,
    tailChance: 0.06,
    tailFactor: 2
  }),
  /** Narrow ranges with small bodies and local wick sweeps, then a strong breakout and a short settle. */
  COMPRESSION_BREAKOUT: profile({
    trendPatterns: { steady: 0.12, burst: 0.18, pullback: 0.08, compression: 0.62 },
    counterPatterns: { steady: 0.4, burst: 0.2, pullback: 0.1, compression: 0.3 },
    breakoutAfterRange: 0.7,
    impulseShare: [0.4, 0.6],
    impulseEarliestSlot: 4,
    pullbackDepth: [0.12, 0.25],
    pullbackLength: [2, 3],
    compressionDuration: [6, 9],
    compressionNoise: 0.28,
    breakoutShare: [0.5, 0.72],
    bodyNoise: 0.8,
    rangeNoise: 0.12,
    bodyVariety: 0.5,
    shadowSize: [0.15, 0.6],
    shadowChance: 0.45,
    longWickChance: 0.08,
    rejectionChance: 0.05,
    sweepChance: 0.3,
    afterImpulseWickChance: 0.3,
    wickSizeFactor: 0.9,
    tickWickFactor: 0.4,
    maxWick: 0.09,
    localVolatilityFactor: 0.3,
    tailChance: 0.04,
    tailFactor: 1.8
  })
});
var CANDLES = 12;
var TICKS = 30;
var KIND_WEIGHT = {
  normal: 1,
  impulse: 1,
  counter: 1,
  coil: 1,
  stabilize: 0.35,
  pinUp: 0.18,
  pinDown: 0.18,
  doji: 0.12
};
var KIND_VOLUME = {
  normal: [0.9, 1.1],
  impulse: [1.5, 2.3],
  counter: [1, 1.2],
  coil: [0.5, 0.6],
  stabilize: [0.8, 0.9],
  pinUp: [1.15, 1.35],
  pinDown: [1.15, 1.35],
  doji: [0.75, 0.85]
};
var lerp = /* @__PURE__ */ __name(([a, b], t) => a + (b - a) * t, "lerp");
var integer = /* @__PURE__ */ __name((random, [low, high]) => Math.round(low) + Math.floor(random() * (Math.round(high) - Math.round(low) + 1)), "integer");
function pick(weights, u) {
  const entries = Object.entries(weights);
  const total = entries.reduce((sum, [, w]) => sum + w, 0);
  let acc = 0;
  for (const [key, w] of entries) {
    acc += w / total;
    if (u < acc) return key;
  }
  return entries[entries.length - 1][0];
}
__name(pick, "pick");
function breaksOut(seed, offset, hour, params) {
  return seededRandom(seed, "realism", offset, "breakout", hour)() < params.breakoutAfterRange;
}
__name(breaksOut, "breaksOut");
function realisticHour(ctx) {
  const { seed, offset, hour, regime, logReturn, sigma, params: P } = ctx;
  const random = seededRandom(seed, "realism", offset, "hour", hour);
  const dir = logReturn >= 0 ? 1 : -1;
  const kinds = Array(CANDLES).fill("normal");
  const share = Array(CANDLES).fill(0);
  const boost = Array(CANDLES).fill(1);
  const quiet = Array(CANDLES).fill(1);
  const slots = [...Array(CANDLES).keys()];
  const spread = /* @__PURE__ */ __name((targets, total) => {
    if (!targets.length) return;
    const g = targets.map((slot) => KIND_WEIGHT[kinds[slot]] * boost[slot] * ((1 - P.bodyVariety) * (0.45 + random() * 1.1) + P.bodyVariety * -Math.log(1 - 0.995 * random())));
    const sum = g.reduce((a, b) => a + b, 0);
    targets.forEach((slot, i) => {
      share[slot] += total * g[i] / sum;
    });
  }, "spread");
  const markRejections = /* @__PURE__ */ __name((targets, dojiChance = 0) => {
    for (const slot of targets) {
      if (kinds[slot] !== "normal") continue;
      const u2 = random();
      if (u2 < P.rejectionChance) kinds[slot] = random() < 0.5 ? "pinUp" : "pinDown";
      else if (u2 < P.rejectionChance + dojiChance) kinds[slot] = "doji";
    }
  }, "markRejections");
  const settleAfter = /* @__PURE__ */ __name((from, count) => {
    for (let s = from; s < Math.min(CANDLES, from + count); s++) kinds[s] = "stabilize";
    if (from < CANDLES && random() < P.afterImpulseWickChance) kinds[from] = dir > 0 ? "pinUp" : "pinDown";
  }, "settleAfter");
  let pattern;
  const u = random();
  if (regime === "consolidation") {
    pattern = ctx.nextRegime === "impulse" && breaksOut(seed, offset, hour + 1, P) ? "coil" : "range";
  } else if (regime === "impulse" && ctx.previousRegime === "consolidation" && breaksOut(seed, offset, hour, P)) {
    pattern = "breakout";
  } else {
    pattern = pick(regime === "impulse" ? P.trendPatterns : P.counterPatterns, u);
  }
  switch (pattern) {
    case "steady": {
      markRejections(slots);
      spread(slots, 1);
      break;
    }
    case "burst": {
      const two = random() < 0.2;
      const last = CANDLES - (two ? 3 : 2);
      const at = integer(random, [Math.min(P.impulseEarliestSlot, last), last]);
      const impulse = lerp(P.impulseShare, random());
      kinds[at] = "impulse";
      share[at] = two ? 0.7 * impulse : impulse;
      if (two) {
        kinds[at + 1] = "impulse";
        share[at + 1] = 0.3 * impulse;
      }
      for (let s = 0; s < at; s++) quiet[s] = 0.8;
      const after = at + (two ? 2 : 1);
      if (after < CANDLES && random() < P.afterImpulseWickChance) kinds[after] = dir > 0 ? "pinUp" : "pinDown";
      const others = slots.filter((s) => kinds[s] !== "impulse");
      markRejections(others);
      spread(others, 1 - impulse);
      break;
    }
    case "pullback": {
      const length = integer(random, P.pullbackLength);
      const start = integer(random, [2, CANDLES - length - 2]);
      const depth = lerp(P.pullbackDepth, random());
      const run = slots.slice(start, start + length);
      run.forEach((s) => {
        kinds[s] = "counter";
      });
      if (random() < Math.min(0.9, 0.2 + 3 * P.rejectionChance)) kinds[start - 1] = dir > 0 ? "pinUp" : "pinDown";
      const end = start + length;
      if (random() < 0.55) kinds[end] = dir > 0 ? "pinDown" : "pinUp";
      const resume = kinds[end] === "normal" ? end : end + 1;
      if (resume < CANDLES) boost[resume] = 1.8;
      const others = slots.filter((s) => kinds[s] !== "counter");
      markRejections(others);
      spread(run, -depth);
      spread(others, 1 + depth);
      break;
    }
    case "compression": {
      const coil = Math.min(integer(random, P.compressionDuration), CANDLES - 3);
      for (let s = 0; s < coil; s++) {
        kinds[s] = "coil";
        quiet[s] = P.compressionNoise * (1 - 0.55 * s / coil);
      }
      kinds[coil] = "impulse";
      settleAfter(coil + 1, integer(random, [1, 2]));
      const drift = lerp([0, 0.1], random());
      const breakout = lerp(P.breakoutShare, random());
      share[coil] = breakout;
      spread(slots.slice(0, coil), drift);
      const rest = slots.slice(coil + 1);
      markRejections(rest);
      spread(rest, 1 - drift - breakout);
      break;
    }
    case "breakout": {
      const at = random() < 0.7 ? 0 : 1;
      if (at === 1) {
        kinds[0] = "coil";
        quiet[0] = P.compressionNoise * 0.5;
      }
      kinds[at] = "impulse";
      settleAfter(at + 1, integer(random, [1, 2]));
      const breakout = lerp(P.breakoutShare, random());
      share[at] = breakout;
      if (at === 1) spread([0], 0.02);
      const rest = slots.slice(at + 1);
      markRejections(rest);
      spread(rest, 1 - breakout - (at === 1 ? 0.02 : 0));
      break;
    }
    case "range":
    case "coil": {
      markRejections(slots, P.longWickChance);
      if (pattern === "coil") {
        for (let s = 0; s < CANDLES; s++) quiet[s] = 1 - 0.65 * s / (CANDLES - 1);
        for (let s = 5; s < CANDLES; s++) if (kinds[s] === "normal") kinds[s] = "coil";
      }
      spread(slots, 1);
      break;
    }
  }
  const unit = regime === "consolidation" ? Math.max(0.8 * sigma, ctx.trendStep * P.rangeNoise) : sigma;
  const base = regime === "consolidation" ? 1 : P.bodyNoise;
  let level = normal(random);
  const scale = kinds.map((kind, k) => {
    if (k > 0) level = 0.65 * level + 0.76 * normal(random);
    const clustered = Math.max(-2, Math.min(2, level));
    const local = Math.exp(P.localVolatilityFactor * clustered - P.localVolatilityFactor * P.localVolatilityFactor / 2);
    const own = kind === "impulse" ? 0.3 : kind === "pinUp" || kind === "pinDown" || kind === "doji" ? 0.3 : kind === "coil" ? regime === "consolidation" ? base : 1 : kind === "stabilize" ? 0.5 * base : kind === "counter" ? 0.6 * base : base * (0.7 + 0.6 * random());
    return unit * own * quiet[k] * local;
  });
  const noise3 = scale.map((s) => s * normal(random) * (random() < P.tailChance ? P.tailFactor : 1));
  const scaleSum = scale.reduce((a, b) => a + b, 0);
  const noiseSum = noise3.reduce((a, b) => a + b, 0);
  for (let k = 0; k < CANDLES; k++) noise3[k] -= noiseSum * scale[k] / scaleSum;
  let walk = 0, farthest = 0;
  for (const n of noise3) {
    walk += n;
    farthest = Math.max(farthest, Math.abs(walk));
  }
  const limit = Math.max(0.3 * Math.abs(logReturn), 3 * unit);
  if (farthest > limit) for (let k = 0; k < CANDLES; k++) noise3[k] *= limit / farthest;
  const steps = share.map((w, k) => logReturn * w + noise3[k]);
  const cap = Math.min(P.maxWick, 4 * unit);
  const timing = /* @__PURE__ */ __name((style) => {
    const rise = style === "wick" ? integer(random, [3, 7]) : style === "sharp" ? integer(random, [1, 2]) : integer(random, [2, 3]);
    const fall = style === "wick" ? integer(random, [2, 5]) : style === "sharp" ? integer(random, [1, 2]) : integer(random, [2, 3]);
    const [low, high] = style === "late" ? [22, 26] : style === "sharp" ? [3, 26] : [5, 24];
    const peak = Math.max(rise, Math.min(TICKS - 1 - fall, integer(random, [low, high])));
    return { peak, rise, fall };
  }, "timing");
  const shapes = kinds.map((kind, k) => {
    const body = Math.abs(steps[k]);
    const own = Math.max(body, scale[k], 0.3 * unit);
    const excursions = [];
    const wick = /* @__PURE__ */ __name((side, height, style) => {
      excursions.push({ side, height: Math.min(cap, height), ...timing(style) });
    }, "wick");
    if (kind === "pinUp" || kind === "pinDown") {
      wick(kind === "pinUp" ? 1 : -1, P.wickSizeFactor * unit * lerp([1.2, 2.6], random()), "wick");
    } else if (kind === "doji") {
      const size = Math.max(own, 0.5 * unit) * P.wickSizeFactor;
      wick(1, size * lerp([0.8, 1.6], random()), "wick");
      wick(-1, size * lerp([0.8, 1.6], random()), "wick");
    } else if (kind === "impulse") {
      if (random() < 0.35) wick(steps[k] >= 0 ? 1 : -1, body * lerp([0.08, 0.3], random()), "late");
    } else {
      const u2 = random();
      const sweep = kind === "coil" ? P.sweepChance : regime === "consolidation" ? 0.5 * P.sweepChance : 0;
      if (u2 < sweep) {
        wick(random() < 0.5 ? 1 : -1, P.wickSizeFactor * unit * lerp([0.5, 1.2], random()), "sharp");
      } else if (u2 < sweep + P.longWickChance) {
        wick(random() < 0.5 ? 1 : -1, P.wickSizeFactor * own * lerp([1, 2.4], random()), "wick");
      } else if (u2 < sweep + P.longWickChance + P.shadowChance) {
        wick(random() < 0.5 ? 1 : -1, own * lerp(P.shadowSize, random()), "wick");
      }
    }
    const reach = excursions.reduce((sum, e) => sum + e.height, 0);
    return {
      kind,
      scale: scale[k],
      intrabar: kind === "impulse" ? 0.5 : kind === "coil" ? 0.8 : 1,
      volume: lerp(KIND_VOLUME[kind], random()) * (1 + 6 * reach),
      excursions
    };
  });
  return { pattern, steps, shapes };
}
__name(realisticHour, "realisticHour");
function excursionAt(excursions, i) {
  let lift = 0;
  for (const e of excursions) {
    const reach = i <= e.peak ? 1 - (e.peak - i) / e.rise : 1 - (i - e.peak) / e.fall;
    if (reach > 0) lift += e.side * e.height * reach;
  }
  return lift;
}
__name(excursionAt, "excursionAt");
function realisticTicks(seed, offset, hour, slot, open, close, shape, cluster, volumeBase, { tickWickFactor, maxWick }) {
  const random = seededRandom(seed, "realism", offset, "ticks", hour, slot);
  const total = Math.log(close / open);
  const tickSigma = shape.scale / Math.sqrt(TICKS) * 1.2 * shape.intrabar;
  const steps = [];
  for (let i = 0; i < TICKS; i++) steps.push(total / TICKS + tickSigma * normal(random));
  const drift = (steps.reduce((a, b) => a + b, 0) - total) / TICKS;
  const quote = volumeBase * (1 + 18 * Math.abs(total) + 0.6 * (cluster - 1)) * shape.volume * Math.exp(0.35 * normal(random));
  const weights = steps.map((step, i) => Math.exp(0.5 * normal(random)) * (1 + 40 * Math.abs(step - drift + excursionAt(shape.excursions, i + 1) - excursionAt(shape.excursions, i))));
  const weightSum = weights.reduce((a, b) => a + b, 0);
  const ceiling = Math.max(open, close) * Math.exp(maxWick);
  const floor = Math.min(open, close) * Math.exp(-maxWick);
  const ticks = [];
  let bridge = 0;
  let previous = open;
  for (let i = 0; i < TICKS; i++) {
    bridge += steps[i] - drift;
    const price = i === TICKS - 1 ? close : Math.min(ceiling, Math.max(floor, Math.exp(Math.log(open) + bridge + excursionAt(shape.excursions, i + 1))));
    const shadow = tickSigma * tickWickFactor;
    const high = Math.min(ceiling, Math.max(previous, price) * Math.exp(Math.abs(normal(random)) * shadow * (random() < 0.03 ? 3 : 1)));
    const low = Math.max(floor, Math.min(previous, price) * Math.exp(-Math.abs(normal(random)) * shadow * (random() < 0.03 ? 3 : 1)));
    const quoteVolume = quote * weights[i] / weightSum;
    ticks.push({ price, high, low, quoteVolume, volume: quoteVolume / ((previous + price) / 2) });
    previous = price;
  }
  return ticks;
}
__name(realisticTicks, "realisticTicks");

// ../../src/services/testMarkets/simulationWaves.ts
var integer2 = /* @__PURE__ */ __name((random, low, high) => low + Math.floor(random() * (high - low + 1)), "integer");
var between = /* @__PURE__ */ __name((random, low, high) => low + (high - low) * random(), "between");
function nextLeg(random, previous, impulsesSinceRest) {
  if (previous === "impulse") {
    if (impulsesSinceRest < 2 && random() < 0.25) return { kind: "pause", hours: integer2(random, 1, 2) };
    return random() < 0.6 ? { kind: "correction", hours: integer2(random, 4, 7) } : { kind: "accumulation", hours: integer2(random, 4, 7) };
  }
  if (previous === "correction") {
    return random() < 0.45 ? { kind: "accumulation", hours: integer2(random, 3, 6) } : { kind: "impulse", hours: integer2(random, 2, 5) };
  }
  return { kind: "impulse", hours: integer2(random, 2, 5) };
}
__name(nextLeg, "nextLeg");
function legsFor(random, length, launch) {
  const legs = [];
  let used = 0;
  let impulses = 0;
  if (launch) {
    legs.push({ kind: "impulse", hours: Math.min(length, 3) });
    used = legs[0].hours;
    impulses = 1;
  }
  const u = random();
  const opening = u < 0.4 ? "accumulation" : u < 0.7 ? "impulse" : "correction";
  while (used < length) {
    const leg = nextLeg(random, legs.length ? legs[legs.length - 1].kind : opening, impulses);
    if (leg.kind === "impulse") impulses += 1;
    if (leg.kind === "correction" || leg.kind === "accumulation") impulses = 0;
    leg.hours = Math.min(leg.hours, length - used);
    legs.push(leg);
    used += leg.hours;
  }
  return legs;
}
__name(legsFor, "legsFor");
var legCurve = /* @__PURE__ */ __name((i, n) => n <= 2 ? 1 : 0.7 + 0.6 * Math.sin(Math.PI * (i + 0.5) / n), "legCurve");
function impulseProfile(random) {
  const u = random();
  return u < 0.65 ? "IMPULSE_TREND" : u < 0.9 ? "PULLBACK_TREND" : "COMPRESSION_BREAKOUT";
}
__name(impulseProfile, "impulseProfile");
function waveHours(seed, blockIndex, start, length, total) {
  if (length <= 0) return [];
  const random = seededRandom(seed, "waves", blockIndex, start);
  const launch = blockIndex === 0 && start === 0;
  const legs = legsFor(random, length, launch);
  const drafts = [];
  const share = [];
  const caps = [];
  let lastLegGain = 1;
  legs.forEach((leg, legIndex) => {
    const n = leg.hours;
    if (leg.kind === "impulse") {
      const isLaunch = launch && legIndex === 0;
      const dipAt = isLaunch ? 1 : n >= 4 || n === 3 && random() < 0.4 ? integer2(random, 1, n - 2) : -1;
      const weights = Array.from({ length: n }, (_, i) => legCurve(i, n) * Math.exp(0.35 * normal(random)) * (isLaunch && i === 0 ? 1.4 : 1));
      const gain = weights.reduce((a, b) => a + b, 0);
      const breakout = !isLaunch && legIndex > 0 && legs[legIndex - 1].kind === "accumulation";
      for (let i = 0; i < n; i++) {
        const isDip = i === dipAt;
        const phase = isLaunch ? "launch" : isDip ? "dip" : i === 0 && breakout ? "breakout" : "impulse";
        drafts.push({
          phase,
          regime: isDip ? "pullback" : "impulse",
          leg: legIndex,
          fixed: 0,
          up: isDip ? 0 : weights[i],
          profile: isLaunch ? "PULLBACK_TREND" : isDip ? "PULLBACK_TREND" : phase === "breakout" ? "COMPRESSION_BREAKOUT" : impulseProfile(random),
          // Trending hours are wide enough that their 15m candles pause and dip, not climb a ladder.
          volatility: isLaunch ? [2.2, 1.9, 1.7][i] ?? 1.6 : phase === "breakout" ? 1.6 : isDip ? 1.2 : between(random, 1.5, 2.1),
          volume: isLaunch ? [1.9, 1.5, 1.3][i] ?? 1.2 : phase === "breakout" ? 2.1 : isDip ? 1.15 : 1.05 + 0.25 * legCurve(i, n),
          flush: isDip && random() < 0.55,
          exhaustion: !isDip && (i === n - 1 || isLaunch && i === 0) && random() < 0.75
        });
        share.push(isDip ? -between(random, 0.15, 0.35) * (gain / n) * (isLaunch ? 1.4 : 1) : 0);
        caps.push(between(random, 0.05, 0.12));
      }
      lastLegGain = gain;
    } else if (leg.kind === "correction" || leg.kind === "pause") {
      const depth = leg.kind === "pause" ? between(random, 0.1, 0.22) : between(random, 0.3, 0.55);
      const cap = leg.kind === "pause" ? between(random, 0.04, 0.12) : between(random, 0.15, 0.45);
      const bounceAt = n >= 3 && random() < (n >= 5 ? 0.75 : 0.5) ? integer2(random, 1, n - 1) : -1;
      const weights = Array.from({ length: n }, (_, i) => i === bounceAt ? 0 : Math.exp(0.4 * normal(random)));
      const sum = weights.reduce((a, b) => a + b, 0) || 1;
      const flushAt = integer2(random, 0, n - 1);
      for (let i = 0; i < n; i++) {
        const isBounce = i === bounceAt;
        drafts.push({
          phase: isBounce ? "bounce" : leg.kind === "pause" ? "dip" : "correction",
          regime: isBounce ? "impulse" : "pullback",
          leg: legIndex,
          up: 0,
          fixed: 0,
          profile: "PULLBACK_TREND",
          volatility: isBounce ? 1 : 1.1,
          volume: isBounce ? 0.95 : 1.2,
          flush: !isBounce && (i === flushAt || random() < 0.2),
          exhaustion: isBounce && random() < 0.5
        });
        share.push(isBounce ? between(random, 0.15, 0.35) * depth * lastLegGain : -(depth * lastLegGain * weights[i]) / sum);
        caps.push(cap);
      }
    } else {
      const drift = between(random, -7e-3, 6e-3);
      for (let i = 0; i < n; i++) {
        const coil = i >= n - 2;
        const takeProfit = i === 0 && legIndex > 0 && legs[legIndex - 1].kind === "impulse";
        drafts.push({
          phase: "accumulation",
          regime: "consolidation",
          leg: legIndex,
          up: 0,
          fixed: takeProfit ? -between(random, 0.01, 0.035) : coil ? between(random, -8e-3, 8e-3) : drift + between(random, 0.012, 0.04) * (random() < 0.5 ? -1 : 1),
          profile: coil ? "COMPRESSION_BREAKOUT" : "PULLBACK_TREND",
          volatility: 0.9,
          volume: 0.6 + 0.2 * random(),
          flush: random() < 0.12,
          exhaustion: false
        });
        share.push(0);
        caps.push(0);
      }
    }
  });
  const sumUp = drafts.reduce((a, d) => a + d.up, 0);
  const sumShare = share.reduce((a, b) => a + b, 0);
  const sumRange = drafts.reduce((a, d) => a + d.fixed, 0);
  const impulseHours = drafts.filter((d) => d.up > 0).length || 1;
  const minUnit = 0.02 * impulseHours / Math.max(sumUp, 1e-9);
  const unit1 = sumUp + sumShare > 0 ? Math.max(minUnit, (total - sumRange) / (sumUp + sumShare)) : minUnit;
  const legTotals = /* @__PURE__ */ new Map();
  drafts.forEach((d, i) => {
    if (share[i] < 0) legTotals.set(d.leg, (legTotals.get(d.leg) ?? 0) + share[i] * unit1);
  });
  drafts.forEach((d, i) => {
    if (share[i] === 0) return;
    const legTotal = legTotals.get(d.leg) ?? 0;
    const cap = Math.log(1 - caps[i]);
    const scale = share[i] < 0 && legTotal < cap ? cap / legTotal : 1;
    d.fixed += share[i] * unit1 * scale;
  });
  const fixed = drafts.reduce((a, d) => a + d.fixed, 0);
  let unit = sumUp > 0 ? (total - fixed) / sumUp : 0;
  if (unit < minUnit && sumUp > 0) {
    const giveBack = drafts.reduce((a, d) => a + Math.min(0, d.fixed), 0);
    const extra = total - fixed - minUnit * sumUp;
    if (giveBack < 0 && extra < 0 && extra / giveBack <= 6) {
      const deepen = 1 + extra / giveBack;
      drafts.forEach((d) => {
        if (d.fixed < 0) d.fixed *= deepen;
      });
      unit = minUnit;
    }
  }
  const raw = drafts.map((d) => unit * d.up + d.fixed);
  const rising = raw.map((value, i) => drafts[i].up > 0 ? i : -1).filter((i) => i >= 0);
  if (rising.length > 1) {
    const cap = 1.8 * rising.reduce((sum, i) => sum + Math.max(raw[i], 0), 0) / rising.length;
    for (let pass = 0; pass < 6; pass++) {
      let excess = 0;
      for (const i of rising) if (raw[i] > cap) {
        excess += raw[i] - cap;
        raw[i] = cap;
      }
      const room = rising.filter((i) => raw[i] < cap);
      const roomSum = room.reduce((sum, i) => sum + Math.max(raw[i], 1e-9), 0);
      if (excess <= 0 || !room.length) break;
      for (const i of room) raw[i] += excess * Math.max(raw[i], 1e-9) / roomSum;
    }
  }
  const error = raw.reduce((a, b) => a + b, 0) - total;
  const weight = raw.reduce((sum, value) => sum + Math.abs(value), 0) || 1;
  const trendStep = Math.max(4e-3, unit * sumUp / impulseHours / 12);
  return drafts.map(({ up: _up, fixed: _fixed, leg: _leg, ...hour }, i) => ({
    ...hour,
    trendStep,
    logReturn: raw[i] - error * Math.abs(raw[i]) / weight
  }));
}
__name(waveHours, "waveHours");
var BUCKET = 3;
function pauseInsideHour(seed, hour, wave, steps, aligned) {
  const out = steps.slice();
  const total = out.reduce((a, b) => a + b, 0);
  if (!aligned || out.length !== 4 * BUCKET || wave.regime !== "impulse" || total <= 0.02) return out;
  const random = seededRandom(seed, "waves", "pause", hour);
  if (random() < 0.22) return capCandles(out, out.map((_, slot) => slot), total);
  const buckets = [1, 2, 3];
  const first = buckets[Math.floor(random() * buckets.length)];
  const chosen = /* @__PURE__ */ new Set([first]);
  if (total > 0.25 && random() < 0.25) chosen.add(buckets.filter((b) => b !== first)[Math.floor(random() * 2)]);
  let removed = 0;
  for (const bucket of chosen) {
    const slots = [0, 1, 2].map((i) => bucket * BUCKET + i);
    const sum = slots.reduce((a, slot) => a + out[slot], 0);
    const target = total * between(random, -0.07, -0.01);
    const delta = target - sum;
    const weights2 = slots.map(() => 0.4 + random());
    const weightSum2 = weights2.reduce((a, b) => a + b, 0);
    slots.forEach((slot, i) => {
      out[slot] += delta * weights2[i] / weightSum2;
    });
    removed -= delta;
  }
  const others = out.map((_, slot) => slot).filter((slot) => !chosen.has(Math.floor(slot / BUCKET)));
  const weights = others.map((slot) => Math.sqrt(Math.max(out[slot], 0)) + 0.25 * Math.sqrt(Math.abs(total) / out.length));
  const weightSum = weights.reduce((a, b) => a + b, 0);
  others.forEach((slot, i) => {
    out[slot] += removed * weights[i] / weightSum;
  });
  return capCandles(out, others, total);
}
__name(pauseInsideHour, "pauseInsideHour");
function capCandles(steps, slots, total) {
  const spread = /* @__PURE__ */ __name((excess, targets) => {
    if (excess <= 0 || !targets.length) return;
    const weights = targets.map((slot) => Math.max(steps[slot], 0) + 0.02 * total);
    const weightSum = weights.reduce((a, b) => a + b, 0);
    targets.forEach((slot, i) => {
      steps[slot] += excess * weights[i] / weightSum;
    });
  }, "spread");
  const candleCap = 0.35 * total, bucketCap = 0.5 * total;
  const bucketOf = /* @__PURE__ */ __name((slot) => Math.floor(slot / BUCKET), "bucketOf");
  for (let pass = 0; pass < 8; pass++) {
    let changed = false;
    let excess = 0;
    for (const slot of slots) if (steps[slot] > candleCap) {
      excess += steps[slot] - candleCap;
      steps[slot] = candleCap;
      changed = true;
    }
    spread(excess, slots.filter((slot) => steps[slot] < candleCap));
    for (let bucket = 0; bucket < steps.length / BUCKET; bucket++) {
      const members = slots.filter((slot) => bucketOf(slot) === bucket);
      const sum = members.reduce((a, slot) => a + steps[slot], 0);
      if (sum <= bucketCap) continue;
      const rising = members.filter((slot) => steps[slot] > 0);
      const risingSum = rising.reduce((a, slot) => a + steps[slot], 0);
      const cut = sum - bucketCap;
      rising.forEach((slot) => {
        steps[slot] -= cut * steps[slot] / risingSum;
      });
      spread(cut, slots.filter((slot) => bucketOf(slot) !== bucket));
      changed = true;
    }
    if (!changed) break;
  }
  return steps;
}
__name(capCandles, "capCandles");

// ../../src/services/testMarkets/simulationCycles.ts
var CYCLIC_IMPULSE_PRESETS = Object.freeze([
  { name: "deep-flush", dropFraction: 0.4, recoveryFraction: 0.5, lowAt: 0.24, reboundAt: 0.59, retestDepth: 0.28, upperWickFraction: 0.11, peakAt: 0.68 },
  { name: "fast-rejection", dropFraction: 0.28, recoveryFraction: 0.4, lowAt: 0.18, reboundAt: 0.52, retestDepth: 0.18, upperWickFraction: 0.07, peakAt: 0.57 },
  { name: "double-dip", dropFraction: 0.32, recoveryFraction: 0.55, lowAt: 0.29, reboundAt: 0.55, retestDepth: 0.44, upperWickFraction: 0.14, peakAt: 0.74 },
  { name: "late-flush", dropFraction: 0.38, recoveryFraction: 0.35, lowAt: 0.43, reboundAt: 0.69, retestDepth: 0.22, upperWickFraction: 0.09, peakAt: 0.63 },
  { name: "shallow-grind", dropFraction: 0.24, recoveryFraction: 0.3, lowAt: 0.36, reboundAt: 0.64, retestDepth: 0.34, upperWickFraction: 0.06, peakAt: 0.8 },
  { name: "capitulation-rebound", dropFraction: 0.45, recoveryFraction: 0.6, lowAt: 0.21, reboundAt: 0.62, retestDepth: 0.19, upperWickFraction: 0.18, peakAt: 0.71 },
  { name: "stepped-recovery", dropFraction: 0.35, recoveryFraction: 0.45, lowAt: 0.33, reboundAt: 0.58, retestDepth: 0.38, upperWickFraction: 0.12, peakAt: 0.6 },
  { name: "deep-retest", dropFraction: 0.42, recoveryFraction: 0.25, lowAt: 0.27, reboundAt: 0.53, retestDepth: 0.46, upperWickFraction: 0.16, peakAt: 0.77 },
  { name: "brief-dislocation", dropFraction: 0.26, recoveryFraction: 0.35, lowAt: 0.17, reboundAt: 0.66, retestDepth: 0.26, upperWickFraction: 0.08, peakAt: 0.54 },
  { name: "delayed-reclaim", dropFraction: 0.36, recoveryFraction: 0.5, lowAt: 0.4, reboundAt: 0.72, retestDepth: 0.31, upperWickFraction: 0.13, peakAt: 0.83 }
].map((preset) => Object.freeze(preset)));
var CYCLE_HOUR_MS = 36e5;
var CYCLE_TICK_MS = 1e4;
var HOUR_TICKS = CYCLE_HOUR_MS / CYCLE_TICK_MS;
function cycleForHour(config, listingAt, hour) {
  if (!config || !Number.isFinite(config.anchorAt) || !Number.isFinite(config.notBefore) || !Number.isSafeInteger(config.periodHours) || config.periodHours < 2) return null;
  const anchorHour = (config.anchorAt - listingAt) / CYCLE_HOUR_MS;
  if (!Number.isSafeInteger(anchorHour) || anchorHour < 0 || !Number.isSafeInteger(hour) || hour < anchorHour) return null;
  const index = Math.floor((hour - anchorHour) / config.periodHours);
  const shockHour = anchorHour + index * config.periodHours;
  const phase = hour - shockHour;
  if (phase > 1) return null;
  const shockAt = listingAt + shockHour * CYCLE_HOUR_MS;
  const protectedTicks = Math.max(0, Math.ceil((config.notBefore - shockAt) / CYCLE_TICK_MS));
  if (protectedTicks > HOUR_TICKS - 6) return null;
  return {
    index,
    shockHour,
    phase: phase === 0 ? "shock" : "recovery",
    protectedTicks,
    preset: CYCLIC_IMPULSE_PRESETS[index % CYCLIC_IMPULSE_PRESETS.length]
  };
}
__name(cycleForHour, "cycleForHour");
function cycleShockClose(shockOpen, preset) {
  return shockOpen * (1 - preset.dropFraction * (1 - preset.recoveryFraction));
}
__name(cycleShockClose, "cycleShockClose");
function cycleHourTicks(seed, hour, cycle, shockOpen, recoveryClose, original) {
  if (original.length !== HOUR_TICKS) throw new RangeError("A cycle needs one complete canonical hour");
  const { preset: P, phase } = cycle;
  const shockClose = cycleShockClose(shockOpen, P);
  const start = phase === "shock" ? cycle.protectedTicks : 0;
  const open = phase === "shock" ? start ? original[start - 1].price : shockOpen : shockClose;
  const count = HOUR_TICKS - start;
  let vertices;
  if (phase === "shock") {
    const low = shockOpen * (1 - P.dropFraction);
    const lowTick = start + Math.max(1, Math.min(count - 3, Math.round(count * P.lowAt)));
    const reboundTick = Math.max(lowTick + 1, Math.min(HOUR_TICKS - 2, start + Math.round(count * P.reboundAt)));
    const retestTick = Math.max(reboundTick + 1, Math.min(HOUR_TICKS - 1, start + Math.round(count * 0.84)));
    const rebound = low + (shockClose - low) * 0.92;
    vertices = [
      { tick: start, price: open },
      { tick: lowTick, price: low },
      { tick: reboundTick, price: rebound },
      { tick: retestTick, price: low + (rebound - low) * (1 - P.retestDepth) },
      { tick: HOUR_TICKS, price: shockClose }
    ];
  } else {
    const peak = Math.max(open, recoveryClose) * (1 + P.upperWickFraction);
    const peakTick = Math.round(HOUR_TICKS * P.peakAt);
    vertices = [
      { tick: 0, price: open },
      { tick: Math.round(peakTick * 0.42), price: open + (recoveryClose - open) * 0.34 },
      { tick: peakTick, price: peak },
      { tick: Math.round(peakTick + (HOUR_TICKS - peakTick) * 0.58), price: recoveryClose + (peak - recoveryClose) * 0.23 },
      { tick: HOUR_TICKS, price: recoveryClose }
    ];
  }
  const floor = Math.min(...vertices.map((v) => v.price));
  const ceiling = Math.max(...vertices.map((v) => v.price));
  const random = seededRandom(seed, "cyclic-impulse-v1", cycle.index, hour, phase);
  const out = original.slice(0, start);
  let previous = open, segment = 0;
  for (let tick = start + 1; tick <= HOUR_TICKS; tick++) {
    while (segment + 1 < vertices.length - 1 && tick > vertices[segment + 1].tick) segment++;
    const a = vertices[segment], b = vertices[segment + 1];
    const progress2 = (tick - a.tick) / (b.tick - a.tick);
    const logMove = Math.log(b.price / a.price);
    const noise3 = Math.min(5e-3, Math.max(35e-5, Math.abs(logMove) * 0.045)) * normal(random) * Math.sin(Math.PI * progress2);
    const price = tick === b.tick ? b.price : Math.min(ceiling, Math.max(floor, a.price * Math.exp(logMove * progress2 + noise3)));
    const move = Math.abs(Math.log(price / previous));
    const shadow = 45e-5 * (0.5 + random()) * (1 + Math.min(5, 30 * move));
    const high = Math.min(ceiling, Math.max(previous, price) * Math.exp(shadow * Math.abs(normal(random))));
    const low = Math.max(floor, Math.min(previous, price) * Math.exp(-shadow * Math.abs(normal(random))));
    const quoteVolume = original[tick - 1].quoteVolume * (phase === "shock" ? 1.25 : 1.4) * (1 + 65 * move);
    out.push({ price, high, low, quoteVolume, volume: quoteVolume / ((previous + price) / 2) });
    previous = price;
  }
  return out;
}
__name(cycleHourTicks, "cycleHourTicks");

// ../../src/services/testMarkets/simulationAccumulation.ts
var HOUR_MS = 36e5;
var TICK_MS = 1e4;
var HOUR_TICKS2 = HOUR_MS / TICK_MS;
var clamp = /* @__PURE__ */ __name((value, min, max) => Math.max(min, Math.min(max, value)), "clamp");
function accumulationForHour(config, listingAt, hour) {
  if (!config || !Number.isFinite(config.anchorAt) || !Number.isSafeInteger(hour) || !Number.isSafeInteger(config.accumulationHours) || config.accumulationHours < 1 || !(config.flushFraction > 0 && config.flushFraction < 0.8) || !(config.minBandFraction > 0 && config.maxBandFraction >= config.minBandFraction && config.maxBandFraction < 1)) return null;
  const startHour = (config.anchorAt - listingAt) / HOUR_MS;
  if (!Number.isSafeInteger(startHour) || startHour < 0 || hour < startHour) return null;
  const relativeHour = hour - startHour;
  if (relativeHour === 0) return { phase: "flush", relativeHour, startHour };
  if (relativeHour <= config.accumulationHours) return { phase: "accumulation", relativeHour, startHour };
  return { phase: "final-growth", relativeHour, startHour };
}
__name(accumulationForHour, "accumulationForHour");
function bandWidth(seed, config, hour) {
  const phaseRandom = seededRandom(seed, "accumulation-band-phase-v1");
  const phase = phaseRandom() * Math.PI * 2;
  const middle = (config.minBandFraction + config.maxBandFraction) / 2;
  const amplitude = (config.maxBandFraction - config.minBandFraction) / 2;
  return middle + amplitude * Math.sin(phase + hour * Math.PI / 24);
}
__name(bandWidth, "bandWidth");
function accumulationFactor(seed, config, hour) {
  if (hour <= 0) return 1;
  const targetHour = Math.min(hour, config.accumulationHours);
  const phaseRandom = seededRandom(seed, "accumulation-wave-phase-v2");
  const primaryPhase = phaseRandom() * Math.PI * 2;
  const secondaryPhase = phaseRandom() * Math.PI * 2;
  const width = bandWidth(seed, config, targetHour);
  const half = width / 2;
  const primary = Math.sin(primaryPhase + targetHour * Math.PI * 2 / 38);
  const secondary = Math.sin(secondaryPhase + targetHour * Math.PI * 2 / 13);
  const random = seededRandom(seed, "accumulation-close-noise-v2", targetHour);
  const noise3 = normal(random) * 0.07;
  const shape = clamp(primary * 0.78 + secondary * 0.17 + noise3 * 0.05, -0.92, 0.92);
  return 1 + half * shape;
}
__name(accumulationFactor, "accumulationFactor");
function flushHourTicks(seed, hour, open, flushFraction, original) {
  if (original.length !== HOUR_TICKS2) throw new RangeError("Flush hour needs one complete canonical hour");
  const floor = open * (1 - flushFraction);
  const vertices = [
    { tick: 0, price: open },
    { tick: 86, price: open * 0.88 },
    { tick: 134, price: floor },
    { tick: 222, price: open * 0.91 },
    { tick: 286, price: open * 0.84 },
    { tick: HOUR_TICKS2, price: open }
  ];
  const random = seededRandom(seed, "final-flush-v1", hour);
  const out = [];
  let previous = open;
  let segment = 0;
  for (let tick = 1; tick <= HOUR_TICKS2; tick++) {
    while (segment + 1 < vertices.length - 1 && tick > vertices[segment + 1].tick) segment++;
    const a = vertices[segment], b = vertices[segment + 1];
    const progress2 = (tick - a.tick) / (b.tick - a.tick);
    const logMove = Math.log(b.price / a.price);
    const noise3 = Math.min(35e-4, Math.max(25e-5, Math.abs(logMove) * 0.03)) * normal(random) * Math.sin(Math.PI * progress2);
    const price = tick === b.tick ? b.price : clamp(a.price * Math.exp(logMove * progress2 + noise3), floor, open);
    const move = Math.abs(Math.log(price / previous));
    const shadow = 35e-5 * (0.5 + random()) * (1 + Math.min(4, 25 * move));
    const high = Math.min(open, Math.max(previous, price) * Math.exp(shadow * Math.abs(normal(random))));
    const low = Math.max(floor, Math.min(previous, price) * Math.exp(-shadow * Math.abs(normal(random))));
    const quoteVolume = original[tick - 1].quoteVolume * 1.35 * (1 + 55 * move);
    out.push({ price, high, low, quoteVolume, volume: quoteVolume / ((previous + price) / 2) });
    previous = price;
  }
  out[133] = { ...out[133], price: floor, low: floor };
  out[HOUR_TICKS2 - 1] = { ...out[HOUR_TICKS2 - 1], price: open, high: Math.max(out[HOUR_TICKS2 - 1].high, open) };
  return out;
}
__name(flushHourTicks, "flushHourTicks");

// ../../src/services/testMarkets/simulationNaturalWicks.ts
var NATURAL_WICK_WINDOW_MS = 15 * 6e4;
function naturalWickWindowAllowed(config, openTime) {
  return Number.isFinite(config.historicalUntil) && openTime + NATURAL_WICK_WINDOW_MS <= config.historicalUntil || Number.isFinite(config.futureFrom) && openTime >= config.futureFrom;
}
__name(naturalWickWindowAllowed, "naturalWickWindowAllowed");
function naturalWickWindowSelected(seed, offset, index) {
  const block = Math.floor(index / 8);
  const random = seededRandom(seed, "natural-wicks-v1", offset, "selection", block);
  const order = [0, 1, 2, 3, 4, 5, 6, 7];
  for (let i = order.length - 1; i > 0; i -= 1) {
    const j = Math.floor(random() * (i + 1));
    [order[i], order[j]] = [order[j], order[i]];
  }
  return order.slice(0, 4).includes(index - block * 8);
}
__name(naturalWickWindowSelected, "naturalWickWindowSelected");
function naturalWickLimit(profileMaxWick) {
  return Math.min(0.16, (profileMaxWick ?? 0.1) * 1.25);
}
__name(naturalWickLimit, "naturalWickLimit");
function naturalWickCandles(seed, offset, index, candles) {
  if (!candles.length) return candles;
  const open = candles[0].open, close = candles[candles.length - 1].close;
  let high = Math.max(open, close), low = Math.min(open, close);
  for (const candle of candles) for (const tick of candle.ticks) {
    high = Math.max(high, tick.high);
    low = Math.min(low, tick.low);
  }
  const range = high - low;
  if (!(range > 0) || !(low > 0)) return candles;
  const body = Math.abs(close - open);
  const localBody = candles.reduce((sum, candle) => sum + Math.abs(candle.close - candle.open), 0) / candles.length;
  const bodyShare = Math.min(1, body / range);
  const scale = Math.max(body * 0.45, Math.min(range * 0.4, Math.max(localBody, range * 0.18))) * (0.55 + 0.45 * bodyShare);
  const random = seededRandom(seed, "natural-wicks-v1", offset, "shape", index);
  const strength = (0.3 + 1.2 * random() ** 1.6) * (random() < 0.12 ? 1.65 : 1);
  const extension = Math.min(scale * strength, range * 0.75, Math.min(open, close) * 0.06);
  const kind = random();
  let upper, lower;
  if (kind < 0.33) {
    upper = extension;
    lower = random() < 0.35 ? extension * (0.05 + random() * 0.2) : 0;
  } else if (kind < 0.66) {
    lower = extension;
    upper = random() < 0.35 ? extension * (0.05 + random() * 0.2) : 0;
  } else {
    upper = extension * (0.25 + random() * 0.75);
    lower = extension * (0.25 + random() * 0.75);
  }
  const result = candles.map((candle) => ({ ...candle, ticks: candle.ticks.slice() }));
  const extend = /* @__PURE__ */ __name((side, amount) => {
    if (!(amount > 0)) return false;
    let chosen = null;
    let best = side === "upper" ? -Infinity : Infinity;
    for (let c = 0; c < candles.length; c += 1) {
      const candle = candles[c];
      const bound = side === "upper" ? Math.max(candle.open, candle.close) * Math.exp(candle.maxWick) : Math.min(candle.open, candle.close) * Math.exp(-candle.maxWick);
      if (side === "upper" ? bound <= high * (1 + 2e-8) : bound >= low * (1 - 2e-8)) continue;
      for (let t = 0; t < candle.ticks.length; t += 1) {
        const extreme = side === "upper" ? candle.ticks[t].high : candle.ticks[t].low;
        if (side === "upper" ? extreme > best : extreme < best) {
          best = extreme;
          chosen = { candle: c, tick: t, bound };
        }
      }
    }
    if (!chosen) return false;
    const tick = result[chosen.candle].ticks[chosen.tick];
    result[chosen.candle].ticks[chosen.tick] = side === "upper" ? { ...tick, high: Math.max(tick.high, Math.min(high + amount, chosen.bound)) } : { ...tick, low: Math.min(tick.low, Math.max(low - amount, chosen.bound)) };
    return true;
  }, "extend");
  const raised = extend("upper", upper);
  const lowered = extend("lower", lower);
  if (!raised && !lowered) {
    if (upper > 0) extend("lower", extension * 0.6);
    else extend("upper", extension * 0.6);
  }
  return result;
}
__name(naturalWickCandles, "naturalWickCandles");

// ../../src/services/testMarkets/testMarketSimulation.ts
var TICK_MS2 = 1e4;
var MINUTE_MS = 6e4;
var CANDLE_MS = 3e5;
var HOUR_MS2 = 36e5;
var DAY_MS = 864e5;
var TICKS_PER_CANDLE = CANDLE_MS / TICK_MS2;
var TICKS_PER_MINUTE = MINUTE_MS / TICK_MS2;
var CANDLES_PER_HOUR = HOUR_MS2 / CANDLE_MS;
function round(price) {
  return Number(price.toPrecision(8));
}
__name(round, "round");
function impulseRate(day) {
  return day <= 2 ? 0.3 : 0.3 * Math.pow(0.8, day - 2);
}
__name(impulseRate, "impulseRate");
var PULLBACK_RETURN = -0.04;
var CONSOLIDATION_BAND = 9e-3;
function blockStartHour(index) {
  return index === 0 ? 0 : 48 + (index - 1) * 24;
}
__name(blockStartHour, "blockStartHour");
function blockIndexOfHour(hour) {
  return hour < 48 ? 0 : 1 + Math.floor((hour - 48) / 24);
}
__name(blockIndexOfHour, "blockIndexOfHour");
function blockCounts(index) {
  if (index === 0) return { impulse: 25, consolidation: 17, pullback: 6 };
  const day = index + 2;
  const impulse = day % 2 === 1 ? 13 : 12;
  return { impulse, consolidation: 24 - impulse - 3, pullback: 3 };
}
__name(blockCounts, "blockCounts");
function longestRuns(regimes) {
  const longest = { impulse: 0, consolidation: 0, pullback: 0 };
  let run = 0;
  for (let i = 0; i < regimes.length; i++) {
    run = i > 0 && regimes[i] === regimes[i - 1] ? run + 1 : 1;
    longest[regimes[i]] = Math.max(longest[regimes[i]], run);
  }
  return longest;
}
__name(longestRuns, "longestRuns");
function blockSchedule(seed, index) {
  const counts = blockCounts(index);
  const pool = [
    ...Array(counts.impulse).fill("impulse"),
    ...Array(counts.consolidation).fill("consolidation"),
    ...Array(counts.pullback).fill("pullback")
  ];
  for (let attempt = 0; attempt < 2e3; attempt++) {
    const random = seededRandom(seed, "schedule", index, attempt);
    const order = pool.slice();
    for (let i = order.length - 1; i > 0; i--) {
      const j = Math.floor(random() * (i + 1));
      [order[i], order[j]] = [order[j], order[i]];
    }
    const runs = longestRuns(order);
    if (runs.impulse > 4 || runs.consolidation > 3 || runs.pullback > 2) continue;
    if (index === 0 && order[0] !== "impulse") continue;
    return order;
  }
  return pool.map((_, i) => pool[i * 7 % pool.length]);
}
__name(blockSchedule, "blockSchedule");
function buildBlock(seed, index) {
  const startHour = blockStartHour(index);
  const regimes = blockSchedule(seed, index);
  const random = seededRandom(seed, "returns", index);
  const anchor = [];
  const logReturns = regimes.map((regime, i) => {
    const day = Math.floor((startHour + i) / 24) + 1;
    const target = regime === "impulse" ? Math.log(1 + impulseRate(day)) : regime === "pullback" ? Math.log(1 + PULLBACK_RETURN) : 0;
    anchor.push(target);
    if (regime === "consolidation") return Math.log(1 + (random() * 2 - 1) * CONSOLIDATION_BAND);
    const spread = regime === "impulse" ? 0.14 : 0.3;
    return target * (1 + spread * normal(random));
  });
  const difference = logReturns.reduce((a, b) => a + b, 0) - anchor.reduce((a, b) => a + b, 0);
  const weight = logReturns.reduce((sum, value, i) => sum + (regimes[i] === "consolidation" ? 0 : Math.abs(value)), 0);
  if (weight > 0) {
    for (let i = 0; i < logReturns.length; i++) {
      if (regimes[i] !== "consolidation") logReturns[i] -= difference * Math.abs(logReturns[i]) / weight;
    }
  }
  return { index, startHour, regimes, logReturns };
}
__name(buildBlock, "buildBlock");
function clusterFactor(seed, hour) {
  let level = 0;
  const weights = [1, 0.8, 0.6, 0.4];
  for (let j = 0; j < weights.length; j++) level += Math.abs(normal(seededRandom(seed, "cluster", hour - j))) * weights[j];
  return 0.45 + 0.7 * level / (0.8 * 2.8);
}
__name(clusterFactor, "clusterFactor");
function candleSigma(regime, hourLogReturn, cluster) {
  const base = regime === "impulse" ? Math.max(Math.abs(hourLogReturn) / CANDLES_PER_HOUR * 1.05, 4e-3) : regime === "pullback" ? 55e-4 : 32e-4;
  return base * cluster;
}
__name(candleSigma, "candleSigma");
function hourCandleReturns(seed, hour, regime, hourLogReturn, sigma) {
  const random = seededRandom(seed, "hour", hour);
  const mu = hourLogReturn / CANDLES_PER_HOUR;
  const steps = [];
  for (let k = 0; k < CANDLES_PER_HOUR; k++) {
    const body = 0.45 + random() * 1.1;
    const burst = random() < 0.07 ? 2.2 : 1;
    steps.push(mu + sigma * body * burst * normal(random));
  }
  const drift = (steps.reduce((a, b) => a + b, 0) - hourLogReturn) / CANDLES_PER_HOUR;
  return steps.map((step) => step - drift);
}
__name(hourCandleReturns, "hourCandleReturns");
var SCHEDULE_UNUSED_TICKS = Object.freeze(Array.from({ length: 360 }, () => Object.freeze({ price: 1, high: 1, low: 1, volume: 0, quoteVolume: 0 })));
var REGIME_VOLUME = { impulse: 1.7, consolidation: 0.5, pullback: 1.35 };
var BASE_QUOTE_VOLUME = 5200;
function candleTicks(seed, hour, slot, regime, open, close, sigma, cluster, initialPrice) {
  const random = seededRandom(seed, "ticks", hour, slot);
  const total = Math.log(close / open);
  const tickSigma = sigma / Math.sqrt(TICKS_PER_CANDLE) * 1.2;
  const steps = [];
  for (let i = 0; i < TICKS_PER_CANDLE; i++) steps.push(total / TICKS_PER_CANDLE + tickSigma * normal(random));
  const drift = (steps.reduce((a, b) => a + b, 0) - total) / TICKS_PER_CANDLE;
  const quote = BASE_QUOTE_VOLUME * Math.pow(open / initialPrice, 0.3) * REGIME_VOLUME[regime] * (1 + 18 * Math.abs(total) + 0.6 * (cluster - 1)) * Math.exp(0.35 * normal(random));
  const weights = steps.map((step) => Math.exp(0.5 * normal(random)) * (1 + 40 * Math.abs(step - drift)));
  const weightSum = weights.reduce((a, b) => a + b, 0);
  const ticks = [];
  let logPrice = Math.log(open);
  let previous = open;
  for (let i = 0; i < TICKS_PER_CANDLE; i++) {
    logPrice += steps[i] - drift;
    const price = i === TICKS_PER_CANDLE - 1 ? close : Math.exp(logPrice);
    const spike = random() < 0.03 ? 3 : 1;
    const high = Math.max(previous, price) * Math.exp(Math.abs(normal(random)) * tickSigma * 0.35 * spike);
    const low = Math.min(previous, price) * Math.exp(-Math.abs(normal(random)) * tickSigma * 0.35 * (random() < 0.03 ? 3 : 1));
    const quoteVolume = quote * weights[i] / weightSum;
    ticks.push({ price, high, low, quoteVolume, volume: quoteVolume / ((previous + price) / 2) });
    previous = price;
  }
  return ticks;
}
__name(candleTicks, "candleTicks");
function candleFromTicks(openTime, open, ticks, format = round) {
  let high = open, low = open, volume = 0, quoteVolume = 0;
  for (const tick of ticks) {
    high = Math.max(high, tick.high);
    low = Math.min(low, tick.low);
    volume += tick.volume;
    quoteVolume += tick.quoteVolume;
  }
  const close = ticks.length ? ticks[ticks.length - 1].price : open;
  return {
    openTime,
    open: format(open),
    high: format(Math.max(high, open, close)),
    low: format(Math.min(low, open, close)),
    close: format(close),
    volume: Number(volume.toFixed(4)),
    quoteVolume: Number(quoteVolume.toFixed(2))
  };
}
__name(candleFromTicks, "candleFromTicks");
function accentHour(seed, hour, wave, realistic, sigma, params) {
  if (!wave.flush && !wave.exhaustion) return realistic;
  const random = seededRandom(seed, "waves", "accent", hour);
  const shapes = realistic.shapes.map((shape) => ({ ...shape, excursions: shape.excursions.slice() }));
  const accent = /* @__PURE__ */ __name((side) => {
    let slot = -1;
    realistic.steps.forEach((step, k) => {
      if (Math.sign(step) === side && (slot < 0 || Math.abs(step) > Math.abs(realistic.steps[slot]))) slot = k;
    });
    if (slot < 0) slot = 3 + Math.floor(random() * 6);
    const height = Math.min(params.maxWick, Math.max(2.2 * sigma, 0.6 * Math.abs(realistic.steps[slot])) * (0.8 + 0.6 * random()));
    const rise = 2 + Math.floor(random() * 4), fall = 4 + Math.floor(random() * 6);
    const peak = Math.max(rise, Math.min(29 - fall, 8 + Math.floor(random() * 12)));
    shapes[slot] = {
      ...shapes[slot],
      volume: shapes[slot].volume * (side < 0 ? 1.7 : 1.45),
      excursions: [...shapes[slot].excursions.filter((e) => e.side !== side), { side, height, peak, rise, fall }]
    };
  }, "accent");
  if (wave.flush) accent(-1);
  if (wave.exhaustion) accent(1);
  return { ...realistic, shapes };
}
__name(accentHour, "accentHour");
var TestMarketSimulation = class _TestMarketSimulation {
  constructor(asset) {
    this.asset = asset;
    this.blocks = /* @__PURE__ */ new Map();
    this.hourOpens = [];
    this.closedCandles = /* @__PURE__ */ new Map();
    this.cycleHours = /* @__PURE__ */ new Map();
    this.accumulationHours = /* @__PURE__ */ new Map();
    this.naturalWindows = /* @__PURE__ */ new Map();
    this.waves = /* @__PURE__ */ new Map();
    this.scheduledHours = /* @__PURE__ */ new Map();
    this.formatPrice = /* @__PURE__ */ __name((price) => {
      const program = this.asset.scheduledScenario;
      return !this.asset.isTradable && program?.mode === "scenario-controls-v2" ? Math.min(Number(program.controls.maxPrice), Number(price.toFixed(10))) : round(price);
    }, "formatPrice");
    this.realism = isSimulationProfile(asset.simulationProfile) ? REALISM_PROFILES[asset.simulationProfile] : null;
    this.realismOffset = asset.realismSeedOffset ?? 0;
    this.realismFromHour = asset.realismFrom === void 0 ? 0 : Math.max(0, Math.ceil((asset.realismFrom - asset.listingAt) / HOUR_MS2));
    const structure = asset.marketStructure;
    this.structureFromHour = structure && Number.isFinite(structure.from) ? Math.max(0, Math.ceil((structure.from - asset.listingAt) / HOUR_MS2)) : null;
  }
  static {
    __name(this, "TestMarketSimulation");
  }
  block(index) {
    let block = this.blocks.get(index);
    if (!block) {
      block = buildBlock(this.asset.seed, index);
      const from = this.structureFromHour;
      const first = from === null ? -1 : Math.max(0, from - block.startHour);
      if (from !== null && first < block.regimes.length) {
        const total = block.logReturns.slice(first).reduce((a, b) => a + b, 0);
        waveHours(this.asset.seed, index, first, block.regimes.length - first, total).forEach((wave, i) => {
          block.regimes[first + i] = wave.regime;
          block.logReturns[first + i] = wave.logReturn;
          this.waves.set(block.startHour + first + i, wave);
        });
      }
      this.blocks.set(index, block);
    }
    return block;
  }
  /** Price at the open of `hour` (0 = the listing hour). */
  hourOpen(hour) {
    if (this.hourOpens.length === 0) this.hourOpens.push(this.asset.initialPrice);
    while (this.hourOpens.length <= hour) {
      const h = this.hourOpens.length - 1;
      const block = this.block(blockIndexOfHour(h));
      this.hourOpens.push(this.hourOpens[h] * Math.exp(block.logReturns[h - block.startHour]));
    }
    return this.hourOpens[hour];
  }
  regimeOf(hour) {
    const block = this.block(blockIndexOfHour(hour));
    return block.regimes[hour - block.startHour];
  }
  baselineHourPlan(hour) {
    const block = this.block(blockIndexOfHour(hour));
    const regime = block.regimes[hour - block.startHour];
    const logReturn = block.logReturns[hour - block.startHour];
    const wave = this.waves.get(hour);
    const cluster = clusterFactor(this.asset.seed, hour) * (wave ? wave.volatility : 1);
    const sigma = wave ? Math.max(
      candleSigma(regime, logReturn, cluster),
      Math.abs(logReturn) / CANDLES_PER_HOUR * 1.25 * wave.volatility,
      wave.trendStep * (regime === "consolidation" ? 0.2 : 0.45) * wave.volatility
    ) : candleSigma(regime, logReturn, cluster);
    const open = this.hourOpen(hour);
    const params = wave ? REALISM_PROFILES[wave.profile] : this.realism && hour >= this.realismFromHour ? this.realism : null;
    const shaped = params ? realisticHour({
      seed: this.asset.seed,
      offset: this.realismOffset,
      hour,
      regime,
      logReturn,
      sigma,
      params,
      trendStep: wave ? wave.trendStep : Math.log(1 + impulseRate(Math.floor(hour / 24) + 1)) / CANDLES_PER_HOUR,
      previousRegime: hour > 0 ? this.regimeOf(hour - 1) : null,
      nextRegime: this.regimeOf(hour + 1)
    }) : null;
    const realistic = shaped && wave && params ? accentHour(this.asset.seed, hour, wave, shaped, sigma, params) : shaped;
    const shapedSteps = realistic ? realistic.steps : hourCandleReturns(this.asset.seed, hour, regime, logReturn, sigma);
    const steps = wave ? pauseInsideHour(this.asset.seed, hour, wave, shapedSteps, this.asset.listingAt % (15 * MINUTE_MS) === 0) : shapedSteps;
    const boundaries = [open];
    let logPrice = Math.log(open);
    for (let k = 0; k < CANDLES_PER_HOUR; k++) {
      logPrice += steps[k];
      boundaries.push(k === CANDLES_PER_HOUR - 1 ? this.hourOpen(hour + 1) : Math.exp(logPrice));
    }
    return {
      hour,
      regime,
      open,
      logReturn,
      sigma,
      cluster,
      boundaries,
      ...realistic ? { shapes: realistic.shapes } : {},
      ...wave && params ? { params, volume: wave.volume } : {}
    };
  }
  accumulationOpen(hour, phase) {
    const config = this.asset.accumulationPhase;
    const anchor = this.hourOpen(phase.startHour);
    if (phase.relativeHour === 0) return anchor;
    if (phase.relativeHour <= config.accumulationHours) {
      return anchor * accumulationFactor(this.asset.seed, config, phase.relativeHour - 1);
    }
    const finalStart = phase.startHour + config.accumulationHours + 1;
    let price = anchor * accumulationFactor(this.asset.seed, config, config.accumulationHours);
    for (let h = finalStart; h < hour; h++) {
      price *= Math.exp(this.baselineHourPlan(h).logReturn);
    }
    return price;
  }
  accumulationHourPlan(hour, phase) {
    const cached = this.accumulationHours.get(hour);
    if (cached) return cached;
    const config = this.asset.accumulationPhase;
    const open = this.accumulationOpen(hour, phase);
    let plan;
    if (phase.phase === "flush") {
      const baseline2 = this.baselineHourPlan(hour);
      const original = Array.from({ length: CANDLES_PER_HOUR }, (_, slot) => this.baselineTicks(baseline2, slot)).flat();
      const phaseTicks = flushHourTicks(this.asset.seed, hour, open, config.flushFraction, original);
      const boundaries = [open];
      for (let slot = 0; slot < CANDLES_PER_HOUR; slot++) boundaries.push(phaseTicks[(slot + 1) * TICKS_PER_CANDLE - 1].price);
      plan = { ...baseline2, open, regime: "pullback", logReturn: 0, boundaries, cycleTicks: phaseTicks, shapes: void 0 };
    } else if (phase.phase === "accumulation") {
      const anchor = this.hourOpen(phase.startHour);
      const close = anchor * accumulationFactor(this.asset.seed, config, phase.relativeHour);
      const logReturn = Math.log(close / open);
      const regime = "consolidation";
      const cluster = clusterFactor(this.asset.seed, hour);
      const sigma = candleSigma(regime, logReturn, cluster);
      const realistic = this.realism ? realisticHour({
        seed: this.asset.seed,
        offset: this.realismOffset,
        hour,
        regime,
        logReturn,
        sigma,
        params: this.realism,
        trendStep: 0,
        previousRegime: "consolidation",
        nextRegime: "consolidation"
      }) : null;
      const steps = realistic ? realistic.steps : hourCandleReturns(this.asset.seed, hour, regime, logReturn, sigma);
      const rangeFloor = anchor * (1 - config.maxBandFraction / 2);
      const rangeCeiling = anchor * (1 + config.maxBandFraction / 2);
      const boundaries = [open];
      let logPrice = Math.log(open);
      for (let k = 0; k < CANDLES_PER_HOUR; k++) {
        logPrice += steps[k];
        const raw = k === CANDLES_PER_HOUR - 1 ? close : Math.exp(logPrice);
        boundaries.push(Math.max(rangeFloor, Math.min(rangeCeiling, raw)));
      }
      plan = {
        hour,
        regime,
        open,
        logReturn: Math.log(boundaries[CANDLES_PER_HOUR] / open),
        sigma,
        cluster,
        boundaries,
        rangeFloor,
        rangeCeiling,
        ...realistic ? { shapes: realistic.shapes } : {}
      };
    } else {
      const baseline2 = this.baselineHourPlan(hour);
      const scale = open / baseline2.open;
      plan = { ...baseline2, open, boundaries: baseline2.boundaries.map((value) => value * scale) };
    }
    this.accumulationHours.set(hour, plan);
    if (this.accumulationHours.size > 240) this.accumulationHours.delete(this.accumulationHours.keys().next().value);
    return plan;
  }
  scheduledHourPlan(hour, config) {
    const cached = this.scheduledHours.get(hour);
    if (cached) return cached;
    const base = this.scheduledBase ??= new _TestMarketSimulation({ ...this.asset, scheduledScenario: void 0 });
    if (this.scheduledAnchor === void 0) {
      const completed = Math.floor((config.from - this.asset.listingAt) / TICK_MS2);
      if (completed <= 0) this.scheduledAnchor = this.asset.initialPrice;
      else {
        const tickIndex = completed - 1, candleIndex = Math.floor(tickIndex / TICKS_PER_CANDLE);
        const anchorPlan = base.hourPlan(Math.floor(candleIndex / CANDLES_PER_HOUR));
        this.scheduledAnchor = base.ticks(anchorPlan, candleIndex % CANDLES_PER_HOUR)[tickIndex % TICKS_PER_CANDLE].price;
      }
    }
    const anchor = this.scheduledAnchor;
    const retainsHistory = this.asset.listingAt + hour * HOUR_MS2 < config.from;
    const original = retainsHistory ? base.hourPlan(hour) : { hour, open: anchor, regime: "consolidation", logReturn: 0, sigma: 0, cluster: 1, boundaries: [anchor] };
    const ticks = retainsHistory ? Array.from({ length: CANDLES_PER_HOUR }, (_, slot) => base.ticks(original, slot)).flat() : SCHEDULE_UNUSED_TICKS;
    const scheduled = scheduledScenarioHour(
      config,
      this.asset.seed,
      this.asset.listingAt,
      this.asset.initialPrice,
      hour,
      anchor,
      original.open,
      ticks
    );
    const boundaries = [scheduled.open];
    for (let slot = 0; slot < CANDLES_PER_HOUR; slot++) boundaries.push(scheduled.ticks[(slot + 1) * TICKS_PER_CANDLE - 1].price);
    const plan = {
      ...original,
      open: scheduled.open,
      regime: scheduled.regime,
      logReturn: Math.log(boundaries[CANDLES_PER_HOUR] / scheduled.open),
      boundaries,
      cycleTicks: scheduled.ticks,
      shapes: void 0,
      rangeFloor: void 0,
      rangeCeiling: void 0
    };
    this.scheduledHours.set(hour, plan);
    if (this.scheduledHours.size > 96) this.scheduledHours.delete(this.scheduledHours.keys().next().value);
    return plan;
  }
  hourPlan(hour) {
    const scheduled = this.asset.symbol === "NRX" && this.asset.pair === "NRX/USDT" || !this.asset.isTradable && (this.asset.scheduledScenario?.mode === "capped-growth-range" || this.asset.scheduledScenario?.mode === "scenario-controls-v2") ? this.asset.scheduledScenario : void 0;
    if (scheduled && hour >= Math.max(0, Math.floor((scheduled.from - this.asset.listingAt) / HOUR_MS2))) {
      return this.scheduledHourPlan(hour, scheduled);
    }
    const accumulation = accumulationForHour(this.asset.accumulationPhase, this.asset.listingAt, hour);
    if (accumulation) return this.accumulationHourPlan(hour, accumulation);
    const cycle = cycleForHour(this.asset.cyclicImpulse, this.asset.listingAt, hour);
    if (!cycle) return this.baselineHourPlan(hour);
    const cached = this.cycleHours.get(hour);
    if (cached) return cached;
    const baseline2 = this.baselineHourPlan(hour);
    const original = Array.from({ length: CANDLES_PER_HOUR }, (_, slot) => this.baselineTicks(baseline2, slot)).flat();
    const shockOpen = this.hourOpen(cycle.shockHour);
    const cycleTicks = cycleHourTicks(this.asset.seed, hour, cycle, shockOpen, this.hourOpen(cycle.shockHour + 2), original);
    const open = cycle.phase === "shock" ? baseline2.open : cycleShockClose(shockOpen, cycle.preset);
    const boundaries = [open];
    for (let slot = 0; slot < CANDLES_PER_HOUR; slot++) boundaries.push(cycleTicks[(slot + 1) * TICKS_PER_CANDLE - 1].price);
    const plan = { ...baseline2, open, logReturn: Math.log(boundaries[CANDLES_PER_HOUR] / open), boundaries, cycleTicks };
    this.cycleHours.set(hour, plan);
    if (this.cycleHours.size > 96) this.cycleHours.delete(this.cycleHours.keys().next().value);
    return plan;
  }
  baselineTicks(plan, slot) {
    const open = plan.boundaries[slot], close = plan.boundaries[slot + 1];
    const params = plan.params ?? this.realism;
    if (plan.shapes && params) {
      const growth = plan.volume !== void 0 && this.structureFromHour !== null ? Math.min(45, Math.pow(open / this.hourOpen(this.structureFromHour), 0.5)) : 1;
      const volumeBase = BASE_QUOTE_VOLUME * Math.pow(open / this.asset.initialPrice, 0.3) * growth * REGIME_VOLUME[plan.regime] * (plan.volume ?? 1);
      return realisticTicks(
        this.asset.seed,
        this.realismOffset,
        plan.hour,
        slot,
        open,
        close,
        plan.shapes[slot],
        plan.cluster,
        volumeBase,
        params
      );
    }
    return candleTicks(this.asset.seed, plan.hour, slot, plan.regime, open, close, plan.sigma, plan.cluster, this.asset.initialPrice);
  }
  originalTicks(plan, slot) {
    if (plan.cycleTicks) return plan.cycleTicks.slice(slot * TICKS_PER_CANDLE, (slot + 1) * TICKS_PER_CANDLE);
    const ticks = this.baselineTicks(plan, slot);
    const from = this.asset.wickBoostFrom;
    if (from === void 0 || !Number.isFinite(from)) return ticks;
    const candleAt = this.asset.listingAt + plan.hour * HOUR_MS2 + slot * CANDLE_MS;
    const ceiling = plan.shapes && this.realism ? Math.max(plan.boundaries[slot], plan.boundaries[slot + 1]) * Math.exp(this.realism.maxWick) : Infinity;
    const floor = plan.shapes && this.realism ? Math.min(plan.boundaries[slot], plan.boundaries[slot + 1]) * Math.exp(-this.realism.maxWick) : Number.MIN_VALUE;
    return ticks.map((tick, i) => {
      if (candleAt + (i + 1) * TICK_MS2 <= from) return tick;
      const previous = i ? ticks[i - 1].price : plan.boundaries[slot];
      const top = Math.max(previous, tick.price), bottom = Math.min(previous, tick.price);
      return {
        ...tick,
        high: Math.min(ceiling, top + (tick.high - top) * 1.55),
        low: Math.max(floor, bottom - (bottom - tick.low) * 1.55)
      };
    });
  }
  boundTicks(plan, ticks) {
    if (plan.rangeFloor === void 0 || plan.rangeCeiling === void 0) return ticks;
    const floor = plan.rangeFloor, ceiling = plan.rangeCeiling;
    return ticks.map((tick) => {
      const price = Math.max(floor, Math.min(ceiling, tick.price));
      const high = Math.max(price, Math.min(ceiling, tick.high));
      const low = Math.min(price, Math.max(floor, tick.low));
      return { ...tick, price, high, low };
    });
  }
  ticks(plan, slot) {
    const policy = this.asset.naturalWicks;
    if (!policy || plan.cycleTicks) return this.boundTicks(plan, this.originalTicks(plan, slot));
    const index = plan.hour * CANDLES_PER_HOUR + slot;
    const at = this.asset.listingAt + index * CANDLE_MS;
    const windowAt = Math.floor(at / NATURAL_WICK_WINDOW_MS) * NATURAL_WICK_WINDOW_MS;
    const firstWindow = Math.floor(this.asset.listingAt / NATURAL_WICK_WINDOW_MS) * NATURAL_WICK_WINDOW_MS;
    const windowIndex = (windowAt - firstWindow) / NATURAL_WICK_WINDOW_MS;
    if (!naturalWickWindowAllowed(policy, windowAt) || !naturalWickWindowSelected(this.asset.seed, this.realismOffset, windowIndex)) {
      return this.boundTicks(plan, this.originalTicks(plan, slot));
    }
    let window = this.naturalWindows.get(windowAt);
    if (!window) {
      const first = Math.max(0, Math.ceil((windowAt - this.asset.listingAt) / CANDLE_MS));
      const end = Math.ceil((windowAt + NATURAL_WICK_WINDOW_MS - this.asset.listingAt) / CANDLE_MS);
      const original = [];
      for (let member = first; member < end; member += 1) {
        const hour = Math.floor(member / CANDLES_PER_HOUR), memberSlot = member % CANDLES_PER_HOUR;
        const memberPlan = hour === plan.hour ? plan : this.hourPlan(hour);
        if (memberPlan.cycleTicks) return this.boundTicks(plan, this.originalTicks(plan, slot));
        original.push({
          index: member,
          open: memberPlan.boundaries[memberSlot],
          close: memberPlan.boundaries[memberSlot + 1],
          maxWick: naturalWickLimit(this.realism?.maxWick),
          ticks: this.originalTicks(memberPlan, memberSlot)
        });
      }
      window = naturalWickCandles(this.asset.seed, this.realismOffset, windowIndex, original);
      this.naturalWindows.set(windowAt, window);
      if (this.naturalWindows.size > 96) this.naturalWindows.delete(this.naturalWindows.keys().next().value);
    }
    return this.boundTicks(plan, window.find((candle) => candle.index === index).ticks);
  }
  /** Read-only tape of completed canonical ticks; never samples a future tick. */
  recentTrades(now, limit = 100) {
    const done = Math.max(0, Math.floor((now - this.asset.listingAt) / TICK_MS2));
    const count = Math.min(done, Math.max(0, Math.min(500, Math.floor(limit))));
    const trades = [];
    let cachedIndex = -1, ticks = [], plan;
    for (let index = done - 1; index >= done - count; index--) {
      const candleIndex = Math.floor(index / TICKS_PER_CANDLE);
      const slot = candleIndex % CANDLES_PER_HOUR;
      if (cachedIndex !== candleIndex) {
        plan = this.hourPlan(Math.floor(candleIndex / CANDLES_PER_HOUR));
        ticks = this.ticks(plan, slot);
        cachedIndex = candleIndex;
      }
      const offset = index % TICKS_PER_CANDLE, tick = ticks[offset];
      const previous = offset ? ticks[offset - 1].price : plan.boundaries[slot];
      trades.push({
        id: `${this.asset.symbol}:${index + 1}`,
        timestamp: this.asset.listingAt + (index + 1) * TICK_MS2,
        price: String(this.formatPrice(tick.price)),
        quantity: tick.volume.toFixed(8),
        quoteVolume: tick.quoteVolume.toFixed(8),
        side: tick.price >= previous ? "BUY" : "SELL"
      });
    }
    return trades;
  }
  /**
   * The canonical 5m series from the listing up to `now`. The last candle
   * is the one forming at `now`, built from completed ticks only. Empty
   * before the listing.
   */
  candles5m(now, from = this.asset.listingAt) {
    const listing = this.asset.listingAt;
    if (now < listing) return [];
    const start = Math.max(listing, listing + Math.floor((from - listing) / CANDLE_MS) * CANDLE_MS);
    const out = [];
    let plan = null;
    for (let openTime = start; openTime <= now; openTime += CANDLE_MS) {
      const index = (openTime - listing) / CANDLE_MS;
      const hour = Math.floor(index / CANDLES_PER_HOUR);
      const slot = index % CANDLES_PER_HOUR;
      const closed = openTime + CANDLE_MS <= now;
      const cached = closed ? this.closedCandles.get(openTime) : void 0;
      if (cached) {
        out.push(cached);
        continue;
      }
      if (!plan || plan.hour !== hour) plan = this.hourPlan(hour);
      const ticks = this.ticks(plan, slot);
      const done = closed ? TICKS_PER_CANDLE : Math.floor((now - openTime) / TICK_MS2);
      const candle = candleFromTicks(openTime, plan.boundaries[slot], ticks.slice(0, done), this.formatPrice);
      if (closed) this.closedCandles.set(openTime, candle);
      out.push(candle);
    }
    return out;
  }
  /**
   * 1m candles from the same ticks as the canonical 5m series (six ticks
   * each), so five of them always aggregate to exactly their 5m candle. The
   * last one is forming at `now`, from completed ticks only.
   */
  candles1m(now, from = this.asset.listingAt) {
    const listing = this.asset.listingAt;
    if (now < listing) return [];
    const start = Math.max(listing, listing + Math.floor((from - listing) / MINUTE_MS) * MINUTE_MS);
    const out = [];
    let plan = null;
    let cachedIndex = -1, ticks = [];
    for (let openTime = start; openTime <= now; openTime += MINUTE_MS) {
      const index = Math.floor((openTime - listing) / CANDLE_MS);
      const hour = Math.floor(index / CANDLES_PER_HOUR);
      const slot = index % CANDLES_PER_HOUR;
      if (cachedIndex !== index) {
        if (!plan || plan.hour !== hour) plan = this.hourPlan(hour);
        ticks = this.ticks(plan, slot);
        cachedIndex = index;
      }
      const first = (openTime - listing - index * CANDLE_MS) / MINUTE_MS * TICKS_PER_MINUTE;
      const done = Math.min(TICKS_PER_MINUTE, Math.max(0, Math.floor((now - openTime) / TICK_MS2)));
      const open = first === 0 ? plan.boundaries[slot] : ticks[first - 1].price;
      out.push(candleFromTicks(openTime, open, ticks.slice(first, first + done), this.formatPrice));
    }
    return out;
  }
  /** The last traded price at `now`, or null before the listing. */
  priceAt(now) {
    if (now < this.asset.listingAt) return null;
    const candles = this.candles5m(now, now);
    return candles.length ? candles[candles.length - 1].close : null;
  }
};
var SIM_INTERVALS = {
  "1m": MINUTE_MS,
  "5m": 5 * 6e4,
  "15m": 15 * 6e4,
  "1h": HOUR_MS2,
  "4h": 4 * HOUR_MS2,
  "1d": DAY_MS,
  "1w": 7 * DAY_MS
};
var SIM_INTERVAL_OFFSETS = { "1w": 4 * DAY_MS };
function aggregateCandles(candles, intervalMs, offsetMs = 0) {
  if (intervalMs === CANDLE_MS) return candles.slice();
  const out = [];
  for (const candle of candles) {
    const bucket = Math.floor((candle.openTime - offsetMs) / intervalMs) * intervalMs + offsetMs;
    const last = out[out.length - 1];
    if (!last || last.openTime !== bucket) {
      out.push({ ...candle, openTime: bucket });
      continue;
    }
    last.high = Math.max(last.high, candle.high);
    last.low = Math.min(last.low, candle.low);
    last.close = candle.close;
    last.volume = Number((last.volume + candle.volume).toFixed(4));
    last.quoteVolume = Number((last.quoteVolume + candle.quoteVolume).toFixed(2));
  }
  return out;
}
__name(aggregateCandles, "aggregateCandles");
function getCurrentTestMarketState(simulation, now) {
  const asset = simulation.asset;
  const base = {
    pair: asset.pair,
    symbol: asset.symbol,
    name: asset.name,
    isTestAsset: true,
    isTradable: asset.isTradable,
    listingAt: asset.listingAt,
    initialPrice: asset.initialPrice,
    serverTime: now
  };
  if (now < asset.listingAt) {
    return {
      ...base,
      phase: "pre-listing",
      lastPrice: null,
      openPrice24h: null,
      change24hPercent: null,
      high24h: null,
      low24h: null,
      volume24h: null,
      quoteVolume24h: null
    };
  }
  const windowStart = now - DAY_MS;
  const window = simulation.candles5m(now, windowStart);
  const lastPrice = window[window.length - 1].close;
  const openPrice24h = windowStart <= asset.listingAt ? asset.initialPrice : simulation.priceAt(windowStart);
  let high = -Infinity, low = Infinity, volume = 0, quoteVolume = 0;
  for (const candle of window) {
    high = Math.max(high, candle.high);
    low = Math.min(low, candle.low);
    volume += candle.volume;
    quoteVolume += candle.quoteVolume;
  }
  return {
    ...base,
    phase: "live",
    lastPrice,
    openPrice24h,
    change24hPercent: (lastPrice / openPrice24h - 1) * 100,
    high24h: high,
    low24h: low,
    volume24h: Number(volume.toFixed(4)),
    quoteVolume24h: Number(quoteVolume.toFixed(2))
  };
}
__name(getCurrentTestMarketState, "getCurrentTestMarketState");
var simulations = /* @__PURE__ */ new Map();
var MAX_SIMULATIONS = 64;
function simulationFor(asset) {
  const cycle = asset.cyclicImpulse;
  const natural = asset.naturalWicks;
  const accumulation = asset.accumulationPhase;
  const cycleKey = cycle ? `${cycle.anchorAt}:${cycle.notBefore}:${cycle.periodHours}` : "no-cycle";
  const naturalKey = natural ? `${natural.historicalUntil ?? "no-history"}:${natural.futureFrom}` : "original-wicks";
  const accumulationKey = accumulation ? `${accumulation.anchorAt}:${accumulation.flushFraction}:${accumulation.accumulationHours}:${accumulation.minBandFraction}:${accumulation.maxBandFraction}` : "no-accumulation";
  const structureKey = asset.marketStructure ? `waves:${asset.marketStructure.from}` : "no-waves";
  const schedule = asset.symbol === "NRX" && asset.pair === "NRX/USDT" || !asset.isTradable && (asset.scheduledScenario?.mode === "capped-growth-range" || asset.scheduledScenario?.mode === "scenario-controls-v2") ? asset.scheduledScenario : void 0;
  const scheduleKey = schedule ? JSON.stringify(Object.fromEntries(Object.entries(schedule).sort(([a], [b]) => a.localeCompare(b)))) : "no-schedule";
  const key = `${asset.pair}|${asset.seed}|${asset.listingAt}|${asset.initialPrice}|${asset.simulationProfile ?? "legacy"}|${asset.realismSeedOffset ?? 0}|${asset.realismFrom ?? 0}|${cycleKey}|${asset.wickBoostFrom ?? "no-wick-boost"}|${naturalKey}|${accumulationKey}|${structureKey}|${scheduleKey}`;
  let simulation = simulations.get(key);
  if (!simulation) {
    simulation = new TestMarketSimulation(asset);
    simulations.set(key, simulation);
    if (simulations.size > MAX_SIMULATIONS) simulations.delete(simulations.keys().next().value);
  }
  return simulation;
}
__name(simulationFor, "simulationFor");

// ../../node_modules/bignumber.js/bignumber.mjs
var isNumeric = /^-?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?$/i;
var mathceil = Math.ceil;
var mathfloor = Math.floor;
var bignumberError = "[BigNumber Error] ";
var tooManyDigits = bignumberError + "Number primitive has more than 15 significant digits: ";
var BASE = 1e14;
var LOG_BASE = 14;
var MAX_SAFE_INTEGER = 9007199254740991;
var POWS_TEN = [1, 10, 100, 1e3, 1e4, 1e5, 1e6, 1e7, 1e8, 1e9, 1e10, 1e11, 1e12, 1e13];
var SQRT_BASE = 1e7;
var MAX = 1e9;
function clone(configObject) {
  var div, convertBase, parseNumeric, P = BigNumber2.prototype = { constructor: BigNumber2, toString: null, valueOf: null }, ONE = new BigNumber2(1), DECIMAL_PLACES = 20, ROUNDING_MODE = 4, TO_EXP_NEG = -7, TO_EXP_POS = 21, MIN_EXP = -1e7, MAX_EXP = 1e7, CRYPTO = false, MODULO_MODE = 1, POW_PRECISION = 0, FORMAT = {
    prefix: "",
    groupSize: 3,
    secondaryGroupSize: 0,
    groupSeparator: ",",
    decimalSeparator: ".",
    fractionGroupSize: 0,
    fractionGroupSeparator: "\xA0",
    // non-breaking space
    suffix: ""
  }, ALPHABET = "0123456789abcdefghijklmnopqrstuvwxyz", alphabetHasNormalDecimalDigits = true;
  function BigNumber2(v, b) {
    var alphabet, c, caseChanged, e, i, isNum, len, str, x = this;
    if (!(x instanceof BigNumber2)) return new BigNumber2(v, b);
    if (b == null) {
      if (v && v._isBigNumber === true) {
        x.s = v.s;
        if (!v.c || v.e > MAX_EXP) {
          x.c = x.e = null;
        } else if (v.e < MIN_EXP) {
          x.c = [x.e = 0];
        } else {
          x.e = v.e;
          x.c = v.c.slice();
        }
        return;
      }
      if ((isNum = typeof v == "number") && v * 0 == 0) {
        x.s = 1 / v < 0 ? (v = -v, -1) : 1;
        if (v === ~~v) {
          for (e = 0, i = v; i >= 10; i /= 10, e++) ;
          if (e > MAX_EXP) {
            x.c = x.e = null;
          } else {
            x.e = e;
            x.c = [v];
          }
          return;
        }
        str = String(v);
      } else {
        if (!isNumeric.test(str = String(v))) return parseNumeric(x, str, isNum);
        x.s = str.charCodeAt(0) == 45 ? (str = str.slice(1), -1) : 1;
      }
      if ((e = str.indexOf(".")) > -1) str = str.replace(".", "");
      if ((i = str.search(/e/i)) > 0) {
        if (e < 0) e = i;
        e += +str.slice(i + 1);
        str = str.substring(0, i);
      } else if (e < 0) {
        e = str.length;
      }
    } else {
      intCheck(b, 2, ALPHABET.length, "Base");
      if (b == 10 && alphabetHasNormalDecimalDigits) {
        x = new BigNumber2(v);
        return round2(x, DECIMAL_PLACES + x.e + 1, ROUNDING_MODE);
      }
      str = String(v);
      if (isNum = typeof v == "number") {
        if (v * 0 != 0) return parseNumeric(x, str, isNum, b);
        x.s = 1 / v < 0 ? (str = str.slice(1), -1) : 1;
        if (BigNumber2.DEBUG && str.replace(/^0\.0*|\./, "").length > 15) {
          throw Error(tooManyDigits + v);
        }
      } else {
        x.s = str.charCodeAt(0) === 45 ? (str = str.slice(1), -1) : 1;
      }
      alphabet = ALPHABET.slice(0, b);
      e = i = 0;
      for (len = str.length; i < len; i++) {
        if (alphabet.indexOf(c = str.charAt(i)) < 0) {
          if (c == ".") {
            if (i > e) {
              e = len;
              continue;
            }
          } else if (!caseChanged) {
            if (str == str.toUpperCase() && (str = str.toLowerCase()) || str == str.toLowerCase() && (str = str.toUpperCase())) {
              caseChanged = true;
              i = -1;
              e = 0;
              continue;
            }
          }
          return parseNumeric(x, String(v), isNum, b);
        }
      }
      isNum = false;
      str = convertBase(str, b, 10, x.s);
      if ((e = str.indexOf(".")) > -1) str = str.replace(".", "");
      else e = str.length;
    }
    for (i = 0; str.charCodeAt(i) === 48; i++) ;
    for (len = str.length; str.charCodeAt(--len) === 48; ) ;
    if (str = str.slice(i, ++len)) {
      len -= i;
      if (isNum && BigNumber2.DEBUG && len > 15 && (v > MAX_SAFE_INTEGER || v !== mathfloor(v))) {
        throw Error(tooManyDigits + x.s * v);
      }
      if ((e = e - i - 1) > MAX_EXP) {
        x.c = x.e = null;
      } else if (e < MIN_EXP) {
        x.c = [x.e = 0];
      } else {
        x.e = e;
        x.c = [];
        i = (e + 1) % LOG_BASE;
        if (e < 0) i += LOG_BASE;
        if (i < len) {
          if (i) x.c.push(+str.slice(0, i));
          for (len -= LOG_BASE; i < len; ) {
            x.c.push(+str.slice(i, i += LOG_BASE));
          }
          i = LOG_BASE - (str = str.slice(i)).length;
        } else {
          i -= len;
        }
        for (; i--; str += "0") ;
        x.c.push(+str);
      }
    } else {
      x.c = [x.e = 0];
    }
  }
  __name(BigNumber2, "BigNumber");
  BigNumber2.clone = clone;
  BigNumber2.ROUND_UP = 0;
  BigNumber2.ROUND_DOWN = 1;
  BigNumber2.ROUND_CEIL = 2;
  BigNumber2.ROUND_FLOOR = 3;
  BigNumber2.ROUND_HALF_UP = 4;
  BigNumber2.ROUND_HALF_DOWN = 5;
  BigNumber2.ROUND_HALF_EVEN = 6;
  BigNumber2.ROUND_HALF_CEIL = 7;
  BigNumber2.ROUND_HALF_FLOOR = 8;
  BigNumber2.EUCLID = 9;
  BigNumber2.config = BigNumber2.set = function(obj) {
    var p, v;
    if (obj != null) {
      if (typeof obj == "object") {
        if (obj.hasOwnProperty(p = "DECIMAL_PLACES")) {
          v = obj[p];
          intCheck(v, 0, MAX, p);
          DECIMAL_PLACES = v;
        }
        if (obj.hasOwnProperty(p = "ROUNDING_MODE")) {
          v = obj[p];
          intCheck(v, 0, 8, p);
          ROUNDING_MODE = v;
        }
        if (obj.hasOwnProperty(p = "EXPONENTIAL_AT")) {
          v = obj[p];
          if (v && v.pop) {
            intCheck(v[0], -MAX, 0, p);
            intCheck(v[1], 0, MAX, p);
            TO_EXP_NEG = v[0];
            TO_EXP_POS = v[1];
          } else {
            intCheck(v, -MAX, MAX, p);
            TO_EXP_NEG = -(TO_EXP_POS = v < 0 ? -v : v);
          }
        }
        if (obj.hasOwnProperty(p = "RANGE")) {
          v = obj[p];
          if (v && v.pop) {
            intCheck(v[0], -MAX, -1, p);
            intCheck(v[1], 1, MAX, p);
            MIN_EXP = v[0];
            MAX_EXP = v[1];
          } else {
            intCheck(v, -MAX, MAX, p);
            if (v) {
              MIN_EXP = -(MAX_EXP = v < 0 ? -v : v);
            } else {
              throw Error(bignumberError + p + " cannot be zero: " + v);
            }
          }
        }
        if (obj.hasOwnProperty(p = "CRYPTO")) {
          v = obj[p];
          if (v === !!v) {
            if (v) {
              if (typeof crypto != "undefined" && crypto && (crypto.getRandomValues || crypto.randomBytes)) {
                CRYPTO = v;
              } else {
                CRYPTO = !v;
                throw Error(bignumberError + "crypto unavailable");
              }
            } else {
              CRYPTO = v;
            }
          } else {
            throw Error(bignumberError + p + " not true or false: " + v);
          }
        }
        if (obj.hasOwnProperty(p = "MODULO_MODE")) {
          v = obj[p];
          intCheck(v, 0, 9, p);
          MODULO_MODE = v;
        }
        if (obj.hasOwnProperty(p = "POW_PRECISION")) {
          v = obj[p];
          intCheck(v, 0, MAX, p);
          POW_PRECISION = v;
        }
        if (obj.hasOwnProperty(p = "FORMAT")) {
          v = obj[p];
          if (typeof v == "object") FORMAT = v;
          else throw Error(bignumberError + p + " not an object: " + v);
        }
        if (obj.hasOwnProperty(p = "ALPHABET")) {
          v = obj[p];
          if (typeof v == "string" && !/^.?$|[+\-.\s]|(.).*\1/.test(v)) {
            alphabetHasNormalDecimalDigits = v.slice(0, 10) == "0123456789";
            ALPHABET = v;
          } else {
            throw Error(bignumberError + p + " invalid: " + v);
          }
        }
      } else {
        throw Error(bignumberError + "Object expected: " + obj);
      }
    }
    return {
      DECIMAL_PLACES,
      ROUNDING_MODE,
      EXPONENTIAL_AT: [TO_EXP_NEG, TO_EXP_POS],
      RANGE: [MIN_EXP, MAX_EXP],
      CRYPTO,
      MODULO_MODE,
      POW_PRECISION,
      FORMAT,
      ALPHABET
    };
  };
  BigNumber2.isBigNumber = function(v) {
    if (!v || v._isBigNumber !== true) return false;
    if (!BigNumber2.DEBUG) return true;
    var i, n, c = v.c, e = v.e, s = v.s;
    out: if ({}.toString.call(c) == "[object Array]") {
      if ((s === 1 || s === -1) && e >= -MAX && e <= MAX && e === mathfloor(e)) {
        if (c[0] === 0) {
          if (e === 0 && c.length === 1) return true;
          break out;
        }
        i = (e + 1) % LOG_BASE;
        if (i < 1) i += LOG_BASE;
        if (String(c[0]).length == i) {
          for (i = 0; i < c.length; i++) {
            n = c[i];
            if (n < 0 || n >= BASE || n !== mathfloor(n)) break out;
          }
          if (n !== 0) return true;
        }
      }
    } else if (c === null && e === null && (s === null || s === 1 || s === -1)) {
      return true;
    }
    throw Error(bignumberError + "Invalid BigNumber: " + v);
  };
  BigNumber2.maximum = BigNumber2.max = function() {
    return maxOrMin(arguments, -1);
  };
  BigNumber2.minimum = BigNumber2.min = function() {
    return maxOrMin(arguments, 1);
  };
  BigNumber2.random = (function() {
    var pow2_53 = 9007199254740992;
    var random53bitInt = Math.random() * pow2_53 & 2097151 ? function() {
      return mathfloor(Math.random() * pow2_53);
    } : function() {
      return (Math.random() * 1073741824 | 0) * 8388608 + (Math.random() * 8388608 | 0);
    };
    return function(dp) {
      var a, b, e, k, v, i = 0, c = [], rand = new BigNumber2(ONE);
      if (dp == null) dp = DECIMAL_PLACES;
      else intCheck(dp, 0, MAX);
      k = mathceil(dp / LOG_BASE);
      if (CRYPTO) {
        if (crypto.getRandomValues) {
          a = crypto.getRandomValues(new Uint32Array(k *= 2));
          for (; i < k; ) {
            v = a[i] * 131072 + (a[i + 1] >>> 11);
            if (v >= 9e15) {
              b = crypto.getRandomValues(new Uint32Array(2));
              a[i] = b[0];
              a[i + 1] = b[1];
            } else {
              c.push(v % 1e14);
              i += 2;
            }
          }
          i = k / 2;
        } else if (crypto.randomBytes) {
          a = crypto.randomBytes(k *= 7);
          for (; i < k; ) {
            v = (a[i] & 31) * 281474976710656 + a[i + 1] * 1099511627776 + a[i + 2] * 4294967296 + a[i + 3] * 16777216 + (a[i + 4] << 16) + (a[i + 5] << 8) + a[i + 6];
            if (v >= 9e15) {
              crypto.randomBytes(7).copy(a, i);
            } else {
              c.push(v % 1e14);
              i += 7;
            }
          }
          i = k / 7;
        } else {
          CRYPTO = false;
          throw Error(bignumberError + "crypto unavailable");
        }
      }
      if (!CRYPTO) {
        for (; i < k; ) {
          v = random53bitInt();
          if (v < 9e15) c[i++] = v % 1e14;
        }
      }
      k = c[--i];
      dp %= LOG_BASE;
      if (k && dp) {
        v = POWS_TEN[LOG_BASE - dp];
        c[i] = mathfloor(k / v) * v;
      }
      for (; c[i] === 0; c.pop(), i--) ;
      if (i < 0) {
        c = [e = 0];
      } else {
        for (e = -1; c[0] === 0; c.splice(0, 1), e -= LOG_BASE) ;
        for (i = 1, v = c[0]; v >= 10; v /= 10, i++) ;
        if (i < LOG_BASE) e -= LOG_BASE - i;
      }
      rand.e = e;
      rand.c = c;
      return rand;
    };
  })();
  BigNumber2.sum = function() {
    var i = 1, args = arguments, sum = new BigNumber2(args[0]);
    for (; i < args.length; ) sum = sum.plus(args[i++]);
    return sum;
  };
  convertBase = /* @__PURE__ */ (function() {
    var decimal2 = "0123456789";
    function toBaseOut(str, baseIn, baseOut, alphabet) {
      var j, arr = [0], arrL, i = 0, len = str.length;
      for (; i < len; ) {
        for (arrL = arr.length; arrL--; arr[arrL] *= baseIn) ;
        arr[0] += alphabet.indexOf(str.charAt(i++));
        for (j = 0; j < arr.length; j++) {
          if (arr[j] > baseOut - 1) {
            if (arr[j + 1] == null) arr[j + 1] = 0;
            arr[j + 1] += arr[j] / baseOut | 0;
            arr[j] %= baseOut;
          }
        }
      }
      return arr.reverse();
    }
    __name(toBaseOut, "toBaseOut");
    return function(str, baseIn, baseOut, sign, callerIsToString) {
      var alphabet, d, e, k, r, x, xc, y, i = str.indexOf("."), dp = DECIMAL_PLACES, rm = ROUNDING_MODE;
      if (i >= 0) {
        k = POW_PRECISION;
        POW_PRECISION = 0;
        str = str.replace(".", "");
        y = new BigNumber2(baseIn);
        x = y.pow(str.length - i);
        POW_PRECISION = k;
        y.c = toBaseOut(
          toFixedPoint(coeffToString(x.c), x.e, "0"),
          10,
          baseOut,
          decimal2
        );
        y.e = y.c.length;
      }
      xc = toBaseOut(str, baseIn, baseOut, callerIsToString ? (alphabet = ALPHABET, decimal2) : (alphabet = decimal2, ALPHABET));
      e = k = xc.length;
      for (; xc[--k] == 0; xc.pop()) ;
      if (!xc[0]) return alphabet.charAt(0);
      if (i < 0) {
        --e;
      } else {
        x.c = xc;
        x.e = e;
        x.s = sign;
        x = div(x, y, dp, rm, baseOut);
        xc = x.c;
        r = x.r;
        e = x.e;
      }
      d = e + dp + 1;
      i = xc[d];
      k = baseOut / 2;
      r = r || d < 0 || xc[d + 1] != null;
      r = rm < 4 ? (i != null || r) && (rm == 0 || rm == (x.s < 0 ? 3 : 2)) : i > k || i == k && (rm == 4 || r || rm == 6 && xc[d - 1] & 1 || rm == (x.s < 0 ? 8 : 7));
      if (d < 1 || !xc[0]) {
        str = r ? toFixedPoint(alphabet.charAt(1), -dp, alphabet.charAt(0)) : alphabet.charAt(0);
      } else {
        xc.length = d;
        if (r) {
          for (--baseOut; ++xc[--d] > baseOut; ) {
            xc[d] = 0;
            if (!d) {
              ++e;
              xc = [1].concat(xc);
            }
          }
        }
        for (k = xc.length; !xc[--k]; ) ;
        for (i = 0, str = ""; i <= k; str += alphabet.charAt(xc[i++])) ;
        str = toFixedPoint(str, e, alphabet.charAt(0));
      }
      return str;
    };
  })();
  div = /* @__PURE__ */ (function() {
    function multiply(x, k, base) {
      var m, temp, xlo, xhi, carry = 0, i = x.length, klo = k % SQRT_BASE, khi = k / SQRT_BASE | 0;
      for (x = x.slice(); i--; ) {
        xlo = x[i] % SQRT_BASE;
        xhi = x[i] / SQRT_BASE | 0;
        m = khi * xlo + xhi * klo;
        temp = klo * xlo + m % SQRT_BASE * SQRT_BASE + carry;
        carry = (temp / base | 0) + (m / SQRT_BASE | 0) + khi * xhi;
        x[i] = temp % base;
      }
      if (carry) x = [carry].concat(x);
      return x;
    }
    __name(multiply, "multiply");
    function compare2(a, b, aL, bL) {
      var i, cmp;
      if (aL != bL) {
        cmp = aL > bL ? 1 : -1;
      } else {
        for (i = cmp = 0; i < aL; i++) {
          if (a[i] != b[i]) {
            cmp = a[i] > b[i] ? 1 : -1;
            break;
          }
        }
      }
      return cmp;
    }
    __name(compare2, "compare");
    function subtract(a, b, aL, base) {
      var i = 0;
      for (; aL--; ) {
        a[aL] -= i;
        i = a[aL] < b[aL] ? 1 : 0;
        a[aL] = i * base + a[aL] - b[aL];
      }
      for (; !a[0] && a.length > 1; a.splice(0, 1)) ;
    }
    __name(subtract, "subtract");
    return function(x, y, dp, rm, base) {
      var cmp, e, i, more, n, prod, prodL, q, qc, rem, remL, rem0, xi, xL, yc0, yL, yz, s = x.s == y.s ? 1 : -1, xc = x.c, yc = y.c;
      if (!xc || !xc[0] || !yc || !yc[0]) {
        return new BigNumber2(
          // Return NaN if either NaN, or both Infinity or 0.
          !x.s || !y.s || (xc ? yc && xc[0] == yc[0] : !yc) ? NaN : (
            // Return ±0 if x is ±0 or y is ±Infinity, or return ±Infinity as y is ±0.
            xc && xc[0] == 0 || !yc ? s * 0 : s / 0
          )
        );
      }
      q = new BigNumber2(s);
      qc = q.c = [];
      e = x.e - y.e;
      s = dp + e + 1;
      if (!base) {
        base = BASE;
        e = bitFloor(x.e / LOG_BASE) - bitFloor(y.e / LOG_BASE);
        s = s / LOG_BASE | 0;
      }
      for (i = 0; yc[i] == (xc[i] || 0); i++) ;
      if (yc[i] > (xc[i] || 0)) e--;
      if (s < 0) {
        qc.push(1);
        more = true;
      } else {
        xL = xc.length;
        yL = yc.length;
        i = 0;
        s += 2;
        n = mathfloor(base / (yc[0] + 1));
        if (n > 1) {
          yc = multiply(yc, n, base);
          xc = multiply(xc, n, base);
          yL = yc.length;
          xL = xc.length;
        }
        xi = yL;
        rem = xc.slice(0, yL);
        remL = rem.length;
        for (; remL < yL; rem[remL++] = 0) ;
        yz = yc.slice();
        yz = [0].concat(yz);
        yc0 = yc[0];
        if (yc[1] >= base / 2) yc0++;
        do {
          n = 0;
          cmp = compare2(yc, rem, yL, remL);
          if (cmp < 0) {
            rem0 = rem[0];
            if (yL != remL) rem0 = rem0 * base + (rem[1] || 0);
            n = mathfloor(rem0 / yc0);
            if (n > 1) {
              if (n >= base) n = base - 1;
              prod = multiply(yc, n, base);
              prodL = prod.length;
              remL = rem.length;
              while (compare2(prod, rem, prodL, remL) == 1) {
                n--;
                subtract(prod, yL < prodL ? yz : yc, prodL, base);
                prodL = prod.length;
                cmp = 1;
              }
            } else {
              if (n == 0) {
                cmp = n = 1;
              }
              prod = yc.slice();
              prodL = prod.length;
            }
            if (prodL < remL) prod = [0].concat(prod);
            subtract(rem, prod, remL, base);
            remL = rem.length;
            if (cmp == -1) {
              while (compare2(yc, rem, yL, remL) < 1) {
                n++;
                subtract(rem, yL < remL ? yz : yc, remL, base);
                remL = rem.length;
              }
            }
          } else if (cmp === 0) {
            n++;
            rem = [0];
          }
          qc[i++] = n;
          if (rem[0]) {
            rem[remL++] = xc[xi] || 0;
          } else {
            rem = [xc[xi]];
            remL = 1;
          }
        } while ((xi++ < xL || rem[0] != null) && s--);
        more = rem[0] != null;
        if (!qc[0]) qc.splice(0, 1);
      }
      if (base == BASE) {
        for (i = 1, s = qc[0]; s >= 10; s /= 10, i++) ;
        round2(q, dp + (q.e = i + e * LOG_BASE - 1) + 1, rm, more);
      } else {
        q.e = e;
        q.r = +more;
      }
      return q;
    };
  })();
  function format(n, i, rm, id) {
    var c0, e, ne, len, str;
    if (rm == null) rm = ROUNDING_MODE;
    else intCheck(rm, 0, 8);
    if (!n.c) return n.toString();
    c0 = n.c[0];
    ne = n.e;
    if (i == null) {
      str = coeffToString(n.c);
      str = id == 1 || id == 2 && (ne <= TO_EXP_NEG || ne >= TO_EXP_POS) ? toExponential(str, ne) : toFixedPoint(str, ne, "0");
    } else {
      n = round2(new BigNumber2(n), i, rm);
      e = n.e;
      str = coeffToString(n.c);
      len = str.length;
      if (id == 1 || id == 2 && (i <= e || e <= TO_EXP_NEG)) {
        for (; len < i; str += "0", len++) ;
        str = toExponential(str, e);
      } else {
        i -= ne + (id === 2 && e > ne);
        str = toFixedPoint(str, e, "0");
        if (e + 1 > len) {
          if (--i > 0) for (str += "."; i--; str += "0") ;
        } else {
          i += e - len;
          if (i > 0) {
            if (e + 1 == len) str += ".";
            for (; i--; str += "0") ;
          }
        }
      }
    }
    return n.s < 0 && c0 ? "-" + str : str;
  }
  __name(format, "format");
  function maxOrMin(args, n) {
    var k, y, i = 1, x = new BigNumber2(args[0]);
    for (; i < args.length; i++) {
      y = new BigNumber2(args[i]);
      if (!y.s || (k = compare(x, y)) === n || k === 0 && x.s === n) {
        x = y;
      }
    }
    return x;
  }
  __name(maxOrMin, "maxOrMin");
  function normalise(n, c, e) {
    var i = 1, j = c.length;
    for (; !c[--j]; c.pop()) ;
    for (j = c[0]; j >= 10; j /= 10, i++) ;
    if ((e = i + e * LOG_BASE - 1) > MAX_EXP) {
      n.c = n.e = null;
    } else if (e < MIN_EXP) {
      n.c = [n.e = 0];
    } else {
      n.e = e;
      n.c = c;
    }
    return n;
  }
  __name(normalise, "normalise");
  parseNumeric = /* @__PURE__ */ (function() {
    var basePrefix = /^(-?)0([xbo])(?=\w[\w.]*$)/i, dotAfter = /^([^.]+)\.$/, dotBefore = /^\.([^.]+)$/, isInfinityOrNaN = /^-?(Infinity|NaN)$/, whitespaceOrPlus = /^\s*\+(?=[\w.])|^\s+|\s+$/g;
    return function(x, str, isNum, b) {
      var base, s = isNum ? str : str.replace(whitespaceOrPlus, "");
      if (isInfinityOrNaN.test(s)) {
        x.s = isNaN(s) ? null : s < 0 ? -1 : 1;
      } else {
        if (!isNum) {
          s = s.replace(basePrefix, function(m, p1, p2) {
            base = (p2 = p2.toLowerCase()) == "x" ? 16 : p2 == "b" ? 2 : 8;
            return !b || b == base ? p1 : m;
          });
          if (b) {
            base = b;
            s = s.replace(dotAfter, "$1").replace(dotBefore, "0.$1");
          }
          if (str != s) return new BigNumber2(s, base);
        }
        if (BigNumber2.DEBUG) {
          throw Error(bignumberError + "Not a" + (b ? " base " + b : "") + " number: " + str);
        }
        x.s = null;
      }
      x.c = x.e = null;
    };
  })();
  function round2(x, sd, rm, r) {
    var d, i, j, k, n, ni, rd, xc = x.c, pows10 = POWS_TEN;
    if (xc) {
      out: {
        for (d = 1, k = xc[0]; k >= 10; k /= 10, d++) ;
        i = sd - d;
        if (i < 0) {
          i += LOG_BASE;
          j = sd;
          n = xc[ni = 0];
          rd = mathfloor(n / pows10[d - j - 1] % 10);
        } else {
          ni = mathceil((i + 1) / LOG_BASE);
          if (ni >= xc.length) {
            if (r) {
              for (; xc.length <= ni; xc.push(0)) ;
              n = rd = 0;
              d = 1;
              i %= LOG_BASE;
              j = i - LOG_BASE + 1;
            } else {
              break out;
            }
          } else {
            n = k = xc[ni];
            for (d = 1; k >= 10; k /= 10, d++) ;
            i %= LOG_BASE;
            j = i - LOG_BASE + d;
            rd = j < 0 ? 0 : mathfloor(n / pows10[d - j - 1] % 10);
          }
        }
        r = r || sd < 0 || // Are there any non-zero digits after the rounding digit?
        // The expression  n % pows10[d - j - 1]  returns all digits of n to the right
        // of the digit at j, e.g. if n is 908714 and j is 2, the expression gives 714.
        xc[ni + 1] != null || (j < 0 ? n : n % pows10[d - j - 1]);
        r = rm < 4 ? (rd || r) && (rm == 0 || rm == (x.s < 0 ? 3 : 2)) : rd > 5 || rd == 5 && (rm == 4 || r || rm == 6 && // Check whether the digit to the left of the rounding digit is odd.
        (i > 0 ? j > 0 ? n / pows10[d - j] : 0 : xc[ni - 1]) % 10 & 1 || rm == (x.s < 0 ? 8 : 7));
        if (sd < 1 || !xc[0]) {
          xc.length = 0;
          if (r) {
            sd -= x.e + 1;
            xc[0] = pows10[(LOG_BASE - sd % LOG_BASE) % LOG_BASE];
            x.e = -sd || 0;
          } else {
            xc[0] = x.e = 0;
          }
          return x;
        }
        if (i == 0) {
          xc.length = ni;
          k = 1;
          ni--;
        } else {
          xc.length = ni + 1;
          k = pows10[LOG_BASE - i];
          xc[ni] = j > 0 ? mathfloor(n / pows10[d - j] % pows10[j]) * k : 0;
        }
        if (r) {
          for (; ; ) {
            if (ni == 0) {
              for (i = 1, j = xc[0]; j >= 10; j /= 10, i++) ;
              j = xc[0] += k;
              for (k = 1; j >= 10; j /= 10, k++) ;
              if (i != k) {
                x.e++;
                if (xc[0] == BASE) xc[0] = 1;
              }
              break;
            } else {
              xc[ni] += k;
              if (xc[ni] != BASE) break;
              xc[ni--] = 0;
              k = 1;
            }
          }
        }
        for (i = xc.length; xc[--i] === 0; xc.pop()) ;
      }
      if (x.e > MAX_EXP) {
        x.c = x.e = null;
      } else if (x.e < MIN_EXP) {
        x.c = [x.e = 0];
      }
    }
    return x;
  }
  __name(round2, "round");
  function valueOf(n) {
    var str, e = n.e;
    if (e === null) return n.toString();
    str = coeffToString(n.c);
    str = e <= TO_EXP_NEG || e >= TO_EXP_POS ? toExponential(str, e) : toFixedPoint(str, e, "0");
    return n.s < 0 ? "-" + str : str;
  }
  __name(valueOf, "valueOf");
  P.absoluteValue = P.abs = function() {
    var x = new BigNumber2(this);
    if (x.s < 0) x.s = 1;
    return x;
  };
  P.comparedTo = function(y, b) {
    return compare(this, new BigNumber2(y, b));
  };
  P.decimalPlaces = P.dp = function(dp, rm) {
    var c, n, v, x = this;
    if (dp != null) {
      intCheck(dp, 0, MAX);
      if (rm == null) rm = ROUNDING_MODE;
      else intCheck(rm, 0, 8);
      return round2(new BigNumber2(x), dp + x.e + 1, rm);
    }
    if (!(c = x.c)) return null;
    n = ((v = c.length - 1) - bitFloor(this.e / LOG_BASE)) * LOG_BASE;
    if (v = c[v]) for (; v % 10 == 0; v /= 10, n--) ;
    if (n < 0) n = 0;
    return n;
  };
  P.dividedBy = P.div = function(y, b) {
    return div(this, new BigNumber2(y, b), DECIMAL_PLACES, ROUNDING_MODE);
  };
  P.dividedToIntegerBy = P.idiv = function(y, b) {
    return div(this, new BigNumber2(y, b), 0, 1);
  };
  P.exponentiatedBy = P.pow = function(n, m) {
    var half, isModExp, i, k, more, nIsBig, nIsNeg, nIsOdd, y, x = this;
    n = new BigNumber2(n);
    if (n.c && !n.isInteger()) {
      throw Error(bignumberError + "Exponent not an integer: " + valueOf(n));
    }
    if (m != null) m = new BigNumber2(m);
    nIsBig = n.e > 14;
    if (!x.c || !x.c[0] || x.c[0] == 1 && !x.e && x.c.length == 1 || !n.c || !n.c[0]) {
      y = new BigNumber2(Math.pow(+valueOf(x), nIsBig ? n.s * (2 - isOdd(n)) : +valueOf(n)));
      return m ? y.mod(m) : y;
    }
    nIsNeg = n.s < 0;
    if (m) {
      if (m.c ? !m.c[0] : !m.s) return new BigNumber2(NaN);
      isModExp = !nIsNeg && x.isInteger() && m.isInteger();
      if (isModExp) x = x.mod(m);
    } else if (n.e > 9 && (x.e > 0 || x.e < -1 || (x.e == 0 ? x.c[0] > 1 || nIsBig && x.c[1] >= 24e7 : x.c[0] < 8e13 || nIsBig && x.c[0] <= 9999975e7))) {
      k = x.s < 0 && isOdd(n) ? -0 : 0;
      if (x.e > -1) k = 1 / k;
      return new BigNumber2(nIsNeg ? 1 / k : k);
    } else if (POW_PRECISION) {
      k = mathceil(POW_PRECISION / LOG_BASE + 2);
    }
    if (nIsBig) {
      half = new BigNumber2(0.5);
      if (nIsNeg) n.s = 1;
      nIsOdd = isOdd(n);
    } else {
      i = Math.abs(+valueOf(n));
      nIsOdd = i % 2;
    }
    y = new BigNumber2(ONE);
    for (; ; ) {
      if (nIsOdd) {
        y = y.times(x);
        if (!y.c) break;
        if (k) {
          if (y.c.length > k) y.c.length = k;
        } else if (isModExp) {
          y = y.mod(m);
        }
      }
      if (i) {
        i = mathfloor(i / 2);
        if (i === 0) break;
        nIsOdd = i % 2;
      } else {
        n = n.times(half);
        round2(n, n.e + 1, 1);
        if (n.e > 14) {
          nIsOdd = isOdd(n);
        } else {
          i = +valueOf(n);
          if (i === 0) break;
          nIsOdd = i % 2;
        }
      }
      x = x.times(x);
      if (k) {
        if (x.c && x.c.length > k) x.c.length = k;
      } else if (isModExp) {
        x = x.mod(m);
      }
    }
    if (isModExp) return y;
    if (nIsNeg) y = ONE.div(y);
    return m ? y.mod(m) : k ? round2(y, POW_PRECISION, ROUNDING_MODE, more) : y;
  };
  P.integerValue = function(rm) {
    var n = new BigNumber2(this);
    if (rm == null) rm = ROUNDING_MODE;
    else intCheck(rm, 0, 8);
    return round2(n, n.e + 1, rm);
  };
  P.isEqualTo = P.eq = function(y, b) {
    return compare(this, new BigNumber2(y, b)) === 0;
  };
  P.isFinite = function() {
    return !!this.c;
  };
  P.isGreaterThan = P.gt = function(y, b) {
    return compare(this, new BigNumber2(y, b)) > 0;
  };
  P.isGreaterThanOrEqualTo = P.gte = function(y, b) {
    return (b = compare(this, new BigNumber2(y, b))) === 1 || b === 0;
  };
  P.isInteger = function() {
    return !!this.c && bitFloor(this.e / LOG_BASE) > this.c.length - 2;
  };
  P.isLessThan = P.lt = function(y, b) {
    return compare(this, new BigNumber2(y, b)) < 0;
  };
  P.isLessThanOrEqualTo = P.lte = function(y, b) {
    return (b = compare(this, new BigNumber2(y, b))) === -1 || b === 0;
  };
  P.isNaN = function() {
    return !this.s;
  };
  P.isNegative = function() {
    return this.s < 0;
  };
  P.isPositive = function() {
    return this.s > 0;
  };
  P.isZero = function() {
    return !!this.c && this.c[0] == 0;
  };
  P.minus = function(y, b) {
    var i, j, t, xLTy, x = this, a = x.s;
    y = new BigNumber2(y, b);
    b = y.s;
    if (!a || !b) return new BigNumber2(NaN);
    if (a != b) {
      y.s = -b;
      return x.plus(y);
    }
    var xe = x.e / LOG_BASE, ye = y.e / LOG_BASE, xc = x.c, yc = y.c;
    if (!xe || !ye) {
      if (!xc || !yc) return xc ? (y.s = -b, y) : new BigNumber2(yc ? x : NaN);
      if (!xc[0] || !yc[0]) {
        return yc[0] ? (y.s = -b, y) : new BigNumber2(xc[0] ? x : (
          // IEEE 754 (2008) 6.3: n - n = -0 when rounding to -Infinity
          ROUNDING_MODE == 3 ? -0 : 0
        ));
      }
    }
    xe = bitFloor(xe);
    ye = bitFloor(ye);
    xc = xc.slice();
    if (a = xe - ye) {
      if (xLTy = a < 0) {
        a = -a;
        t = xc;
      } else {
        ye = xe;
        t = yc;
      }
      t.reverse();
      for (b = a; b--; t.push(0)) ;
      t.reverse();
    } else {
      j = (xLTy = (a = xc.length) < (b = yc.length)) ? a : b;
      for (a = b = 0; b < j; b++) {
        if (xc[b] != yc[b]) {
          xLTy = xc[b] < yc[b];
          break;
        }
      }
    }
    if (xLTy) {
      t = xc;
      xc = yc;
      yc = t;
      y.s = -y.s;
    }
    b = (j = yc.length) - (i = xc.length);
    if (b > 0) for (; b--; xc[i++] = 0) ;
    b = BASE - 1;
    for (; j > a; ) {
      if (xc[--j] < yc[j]) {
        for (i = j; i && !xc[--i]; xc[i] = b) ;
        --xc[i];
        xc[j] += BASE;
      }
      xc[j] -= yc[j];
    }
    for (; xc[0] == 0; xc.splice(0, 1), --ye) ;
    if (!xc[0]) {
      y.s = ROUNDING_MODE == 3 ? -1 : 1;
      y.c = [y.e = 0];
      return y;
    }
    return normalise(y, xc, ye);
  };
  P.modulo = P.mod = function(y, b) {
    var q, s, x = this;
    y = new BigNumber2(y, b);
    if (!x.c || !y.s || y.c && !y.c[0]) {
      return new BigNumber2(NaN);
    } else if (!y.c || x.c && !x.c[0]) {
      return new BigNumber2(x);
    }
    if (MODULO_MODE == 9) {
      s = y.s;
      y.s = 1;
      q = div(x, y, 0, 3);
      y.s = s;
      q.s *= s;
    } else {
      q = div(x, y, 0, MODULO_MODE);
    }
    y = x.minus(q.times(y));
    if (!y.c[0] && MODULO_MODE == 1) y.s = x.s;
    return y;
  };
  P.multipliedBy = P.times = function(y, b) {
    var c, e, i, j, k, m, xcL, xlo, xhi, ycL, ylo, yhi, zc, base, sqrtBase, x = this, xc = x.c, yc = (y = new BigNumber2(y, b)).c;
    if (!xc || !yc || !xc[0] || !yc[0]) {
      if (!x.s || !y.s || xc && !xc[0] && !yc || yc && !yc[0] && !xc) {
        y.c = y.e = y.s = null;
      } else {
        y.s *= x.s;
        if (!xc || !yc) {
          y.c = y.e = null;
        } else {
          y.c = [0];
          y.e = 0;
        }
      }
      return y;
    }
    e = bitFloor(x.e / LOG_BASE) + bitFloor(y.e / LOG_BASE);
    y.s *= x.s;
    xcL = xc.length;
    ycL = yc.length;
    if (xcL < ycL) {
      zc = xc;
      xc = yc;
      yc = zc;
      i = xcL;
      xcL = ycL;
      ycL = i;
    }
    for (i = xcL + ycL, zc = []; i--; zc.push(0)) ;
    base = BASE;
    sqrtBase = SQRT_BASE;
    for (i = ycL; --i >= 0; ) {
      c = 0;
      ylo = yc[i] % sqrtBase;
      yhi = yc[i] / sqrtBase | 0;
      for (k = xcL, j = i + k; j > i; ) {
        xlo = xc[--k] % sqrtBase;
        xhi = xc[k] / sqrtBase | 0;
        m = yhi * xlo + xhi * ylo;
        xlo = ylo * xlo + m % sqrtBase * sqrtBase + zc[j] + c;
        c = (xlo / base | 0) + (m / sqrtBase | 0) + yhi * xhi;
        zc[j--] = xlo % base;
      }
      zc[j] = c;
    }
    if (c) {
      ++e;
    } else {
      zc.splice(0, 1);
    }
    return normalise(y, zc, e);
  };
  P.negated = function() {
    var x = new BigNumber2(this);
    x.s = -x.s || null;
    return x;
  };
  P.plus = function(y, b) {
    var t, x = this, a = x.s;
    y = new BigNumber2(y, b);
    b = y.s;
    if (!a || !b) return new BigNumber2(NaN);
    if (a != b) {
      y.s = -b;
      return x.minus(y);
    }
    var xe = x.e / LOG_BASE, ye = y.e / LOG_BASE, xc = x.c, yc = y.c;
    if (!xe || !ye) {
      if (!xc || !yc) return new BigNumber2(a / 0);
      if (!xc[0] || !yc[0]) return yc[0] ? y : new BigNumber2(xc[0] ? x : a * 0);
    }
    xe = bitFloor(xe);
    ye = bitFloor(ye);
    xc = xc.slice();
    if (a = xe - ye) {
      if (a > 0) {
        ye = xe;
        t = yc;
      } else {
        a = -a;
        t = xc;
      }
      t.reverse();
      for (; a--; t.push(0)) ;
      t.reverse();
    }
    a = xc.length;
    b = yc.length;
    if (a - b < 0) {
      t = yc;
      yc = xc;
      xc = t;
      b = a;
    }
    for (a = 0; b; ) {
      a = (xc[--b] = xc[b] + yc[b] + a) / BASE | 0;
      xc[b] = BASE === xc[b] ? 0 : xc[b] % BASE;
    }
    if (a) {
      xc = [a].concat(xc);
      ++ye;
    }
    return normalise(y, xc, ye);
  };
  P.precision = P.sd = function(sd, rm) {
    var c, n, v, x = this;
    if (sd != null && sd !== !!sd) {
      intCheck(sd, 1, MAX);
      if (rm == null) rm = ROUNDING_MODE;
      else intCheck(rm, 0, 8);
      return round2(new BigNumber2(x), sd, rm);
    }
    if (!(c = x.c)) return null;
    v = c.length - 1;
    n = v * LOG_BASE + 1;
    if (v = c[v]) {
      for (; v % 10 == 0; v /= 10, n--) ;
      for (v = c[0]; v >= 10; v /= 10, n++) ;
    }
    if (sd && x.e + 1 > n) n = x.e + 1;
    return n;
  };
  P.shiftedBy = function(k) {
    intCheck(k, -MAX_SAFE_INTEGER, MAX_SAFE_INTEGER);
    return this.times("1e" + k);
  };
  P.squareRoot = P.sqrt = function() {
    var m, n, r, rep, t, x = this, c = x.c, s = x.s, e = x.e, dp = DECIMAL_PLACES + 4, half = new BigNumber2("0.5");
    if (s !== 1 || !c || !c[0]) {
      return new BigNumber2(!s || s < 0 && (!c || c[0]) ? NaN : c ? x : 1 / 0);
    }
    s = Math.sqrt(+valueOf(x));
    if (s == 0 || s == 1 / 0) {
      n = coeffToString(c);
      if ((n.length + e) % 2 == 0) n += "0";
      s = Math.sqrt(+n);
      e = bitFloor((e + 1) / 2) - (e < 0 || e % 2);
      if (s == 1 / 0) {
        n = "5e" + e;
      } else {
        n = s.toExponential();
        n = n.slice(0, n.indexOf("e") + 1) + e;
      }
      r = new BigNumber2(n);
    } else {
      r = new BigNumber2(s + "");
    }
    if (r.c[0]) {
      e = r.e;
      s = e + dp;
      if (s < 3) s = 0;
      for (; ; ) {
        t = r;
        r = half.times(t.plus(div(x, t, dp, 1)));
        if (coeffToString(t.c).slice(0, s) === (n = coeffToString(r.c)).slice(0, s)) {
          if (r.e < e) --s;
          n = n.slice(s - 3, s + 1);
          if (n == "9999" || !rep && n == "4999") {
            if (!rep) {
              round2(t, t.e + DECIMAL_PLACES + 2, 0);
              if (t.times(t).eq(x)) {
                r = t;
                break;
              }
            }
            dp += 4;
            s += 4;
            rep = 1;
          } else {
            if (!+n || !+n.slice(1) && n.charAt(0) == "5") {
              round2(r, r.e + DECIMAL_PLACES + 2, 1);
              m = !r.times(r).eq(x);
            }
            break;
          }
        }
      }
    }
    return round2(r, r.e + DECIMAL_PLACES + 1, ROUNDING_MODE, m);
  };
  P.toExponential = function(dp, rm) {
    if (dp != null) {
      intCheck(dp, 0, MAX);
      dp++;
    }
    return format(this, dp, rm, 1);
  };
  P.toFixed = function(dp, rm) {
    if (dp != null) {
      intCheck(dp, 0, MAX);
      dp = dp + this.e + 1;
    }
    return format(this, dp, rm);
  };
  P.toFormat = function(dp, rm, format2) {
    var str, x = this;
    if (format2 == null) {
      if (dp != null && rm && typeof rm == "object") {
        format2 = rm;
        rm = null;
      } else if (dp && typeof dp == "object") {
        format2 = dp;
        dp = rm = null;
      } else {
        format2 = FORMAT;
      }
    } else if (typeof format2 != "object") {
      throw Error(bignumberError + "Argument not an object: " + format2);
    }
    str = x.toFixed(dp, rm);
    if (x.c) {
      var i, arr = str.split("."), g1 = +format2.groupSize, g2 = +format2.secondaryGroupSize, groupSeparator = format2.groupSeparator || "", intPart = arr[0], fractionPart = arr[1], isNeg = x.s < 0, intDigits = isNeg ? intPart.slice(1) : intPart, len = intDigits.length;
      if (g2) {
        i = g1;
        g1 = g2;
        g2 = i;
        len -= i;
      }
      if (g1 > 0 && len > 0) {
        i = len % g1 || g1;
        intPart = intDigits.substr(0, i);
        for (; i < len; i += g1) intPart += groupSeparator + intDigits.substr(i, g1);
        if (g2 > 0) intPart += groupSeparator + intDigits.slice(i);
        if (isNeg) intPart = "-" + intPart;
      }
      str = fractionPart ? intPart + (format2.decimalSeparator || "") + ((g2 = +format2.fractionGroupSize) ? fractionPart.replace(
        new RegExp("\\d{" + g2 + "}\\B", "g"),
        "$&" + (format2.fractionGroupSeparator || "")
      ) : fractionPart) : intPart;
    }
    return (format2.prefix || "") + str + (format2.suffix || "");
  };
  P.toFraction = function(md) {
    var d, d0, d1, d2, e, exp, n, n0, n1, q, r, s, x = this, xc = x.c;
    if (md != null) {
      n = new BigNumber2(md);
      if (!n.isInteger() && (n.c || n.s !== 1) || n.lt(ONE)) {
        throw Error(bignumberError + "Argument " + (n.isInteger() ? "out of range: " : "not an integer: ") + valueOf(n));
      }
    }
    if (!xc) return new BigNumber2(x);
    d = new BigNumber2(ONE);
    n1 = d0 = new BigNumber2(ONE);
    d1 = n0 = new BigNumber2(ONE);
    s = coeffToString(xc);
    e = d.e = s.length - x.e - 1;
    d.c[0] = POWS_TEN[(exp = e % LOG_BASE) < 0 ? LOG_BASE + exp : exp];
    md = !md || n.comparedTo(d) > 0 ? e > 0 ? d : n1 : n;
    exp = MAX_EXP;
    MAX_EXP = 1 / 0;
    n = new BigNumber2(s);
    n0.c[0] = 0;
    for (; ; ) {
      q = div(n, d, 0, 1);
      d2 = d0.plus(q.times(d1));
      if (d2.comparedTo(md) == 1) break;
      d0 = d1;
      d1 = d2;
      n1 = n0.plus(q.times(d2 = n1));
      n0 = d2;
      d = n.minus(q.times(d2 = d));
      n = d2;
    }
    d2 = div(md.minus(d0), d1, 0, 1);
    n0 = n0.plus(d2.times(n1));
    d0 = d0.plus(d2.times(d1));
    n0.s = n1.s = x.s;
    e = e * 2;
    r = div(n1, d1, e, ROUNDING_MODE).minus(x).abs().comparedTo(
      div(n0, d0, e, ROUNDING_MODE).minus(x).abs()
    ) < 1 ? [n1, d1] : [n0, d0];
    MAX_EXP = exp;
    return r;
  };
  P.toNumber = function() {
    return +valueOf(this);
  };
  P.toPrecision = function(sd, rm) {
    if (sd != null) intCheck(sd, 1, MAX);
    return format(this, sd, rm, 2);
  };
  P.toString = function(b) {
    var str, n = this, s = n.s, e = n.e;
    if (e === null) {
      if (s) {
        str = "Infinity";
        if (s < 0) str = "-" + str;
      } else {
        str = "NaN";
      }
    } else {
      if (b == null) {
        str = e <= TO_EXP_NEG || e >= TO_EXP_POS ? toExponential(coeffToString(n.c), e) : toFixedPoint(coeffToString(n.c), e, "0");
      } else if (b === 10 && alphabetHasNormalDecimalDigits) {
        n = round2(new BigNumber2(n), DECIMAL_PLACES + e + 1, ROUNDING_MODE);
        str = toFixedPoint(coeffToString(n.c), n.e, "0");
      } else {
        intCheck(b, 2, ALPHABET.length, "Base");
        str = convertBase(toFixedPoint(coeffToString(n.c), e, "0"), 10, b, s, true);
      }
      if (s < 0 && n.c[0]) str = "-" + str;
    }
    return str;
  };
  P.valueOf = P.toJSON = function() {
    return valueOf(this);
  };
  P._isBigNumber = true;
  P[Symbol.toStringTag] = "BigNumber";
  P[/* @__PURE__ */ Symbol.for("nodejs.util.inspect.custom")] = P.valueOf;
  if (configObject != null) BigNumber2.set(configObject);
  return BigNumber2;
}
__name(clone, "clone");
function bitFloor(n) {
  var i = n | 0;
  return n > 0 || n === i ? i : i - 1;
}
__name(bitFloor, "bitFloor");
function coeffToString(a) {
  var s, z, i = 1, j = a.length, r = a[0] + "";
  for (; i < j; ) {
    s = a[i++] + "";
    z = LOG_BASE - s.length;
    for (; z--; s = "0" + s) ;
    r += s;
  }
  for (j = r.length; r.charCodeAt(--j) === 48; ) ;
  return r.slice(0, j + 1 || 1);
}
__name(coeffToString, "coeffToString");
function compare(x, y) {
  var a, b, xc = x.c, yc = y.c, i = x.s, j = y.s, k = x.e, l = y.e;
  if (!i || !j) return null;
  a = xc && !xc[0];
  b = yc && !yc[0];
  if (a || b) return a ? b ? 0 : -j : i;
  if (i != j) return i;
  a = i < 0;
  b = k == l;
  if (!xc || !yc) return b ? 0 : !xc ^ a ? 1 : -1;
  if (!b) return k > l ^ a ? 1 : -1;
  j = (k = xc.length) < (l = yc.length) ? k : l;
  for (i = 0; i < j; i++) if (xc[i] != yc[i]) return xc[i] > yc[i] ^ a ? 1 : -1;
  return k == l ? 0 : k > l ^ a ? 1 : -1;
}
__name(compare, "compare");
function intCheck(n, min, max, name) {
  if (n < min || n > max || n !== mathfloor(n)) {
    throw Error(bignumberError + (name || "Argument") + (typeof n == "number" ? n < min || n > max ? " out of range: " : " not an integer: " : " not a primitive number: ") + String(n));
  }
}
__name(intCheck, "intCheck");
function isOdd(n) {
  var k = n.c.length - 1;
  return bitFloor(n.e / LOG_BASE) == k && n.c[k] % 2 != 0;
}
__name(isOdd, "isOdd");
function toExponential(str, e) {
  return (str.length > 1 ? str.charAt(0) + "." + str.slice(1) : str) + (e < 0 ? "e" : "e+") + e;
}
__name(toExponential, "toExponential");
function toFixedPoint(str, e, z) {
  var len, zs;
  if (e < 0) {
    for (zs = z + "."; ++e; zs += z) ;
    str = zs + str;
  } else {
    len = str.length;
    if (++e > len) {
      for (zs = z, e -= len; --e; zs += z) ;
      str += zs;
    } else if (e < len) {
      str = str.slice(0, e) + "." + str.slice(e);
    }
  }
  return str;
}
__name(toFixedPoint, "toFixedPoint");
var BigNumber = clone();
var bignumber_default = BigNumber;

// ../../src/services/testMarkets/testMarketDepth.ts
function testMarketDepth(simulation, now) {
  const { asset } = simulation;
  const empty = {
    source: "simulation",
    pair: asset.pair,
    isTestAsset: true,
    available: false,
    bids: [],
    asks: [],
    timestamp: now
  };
  const current = simulation.priceAt(now);
  if (current === null) return empty;
  const bucket = Math.floor((now - asset.listingAt) / TICK_MS2);
  const bid = new bignumber_default(current).decimalPlaces(10, bignumber_default.ROUND_DOWN);
  const quantum = new bignumber_default("0.0000000001");
  const step = bignumber_default.maximum(quantum, bid.times("0.0002").decimalPlaces(10, bignumber_default.ROUND_UP));
  const spread = step.times(2);
  const sides = /* @__PURE__ */ __name((side) => Array.from({ length: 25 }, (_, level) => {
    const random = seededRandom(asset.seed, "display-depth", bucket, side, level);
    const price = side === "bid" ? bid.minus(step.times(level)) : bid.plus(spread).plus(step.times(level));
    const quoteSize = (80 + level * 28) * (0.8 + random() * 0.4);
    return {
      price: bignumber_default.maximum(quantum, price).toFixed(10),
      quantity: new bignumber_default(quoteSize).div(price).decimalPlaces(8, bignumber_default.ROUND_DOWN).toFixed(8)
    };
  }), "sides");
  return { ...empty, available: true, bids: sides("bid"), asks: sides("ask"), timestamp: asset.listingAt + bucket * TICK_MS2 };
}
__name(testMarketDepth, "testMarketDepth");

// ../../src/services/testMarkets/testMarketService.ts
var TEST_ASSET_STATUS_LABEL = "TEST \xB7 NOT TRADABLE";
function effectiveTestMarketNow(asset, now) {
  return asset.listingArmed ? now : Math.min(now, asset.listingAt - 1);
}
__name(effectiveTestMarketNow, "effectiveTestMarketNow");
function publicTestAsset(asset, now) {
  const marketNow = effectiveTestMarketNow(asset, now);
  return {
    pair: asset.pair,
    symbol: asset.symbol,
    name: asset.name,
    quote: asset.quote,
    isTestAsset: true,
    isTradable: asset.isTradable,
    status: asset.isTradable ? "SPOT" : TEST_ASSET_STATUS_LABEL,
    listingArmed: asset.listingArmed,
    listingAt: new Date(asset.listingAt).toISOString(),
    initialPrice: asset.initialPrice,
    state: getCurrentTestMarketState(simulationFor(asset), marketNow)
  };
}
__name(publicTestAsset, "publicTestAsset");
var UnsupportedTestIntervalError = class extends Error {
  static {
    __name(this, "UnsupportedTestIntervalError");
  }
};
function testMarketCandles(asset, interval, now, limit = 300) {
  const marketNow = effectiveTestMarketNow(asset, now);
  const size = SIM_INTERVALS[interval];
  if (!size) throw new UnsupportedTestIntervalError(`Unsupported interval: ${interval}`);
  const offset = SIM_INTERVAL_OFFSETS[interval] ?? 0;
  const count = Math.max(1, Math.min(Math.floor(limit) || 300, 1e3));
  const currentBucket = Math.floor((marketNow - offset) / size) * size + offset;
  const from = Math.max(asset.listingAt, currentBucket - (count - 1) * size);
  const simulation = simulationFor(asset);
  const candles = size === MINUTE_MS ? simulation.candles1m(marketNow, from) : aggregateCandles(simulation.candles5m(marketNow, from), size, offset);
  return candles.filter((candle) => candle.openTime >= currentBucket - (count - 1) * size).slice(-count).map((candle) => ({
    time: Math.floor(candle.openTime / 1e3),
    open: candle.open,
    high: candle.high,
    low: candle.low,
    close: candle.close,
    volume: candle.volume
  }));
}
__name(testMarketCandles, "testMarketCandles");

// ../../src/services/testMarkets/nrxPublic.ts
var headers = {
  "content-type": "application/json; charset=utf-8",
  "cache-control": "no-store",
  "access-control-allow-origin": "*",
  "access-control-allow-methods": "GET, HEAD, OPTIONS"
};
function nrxPublicResponse(request, _clock = Date.now) {
  const url = new URL(request.url);
  let path = url.pathname;
  try {
    path = decodeURIComponent(path);
  } catch {
  }
  if (!path.toUpperCase().includes("NRX")) return null;
  if (request.method === "OPTIONS") return new Response(null, { status: 204, headers });
  const status = ["GET", "HEAD"].includes(request.method) ? 410 : 405;
  return new Response(request.method === "HEAD" ? null : JSON.stringify({
    error: status === 410 ? "market_retired" : "method_not_allowed",
    symbol: "NRX"
  }), { status, headers });
}
__name(nrxPublicResponse, "nrxPublicResponse");

// ../../node_modules/zod/v3/external.js
var external_exports = {};
__export(external_exports, {
  BRAND: () => BRAND,
  DIRTY: () => DIRTY,
  EMPTY_PATH: () => EMPTY_PATH,
  INVALID: () => INVALID,
  NEVER: () => NEVER,
  OK: () => OK,
  ParseStatus: () => ParseStatus,
  Schema: () => ZodType,
  ZodAny: () => ZodAny,
  ZodArray: () => ZodArray,
  ZodBigInt: () => ZodBigInt,
  ZodBoolean: () => ZodBoolean,
  ZodBranded: () => ZodBranded,
  ZodCatch: () => ZodCatch,
  ZodDate: () => ZodDate,
  ZodDefault: () => ZodDefault,
  ZodDiscriminatedUnion: () => ZodDiscriminatedUnion,
  ZodEffects: () => ZodEffects,
  ZodEnum: () => ZodEnum,
  ZodError: () => ZodError,
  ZodFirstPartyTypeKind: () => ZodFirstPartyTypeKind,
  ZodFunction: () => ZodFunction,
  ZodIntersection: () => ZodIntersection,
  ZodIssueCode: () => ZodIssueCode,
  ZodLazy: () => ZodLazy,
  ZodLiteral: () => ZodLiteral,
  ZodMap: () => ZodMap,
  ZodNaN: () => ZodNaN,
  ZodNativeEnum: () => ZodNativeEnum,
  ZodNever: () => ZodNever,
  ZodNull: () => ZodNull,
  ZodNullable: () => ZodNullable,
  ZodNumber: () => ZodNumber,
  ZodObject: () => ZodObject,
  ZodOptional: () => ZodOptional,
  ZodParsedType: () => ZodParsedType,
  ZodPipeline: () => ZodPipeline,
  ZodPromise: () => ZodPromise,
  ZodReadonly: () => ZodReadonly,
  ZodRecord: () => ZodRecord,
  ZodSchema: () => ZodType,
  ZodSet: () => ZodSet,
  ZodString: () => ZodString,
  ZodSymbol: () => ZodSymbol,
  ZodTransformer: () => ZodEffects,
  ZodTuple: () => ZodTuple,
  ZodType: () => ZodType,
  ZodUndefined: () => ZodUndefined,
  ZodUnion: () => ZodUnion,
  ZodUnknown: () => ZodUnknown,
  ZodVoid: () => ZodVoid,
  addIssueToContext: () => addIssueToContext,
  any: () => anyType,
  array: () => arrayType,
  bigint: () => bigIntType,
  boolean: () => booleanType,
  coerce: () => coerce,
  custom: () => custom,
  date: () => dateType,
  datetimeRegex: () => datetimeRegex,
  defaultErrorMap: () => en_default,
  discriminatedUnion: () => discriminatedUnionType,
  effect: () => effectsType,
  enum: () => enumType,
  function: () => functionType,
  getErrorMap: () => getErrorMap,
  getParsedType: () => getParsedType,
  instanceof: () => instanceOfType,
  intersection: () => intersectionType,
  isAborted: () => isAborted,
  isAsync: () => isAsync,
  isDirty: () => isDirty,
  isValid: () => isValid,
  late: () => late,
  lazy: () => lazyType,
  literal: () => literalType,
  makeIssue: () => makeIssue,
  map: () => mapType,
  nan: () => nanType,
  nativeEnum: () => nativeEnumType,
  never: () => neverType,
  null: () => nullType,
  nullable: () => nullableType,
  number: () => numberType,
  object: () => objectType,
  objectUtil: () => objectUtil,
  oboolean: () => oboolean,
  onumber: () => onumber,
  optional: () => optionalType,
  ostring: () => ostring,
  pipeline: () => pipelineType,
  preprocess: () => preprocessType,
  promise: () => promiseType,
  quotelessJson: () => quotelessJson,
  record: () => recordType,
  set: () => setType,
  setErrorMap: () => setErrorMap,
  strictObject: () => strictObjectType,
  string: () => stringType,
  symbol: () => symbolType,
  transformer: () => effectsType,
  tuple: () => tupleType,
  undefined: () => undefinedType,
  union: () => unionType,
  unknown: () => unknownType,
  util: () => util,
  void: () => voidType
});

// ../../node_modules/zod/v3/helpers/util.js
var util;
(function(util2) {
  util2.assertEqual = (_) => {
  };
  function assertIs(_arg) {
  }
  __name(assertIs, "assertIs");
  util2.assertIs = assertIs;
  function assertNever(_x) {
    throw new Error();
  }
  __name(assertNever, "assertNever");
  util2.assertNever = assertNever;
  util2.arrayToEnum = (items) => {
    const obj = {};
    for (const item of items) {
      obj[item] = item;
    }
    return obj;
  };
  util2.getValidEnumValues = (obj) => {
    const validKeys = util2.objectKeys(obj).filter((k) => typeof obj[obj[k]] !== "number");
    const filtered = {};
    for (const k of validKeys) {
      filtered[k] = obj[k];
    }
    return util2.objectValues(filtered);
  };
  util2.objectValues = (obj) => {
    return util2.objectKeys(obj).map(function(e) {
      return obj[e];
    });
  };
  util2.objectKeys = typeof Object.keys === "function" ? (obj) => Object.keys(obj) : (object) => {
    const keys = [];
    for (const key in object) {
      if (Object.prototype.hasOwnProperty.call(object, key)) {
        keys.push(key);
      }
    }
    return keys;
  };
  util2.find = (arr, checker) => {
    for (const item of arr) {
      if (checker(item))
        return item;
    }
    return void 0;
  };
  util2.isInteger = typeof Number.isInteger === "function" ? (val) => Number.isInteger(val) : (val) => typeof val === "number" && Number.isFinite(val) && Math.floor(val) === val;
  function joinValues(array, separator = " | ") {
    return array.map((val) => typeof val === "string" ? `'${val}'` : val).join(separator);
  }
  __name(joinValues, "joinValues");
  util2.joinValues = joinValues;
  util2.jsonStringifyReplacer = (_, value) => {
    if (typeof value === "bigint") {
      return value.toString();
    }
    return value;
  };
})(util || (util = {}));
var objectUtil;
(function(objectUtil2) {
  objectUtil2.mergeShapes = (first, second) => {
    return {
      ...first,
      ...second
      // second overwrites first
    };
  };
})(objectUtil || (objectUtil = {}));
var ZodParsedType = util.arrayToEnum([
  "string",
  "nan",
  "number",
  "integer",
  "float",
  "boolean",
  "date",
  "bigint",
  "symbol",
  "function",
  "undefined",
  "null",
  "array",
  "object",
  "unknown",
  "promise",
  "void",
  "never",
  "map",
  "set"
]);
var getParsedType = /* @__PURE__ */ __name((data) => {
  const t = typeof data;
  switch (t) {
    case "undefined":
      return ZodParsedType.undefined;
    case "string":
      return ZodParsedType.string;
    case "number":
      return Number.isNaN(data) ? ZodParsedType.nan : ZodParsedType.number;
    case "boolean":
      return ZodParsedType.boolean;
    case "function":
      return ZodParsedType.function;
    case "bigint":
      return ZodParsedType.bigint;
    case "symbol":
      return ZodParsedType.symbol;
    case "object":
      if (Array.isArray(data)) {
        return ZodParsedType.array;
      }
      if (data === null) {
        return ZodParsedType.null;
      }
      if (data.then && typeof data.then === "function" && data.catch && typeof data.catch === "function") {
        return ZodParsedType.promise;
      }
      if (typeof Map !== "undefined" && data instanceof Map) {
        return ZodParsedType.map;
      }
      if (typeof Set !== "undefined" && data instanceof Set) {
        return ZodParsedType.set;
      }
      if (typeof Date !== "undefined" && data instanceof Date) {
        return ZodParsedType.date;
      }
      return ZodParsedType.object;
    default:
      return ZodParsedType.unknown;
  }
}, "getParsedType");

// ../../node_modules/zod/v3/ZodError.js
var ZodIssueCode = util.arrayToEnum([
  "invalid_type",
  "invalid_literal",
  "custom",
  "invalid_union",
  "invalid_union_discriminator",
  "invalid_enum_value",
  "unrecognized_keys",
  "invalid_arguments",
  "invalid_return_type",
  "invalid_date",
  "invalid_string",
  "too_small",
  "too_big",
  "invalid_intersection_types",
  "not_multiple_of",
  "not_finite"
]);
var quotelessJson = /* @__PURE__ */ __name((obj) => {
  const json2 = JSON.stringify(obj, null, 2);
  return json2.replace(/"([^"]+)":/g, "$1:");
}, "quotelessJson");
var ZodError = class _ZodError extends Error {
  static {
    __name(this, "ZodError");
  }
  get errors() {
    return this.issues;
  }
  constructor(issues) {
    super();
    this.issues = [];
    this.addIssue = (sub) => {
      this.issues = [...this.issues, sub];
    };
    this.addIssues = (subs = []) => {
      this.issues = [...this.issues, ...subs];
    };
    const actualProto = new.target.prototype;
    if (Object.setPrototypeOf) {
      Object.setPrototypeOf(this, actualProto);
    } else {
      this.__proto__ = actualProto;
    }
    this.name = "ZodError";
    this.issues = issues;
  }
  format(_mapper) {
    const mapper = _mapper || function(issue) {
      return issue.message;
    };
    const fieldErrors = { _errors: [] };
    const processError = /* @__PURE__ */ __name((error) => {
      for (const issue of error.issues) {
        if (issue.code === "invalid_union") {
          issue.unionErrors.map(processError);
        } else if (issue.code === "invalid_return_type") {
          processError(issue.returnTypeError);
        } else if (issue.code === "invalid_arguments") {
          processError(issue.argumentsError);
        } else if (issue.path.length === 0) {
          fieldErrors._errors.push(mapper(issue));
        } else {
          let curr = fieldErrors;
          let i = 0;
          while (i < issue.path.length) {
            const el = issue.path[i];
            const terminal = i === issue.path.length - 1;
            if (!terminal) {
              curr[el] = curr[el] || { _errors: [] };
            } else {
              curr[el] = curr[el] || { _errors: [] };
              curr[el]._errors.push(mapper(issue));
            }
            curr = curr[el];
            i++;
          }
        }
      }
    }, "processError");
    processError(this);
    return fieldErrors;
  }
  static assert(value) {
    if (!(value instanceof _ZodError)) {
      throw new Error(`Not a ZodError: ${value}`);
    }
  }
  toString() {
    return this.message;
  }
  get message() {
    return JSON.stringify(this.issues, util.jsonStringifyReplacer, 2);
  }
  get isEmpty() {
    return this.issues.length === 0;
  }
  flatten(mapper = (issue) => issue.message) {
    const fieldErrors = {};
    const formErrors = [];
    for (const sub of this.issues) {
      if (sub.path.length > 0) {
        const firstEl = sub.path[0];
        fieldErrors[firstEl] = fieldErrors[firstEl] || [];
        fieldErrors[firstEl].push(mapper(sub));
      } else {
        formErrors.push(mapper(sub));
      }
    }
    return { formErrors, fieldErrors };
  }
  get formErrors() {
    return this.flatten();
  }
};
ZodError.create = (issues) => {
  const error = new ZodError(issues);
  return error;
};

// ../../node_modules/zod/v3/locales/en.js
var errorMap = /* @__PURE__ */ __name((issue, _ctx) => {
  let message;
  switch (issue.code) {
    case ZodIssueCode.invalid_type:
      if (issue.received === ZodParsedType.undefined) {
        message = "Required";
      } else {
        message = `Expected ${issue.expected}, received ${issue.received}`;
      }
      break;
    case ZodIssueCode.invalid_literal:
      message = `Invalid literal value, expected ${JSON.stringify(issue.expected, util.jsonStringifyReplacer)}`;
      break;
    case ZodIssueCode.unrecognized_keys:
      message = `Unrecognized key(s) in object: ${util.joinValues(issue.keys, ", ")}`;
      break;
    case ZodIssueCode.invalid_union:
      message = `Invalid input`;
      break;
    case ZodIssueCode.invalid_union_discriminator:
      message = `Invalid discriminator value. Expected ${util.joinValues(issue.options)}`;
      break;
    case ZodIssueCode.invalid_enum_value:
      message = `Invalid enum value. Expected ${util.joinValues(issue.options)}, received '${issue.received}'`;
      break;
    case ZodIssueCode.invalid_arguments:
      message = `Invalid function arguments`;
      break;
    case ZodIssueCode.invalid_return_type:
      message = `Invalid function return type`;
      break;
    case ZodIssueCode.invalid_date:
      message = `Invalid date`;
      break;
    case ZodIssueCode.invalid_string:
      if (typeof issue.validation === "object") {
        if ("includes" in issue.validation) {
          message = `Invalid input: must include "${issue.validation.includes}"`;
          if (typeof issue.validation.position === "number") {
            message = `${message} at one or more positions greater than or equal to ${issue.validation.position}`;
          }
        } else if ("startsWith" in issue.validation) {
          message = `Invalid input: must start with "${issue.validation.startsWith}"`;
        } else if ("endsWith" in issue.validation) {
          message = `Invalid input: must end with "${issue.validation.endsWith}"`;
        } else {
          util.assertNever(issue.validation);
        }
      } else if (issue.validation !== "regex") {
        message = `Invalid ${issue.validation}`;
      } else {
        message = "Invalid";
      }
      break;
    case ZodIssueCode.too_small:
      if (issue.type === "array")
        message = `Array must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `more than`} ${issue.minimum} element(s)`;
      else if (issue.type === "string")
        message = `String must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `over`} ${issue.minimum} character(s)`;
      else if (issue.type === "number")
        message = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
      else if (issue.type === "bigint")
        message = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
      else if (issue.type === "date")
        message = `Date must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${new Date(Number(issue.minimum))}`;
      else
        message = "Invalid input";
      break;
    case ZodIssueCode.too_big:
      if (issue.type === "array")
        message = `Array must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `less than`} ${issue.maximum} element(s)`;
      else if (issue.type === "string")
        message = `String must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `under`} ${issue.maximum} character(s)`;
      else if (issue.type === "number")
        message = `Number must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
      else if (issue.type === "bigint")
        message = `BigInt must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
      else if (issue.type === "date")
        message = `Date must be ${issue.exact ? `exactly` : issue.inclusive ? `smaller than or equal to` : `smaller than`} ${new Date(Number(issue.maximum))}`;
      else
        message = "Invalid input";
      break;
    case ZodIssueCode.custom:
      message = `Invalid input`;
      break;
    case ZodIssueCode.invalid_intersection_types:
      message = `Intersection results could not be merged`;
      break;
    case ZodIssueCode.not_multiple_of:
      message = `Number must be a multiple of ${issue.multipleOf}`;
      break;
    case ZodIssueCode.not_finite:
      message = "Number must be finite";
      break;
    default:
      message = _ctx.defaultError;
      util.assertNever(issue);
  }
  return { message };
}, "errorMap");
var en_default = errorMap;

// ../../node_modules/zod/v3/errors.js
var overrideErrorMap = en_default;
function setErrorMap(map) {
  overrideErrorMap = map;
}
__name(setErrorMap, "setErrorMap");
function getErrorMap() {
  return overrideErrorMap;
}
__name(getErrorMap, "getErrorMap");

// ../../node_modules/zod/v3/helpers/parseUtil.js
var makeIssue = /* @__PURE__ */ __name((params) => {
  const { data, path, errorMaps, issueData } = params;
  const fullPath = [...path, ...issueData.path || []];
  const fullIssue = {
    ...issueData,
    path: fullPath
  };
  if (issueData.message !== void 0) {
    return {
      ...issueData,
      path: fullPath,
      message: issueData.message
    };
  }
  let errorMessage = "";
  const maps = errorMaps.filter((m) => !!m).slice().reverse();
  for (const map of maps) {
    errorMessage = map(fullIssue, { data, defaultError: errorMessage }).message;
  }
  return {
    ...issueData,
    path: fullPath,
    message: errorMessage
  };
}, "makeIssue");
var EMPTY_PATH = [];
function addIssueToContext(ctx, issueData) {
  const overrideMap = getErrorMap();
  const issue = makeIssue({
    issueData,
    data: ctx.data,
    path: ctx.path,
    errorMaps: [
      ctx.common.contextualErrorMap,
      // contextual error map is first priority
      ctx.schemaErrorMap,
      // then schema-bound map if available
      overrideMap,
      // then global override map
      overrideMap === en_default ? void 0 : en_default
      // then global default map
    ].filter((x) => !!x)
  });
  ctx.common.issues.push(issue);
}
__name(addIssueToContext, "addIssueToContext");
var ParseStatus = class _ParseStatus {
  static {
    __name(this, "ParseStatus");
  }
  constructor() {
    this.value = "valid";
  }
  dirty() {
    if (this.value === "valid")
      this.value = "dirty";
  }
  abort() {
    if (this.value !== "aborted")
      this.value = "aborted";
  }
  static mergeArray(status, results) {
    const arrayValue = [];
    for (const s of results) {
      if (s.status === "aborted")
        return INVALID;
      if (s.status === "dirty")
        status.dirty();
      arrayValue.push(s.value);
    }
    return { status: status.value, value: arrayValue };
  }
  static async mergeObjectAsync(status, pairs) {
    const syncPairs = [];
    for (const pair of pairs) {
      const key = await pair.key;
      const value = await pair.value;
      syncPairs.push({
        key,
        value
      });
    }
    return _ParseStatus.mergeObjectSync(status, syncPairs);
  }
  static mergeObjectSync(status, pairs) {
    const finalObject = {};
    for (const pair of pairs) {
      const { key, value } = pair;
      if (key.status === "aborted")
        return INVALID;
      if (value.status === "aborted")
        return INVALID;
      if (key.status === "dirty")
        status.dirty();
      if (value.status === "dirty")
        status.dirty();
      if (key.value !== "__proto__" && (typeof value.value !== "undefined" || pair.alwaysSet)) {
        finalObject[key.value] = value.value;
      }
    }
    return { status: status.value, value: finalObject };
  }
};
var INVALID = Object.freeze({
  status: "aborted"
});
var DIRTY = /* @__PURE__ */ __name((value) => ({ status: "dirty", value }), "DIRTY");
var OK = /* @__PURE__ */ __name((value) => ({ status: "valid", value }), "OK");
var isAborted = /* @__PURE__ */ __name((x) => x.status === "aborted", "isAborted");
var isDirty = /* @__PURE__ */ __name((x) => x.status === "dirty", "isDirty");
var isValid = /* @__PURE__ */ __name((x) => x.status === "valid", "isValid");
var isAsync = /* @__PURE__ */ __name((x) => typeof Promise !== "undefined" && x instanceof Promise, "isAsync");

// ../../node_modules/zod/v3/helpers/errorUtil.js
var errorUtil;
(function(errorUtil2) {
  errorUtil2.errToObj = (message) => typeof message === "string" ? { message } : message || {};
  errorUtil2.toString = (message) => typeof message === "string" ? message : message?.message;
})(errorUtil || (errorUtil = {}));

// ../../node_modules/zod/v3/types.js
var ParseInputLazyPath = class {
  static {
    __name(this, "ParseInputLazyPath");
  }
  constructor(parent, value, path, key) {
    this._cachedPath = [];
    this.parent = parent;
    this.data = value;
    this._path = path;
    this._key = key;
  }
  get path() {
    if (!this._cachedPath.length) {
      if (Array.isArray(this._key)) {
        this._cachedPath.push(...this._path, ...this._key);
      } else {
        this._cachedPath.push(...this._path, this._key);
      }
    }
    return this._cachedPath;
  }
};
var handleResult = /* @__PURE__ */ __name((ctx, result) => {
  if (isValid(result)) {
    return { success: true, data: result.value };
  } else {
    if (!ctx.common.issues.length) {
      throw new Error("Validation failed but no issues detected.");
    }
    return {
      success: false,
      get error() {
        if (this._error)
          return this._error;
        const error = new ZodError(ctx.common.issues);
        this._error = error;
        return this._error;
      }
    };
  }
}, "handleResult");
function processCreateParams(params) {
  if (!params)
    return {};
  const { errorMap: errorMap2, invalid_type_error, required_error, description } = params;
  if (errorMap2 && (invalid_type_error || required_error)) {
    throw new Error(`Can't use "invalid_type_error" or "required_error" in conjunction with custom error map.`);
  }
  if (errorMap2)
    return { errorMap: errorMap2, description };
  const customMap = /* @__PURE__ */ __name((iss, ctx) => {
    const { message } = params;
    if (iss.code === "invalid_enum_value") {
      return { message: message ?? ctx.defaultError };
    }
    if (typeof ctx.data === "undefined") {
      return { message: message ?? required_error ?? ctx.defaultError };
    }
    if (iss.code !== "invalid_type")
      return { message: ctx.defaultError };
    return { message: message ?? invalid_type_error ?? ctx.defaultError };
  }, "customMap");
  return { errorMap: customMap, description };
}
__name(processCreateParams, "processCreateParams");
var ZodType = class {
  static {
    __name(this, "ZodType");
  }
  get description() {
    return this._def.description;
  }
  _getType(input) {
    return getParsedType(input.data);
  }
  _getOrReturnCtx(input, ctx) {
    return ctx || {
      common: input.parent.common,
      data: input.data,
      parsedType: getParsedType(input.data),
      schemaErrorMap: this._def.errorMap,
      path: input.path,
      parent: input.parent
    };
  }
  _processInputParams(input) {
    return {
      status: new ParseStatus(),
      ctx: {
        common: input.parent.common,
        data: input.data,
        parsedType: getParsedType(input.data),
        schemaErrorMap: this._def.errorMap,
        path: input.path,
        parent: input.parent
      }
    };
  }
  _parseSync(input) {
    const result = this._parse(input);
    if (isAsync(result)) {
      throw new Error("Synchronous parse encountered promise.");
    }
    return result;
  }
  _parseAsync(input) {
    const result = this._parse(input);
    return Promise.resolve(result);
  }
  parse(data, params) {
    const result = this.safeParse(data, params);
    if (result.success)
      return result.data;
    throw result.error;
  }
  safeParse(data, params) {
    const ctx = {
      common: {
        issues: [],
        async: params?.async ?? false,
        contextualErrorMap: params?.errorMap
      },
      path: params?.path || [],
      schemaErrorMap: this._def.errorMap,
      parent: null,
      data,
      parsedType: getParsedType(data)
    };
    const result = this._parseSync({ data, path: ctx.path, parent: ctx });
    return handleResult(ctx, result);
  }
  "~validate"(data) {
    const ctx = {
      common: {
        issues: [],
        async: !!this["~standard"].async
      },
      path: [],
      schemaErrorMap: this._def.errorMap,
      parent: null,
      data,
      parsedType: getParsedType(data)
    };
    if (!this["~standard"].async) {
      try {
        const result = this._parseSync({ data, path: [], parent: ctx });
        return isValid(result) ? {
          value: result.value
        } : {
          issues: ctx.common.issues
        };
      } catch (err) {
        if (err?.message?.toLowerCase()?.includes("encountered")) {
          this["~standard"].async = true;
        }
        ctx.common = {
          issues: [],
          async: true
        };
      }
    }
    return this._parseAsync({ data, path: [], parent: ctx }).then((result) => isValid(result) ? {
      value: result.value
    } : {
      issues: ctx.common.issues
    });
  }
  async parseAsync(data, params) {
    const result = await this.safeParseAsync(data, params);
    if (result.success)
      return result.data;
    throw result.error;
  }
  async safeParseAsync(data, params) {
    const ctx = {
      common: {
        issues: [],
        contextualErrorMap: params?.errorMap,
        async: true
      },
      path: params?.path || [],
      schemaErrorMap: this._def.errorMap,
      parent: null,
      data,
      parsedType: getParsedType(data)
    };
    const maybeAsyncResult = this._parse({ data, path: ctx.path, parent: ctx });
    const result = await (isAsync(maybeAsyncResult) ? maybeAsyncResult : Promise.resolve(maybeAsyncResult));
    return handleResult(ctx, result);
  }
  refine(check, message) {
    const getIssueProperties = /* @__PURE__ */ __name((val) => {
      if (typeof message === "string" || typeof message === "undefined") {
        return { message };
      } else if (typeof message === "function") {
        return message(val);
      } else {
        return message;
      }
    }, "getIssueProperties");
    return this._refinement((val, ctx) => {
      const result = check(val);
      const setError = /* @__PURE__ */ __name(() => ctx.addIssue({
        code: ZodIssueCode.custom,
        ...getIssueProperties(val)
      }), "setError");
      if (typeof Promise !== "undefined" && result instanceof Promise) {
        return result.then((data) => {
          if (!data) {
            setError();
            return false;
          } else {
            return true;
          }
        });
      }
      if (!result) {
        setError();
        return false;
      } else {
        return true;
      }
    });
  }
  refinement(check, refinementData) {
    return this._refinement((val, ctx) => {
      if (!check(val)) {
        ctx.addIssue(typeof refinementData === "function" ? refinementData(val, ctx) : refinementData);
        return false;
      } else {
        return true;
      }
    });
  }
  _refinement(refinement) {
    return new ZodEffects({
      schema: this,
      typeName: ZodFirstPartyTypeKind.ZodEffects,
      effect: { type: "refinement", refinement }
    });
  }
  superRefine(refinement) {
    return this._refinement(refinement);
  }
  constructor(def) {
    this.spa = this.safeParseAsync;
    this._def = def;
    this.parse = this.parse.bind(this);
    this.safeParse = this.safeParse.bind(this);
    this.parseAsync = this.parseAsync.bind(this);
    this.safeParseAsync = this.safeParseAsync.bind(this);
    this.spa = this.spa.bind(this);
    this.refine = this.refine.bind(this);
    this.refinement = this.refinement.bind(this);
    this.superRefine = this.superRefine.bind(this);
    this.optional = this.optional.bind(this);
    this.nullable = this.nullable.bind(this);
    this.nullish = this.nullish.bind(this);
    this.array = this.array.bind(this);
    this.promise = this.promise.bind(this);
    this.or = this.or.bind(this);
    this.and = this.and.bind(this);
    this.transform = this.transform.bind(this);
    this.brand = this.brand.bind(this);
    this.default = this.default.bind(this);
    this.catch = this.catch.bind(this);
    this.describe = this.describe.bind(this);
    this.pipe = this.pipe.bind(this);
    this.readonly = this.readonly.bind(this);
    this.isNullable = this.isNullable.bind(this);
    this.isOptional = this.isOptional.bind(this);
    this["~standard"] = {
      version: 1,
      vendor: "zod",
      validate: /* @__PURE__ */ __name((data) => this["~validate"](data), "validate")
    };
  }
  optional() {
    return ZodOptional.create(this, this._def);
  }
  nullable() {
    return ZodNullable.create(this, this._def);
  }
  nullish() {
    return this.nullable().optional();
  }
  array() {
    return ZodArray.create(this);
  }
  promise() {
    return ZodPromise.create(this, this._def);
  }
  or(option) {
    return ZodUnion.create([this, option], this._def);
  }
  and(incoming) {
    return ZodIntersection.create(this, incoming, this._def);
  }
  transform(transform) {
    return new ZodEffects({
      ...processCreateParams(this._def),
      schema: this,
      typeName: ZodFirstPartyTypeKind.ZodEffects,
      effect: { type: "transform", transform }
    });
  }
  default(def) {
    const defaultValueFunc = typeof def === "function" ? def : () => def;
    return new ZodDefault({
      ...processCreateParams(this._def),
      innerType: this,
      defaultValue: defaultValueFunc,
      typeName: ZodFirstPartyTypeKind.ZodDefault
    });
  }
  brand() {
    return new ZodBranded({
      typeName: ZodFirstPartyTypeKind.ZodBranded,
      type: this,
      ...processCreateParams(this._def)
    });
  }
  catch(def) {
    const catchValueFunc = typeof def === "function" ? def : () => def;
    return new ZodCatch({
      ...processCreateParams(this._def),
      innerType: this,
      catchValue: catchValueFunc,
      typeName: ZodFirstPartyTypeKind.ZodCatch
    });
  }
  describe(description) {
    const This = this.constructor;
    return new This({
      ...this._def,
      description
    });
  }
  pipe(target) {
    return ZodPipeline.create(this, target);
  }
  readonly() {
    return ZodReadonly.create(this);
  }
  isOptional() {
    return this.safeParse(void 0).success;
  }
  isNullable() {
    return this.safeParse(null).success;
  }
};
var cuidRegex = /^c[^\s-]{8,}$/i;
var cuid2Regex = /^[0-9a-z]+$/;
var ulidRegex = /^[0-9A-HJKMNP-TV-Z]{26}$/i;
var uuidRegex = /^[0-9a-fA-F]{8}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{12}$/i;
var nanoidRegex = /^[a-z0-9_-]{21}$/i;
var jwtRegex = /^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]*$/;
var durationRegex = /^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/;
var emailRegex = /^(?!\.)(?!.*\.\.)([A-Z0-9_'+\-\.]*)[A-Z0-9_+-]@([A-Z0-9][A-Z0-9\-]*\.)+[A-Z]{2,}$/i;
var _emojiRegex = `^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$`;
var emojiRegex;
var ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/;
var ipv4CidrRegex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/(3[0-2]|[12]?[0-9])$/;
var ipv6Regex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))$/;
var ipv6CidrRegex = /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/;
var base64Regex = /^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/;
var base64urlRegex = /^([0-9a-zA-Z-_]{4})*(([0-9a-zA-Z-_]{2}(==)?)|([0-9a-zA-Z-_]{3}(=)?))?$/;
var dateRegexSource = `((\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-((0[13578]|1[02])-(0[1-9]|[12]\\d|3[01])|(0[469]|11)-(0[1-9]|[12]\\d|30)|(02)-(0[1-9]|1\\d|2[0-8])))`;
var dateRegex = new RegExp(`^${dateRegexSource}$`);
function timeRegexSource(args) {
  let secondsRegexSource = `[0-5]\\d`;
  if (args.precision) {
    secondsRegexSource = `${secondsRegexSource}\\.\\d{${args.precision}}`;
  } else if (args.precision == null) {
    secondsRegexSource = `${secondsRegexSource}(\\.\\d+)?`;
  }
  const secondsQuantifier = args.precision ? "+" : "?";
  return `([01]\\d|2[0-3]):[0-5]\\d(:${secondsRegexSource})${secondsQuantifier}`;
}
__name(timeRegexSource, "timeRegexSource");
function timeRegex(args) {
  return new RegExp(`^${timeRegexSource(args)}$`);
}
__name(timeRegex, "timeRegex");
function datetimeRegex(args) {
  let regex = `${dateRegexSource}T${timeRegexSource(args)}`;
  const opts = [];
  opts.push(args.local ? `Z?` : `Z`);
  if (args.offset)
    opts.push(`([+-]\\d{2}:?\\d{2})`);
  regex = `${regex}(${opts.join("|")})`;
  return new RegExp(`^${regex}$`);
}
__name(datetimeRegex, "datetimeRegex");
function isValidIP(ip, version) {
  if ((version === "v4" || !version) && ipv4Regex.test(ip)) {
    return true;
  }
  if ((version === "v6" || !version) && ipv6Regex.test(ip)) {
    return true;
  }
  return false;
}
__name(isValidIP, "isValidIP");
function isValidJWT(jwt, alg) {
  if (!jwtRegex.test(jwt))
    return false;
  try {
    const [header] = jwt.split(".");
    if (!header)
      return false;
    const base64 = header.replace(/-/g, "+").replace(/_/g, "/").padEnd(header.length + (4 - header.length % 4) % 4, "=");
    const decoded = JSON.parse(atob(base64));
    if (typeof decoded !== "object" || decoded === null)
      return false;
    if ("typ" in decoded && decoded?.typ !== "JWT")
      return false;
    if (!decoded.alg)
      return false;
    if (alg && decoded.alg !== alg)
      return false;
    return true;
  } catch {
    return false;
  }
}
__name(isValidJWT, "isValidJWT");
function isValidCidr(ip, version) {
  if ((version === "v4" || !version) && ipv4CidrRegex.test(ip)) {
    return true;
  }
  if ((version === "v6" || !version) && ipv6CidrRegex.test(ip)) {
    return true;
  }
  return false;
}
__name(isValidCidr, "isValidCidr");
var ZodString = class _ZodString extends ZodType {
  static {
    __name(this, "ZodString");
  }
  _parse(input) {
    if (this._def.coerce) {
      input.data = String(input.data);
    }
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.string) {
      const ctx2 = this._getOrReturnCtx(input);
      addIssueToContext(ctx2, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.string,
        received: ctx2.parsedType
      });
      return INVALID;
    }
    const status = new ParseStatus();
    let ctx = void 0;
    for (const check of this._def.checks) {
      if (check.kind === "min") {
        if (input.data.length < check.value) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            minimum: check.value,
            type: "string",
            inclusive: true,
            exact: false,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "max") {
        if (input.data.length > check.value) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            maximum: check.value,
            type: "string",
            inclusive: true,
            exact: false,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "length") {
        const tooBig = input.data.length > check.value;
        const tooSmall = input.data.length < check.value;
        if (tooBig || tooSmall) {
          ctx = this._getOrReturnCtx(input, ctx);
          if (tooBig) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              maximum: check.value,
              type: "string",
              inclusive: true,
              exact: true,
              message: check.message
            });
          } else if (tooSmall) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              minimum: check.value,
              type: "string",
              inclusive: true,
              exact: true,
              message: check.message
            });
          }
          status.dirty();
        }
      } else if (check.kind === "email") {
        if (!emailRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "email",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "emoji") {
        if (!emojiRegex) {
          emojiRegex = new RegExp(_emojiRegex, "u");
        }
        if (!emojiRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "emoji",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "uuid") {
        if (!uuidRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "uuid",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "nanoid") {
        if (!nanoidRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "nanoid",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "cuid") {
        if (!cuidRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "cuid",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "cuid2") {
        if (!cuid2Regex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "cuid2",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "ulid") {
        if (!ulidRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "ulid",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "url") {
        try {
          new URL(input.data);
        } catch {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "url",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "regex") {
        check.regex.lastIndex = 0;
        const testResult = check.regex.test(input.data);
        if (!testResult) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "regex",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "trim") {
        input.data = input.data.trim();
      } else if (check.kind === "includes") {
        if (!input.data.includes(check.value, check.position)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: { includes: check.value, position: check.position },
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "toLowerCase") {
        input.data = input.data.toLowerCase();
      } else if (check.kind === "toUpperCase") {
        input.data = input.data.toUpperCase();
      } else if (check.kind === "startsWith") {
        if (!input.data.startsWith(check.value)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: { startsWith: check.value },
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "endsWith") {
        if (!input.data.endsWith(check.value)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: { endsWith: check.value },
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "datetime") {
        const regex = datetimeRegex(check);
        if (!regex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: "datetime",
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "date") {
        const regex = dateRegex;
        if (!regex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: "date",
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "time") {
        const regex = timeRegex(check);
        if (!regex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_string,
            validation: "time",
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "duration") {
        if (!durationRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "duration",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "ip") {
        if (!isValidIP(input.data, check.version)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "ip",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "jwt") {
        if (!isValidJWT(input.data, check.alg)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "jwt",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "cidr") {
        if (!isValidCidr(input.data, check.version)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "cidr",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "base64") {
        if (!base64Regex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "base64",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "base64url") {
        if (!base64urlRegex.test(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            validation: "base64url",
            code: ZodIssueCode.invalid_string,
            message: check.message
          });
          status.dirty();
        }
      } else {
        util.assertNever(check);
      }
    }
    return { status: status.value, value: input.data };
  }
  _regex(regex, validation, message) {
    return this.refinement((data) => regex.test(data), {
      validation,
      code: ZodIssueCode.invalid_string,
      ...errorUtil.errToObj(message)
    });
  }
  _addCheck(check) {
    return new _ZodString({
      ...this._def,
      checks: [...this._def.checks, check]
    });
  }
  email(message) {
    return this._addCheck({ kind: "email", ...errorUtil.errToObj(message) });
  }
  url(message) {
    return this._addCheck({ kind: "url", ...errorUtil.errToObj(message) });
  }
  emoji(message) {
    return this._addCheck({ kind: "emoji", ...errorUtil.errToObj(message) });
  }
  uuid(message) {
    return this._addCheck({ kind: "uuid", ...errorUtil.errToObj(message) });
  }
  nanoid(message) {
    return this._addCheck({ kind: "nanoid", ...errorUtil.errToObj(message) });
  }
  cuid(message) {
    return this._addCheck({ kind: "cuid", ...errorUtil.errToObj(message) });
  }
  cuid2(message) {
    return this._addCheck({ kind: "cuid2", ...errorUtil.errToObj(message) });
  }
  ulid(message) {
    return this._addCheck({ kind: "ulid", ...errorUtil.errToObj(message) });
  }
  base64(message) {
    return this._addCheck({ kind: "base64", ...errorUtil.errToObj(message) });
  }
  base64url(message) {
    return this._addCheck({
      kind: "base64url",
      ...errorUtil.errToObj(message)
    });
  }
  jwt(options) {
    return this._addCheck({ kind: "jwt", ...errorUtil.errToObj(options) });
  }
  ip(options) {
    return this._addCheck({ kind: "ip", ...errorUtil.errToObj(options) });
  }
  cidr(options) {
    return this._addCheck({ kind: "cidr", ...errorUtil.errToObj(options) });
  }
  datetime(options) {
    if (typeof options === "string") {
      return this._addCheck({
        kind: "datetime",
        precision: null,
        offset: false,
        local: false,
        message: options
      });
    }
    return this._addCheck({
      kind: "datetime",
      precision: typeof options?.precision === "undefined" ? null : options?.precision,
      offset: options?.offset ?? false,
      local: options?.local ?? false,
      ...errorUtil.errToObj(options?.message)
    });
  }
  date(message) {
    return this._addCheck({ kind: "date", message });
  }
  time(options) {
    if (typeof options === "string") {
      return this._addCheck({
        kind: "time",
        precision: null,
        message: options
      });
    }
    return this._addCheck({
      kind: "time",
      precision: typeof options?.precision === "undefined" ? null : options?.precision,
      ...errorUtil.errToObj(options?.message)
    });
  }
  duration(message) {
    return this._addCheck({ kind: "duration", ...errorUtil.errToObj(message) });
  }
  regex(regex, message) {
    return this._addCheck({
      kind: "regex",
      regex,
      ...errorUtil.errToObj(message)
    });
  }
  includes(value, options) {
    return this._addCheck({
      kind: "includes",
      value,
      position: options?.position,
      ...errorUtil.errToObj(options?.message)
    });
  }
  startsWith(value, message) {
    return this._addCheck({
      kind: "startsWith",
      value,
      ...errorUtil.errToObj(message)
    });
  }
  endsWith(value, message) {
    return this._addCheck({
      kind: "endsWith",
      value,
      ...errorUtil.errToObj(message)
    });
  }
  min(minLength, message) {
    return this._addCheck({
      kind: "min",
      value: minLength,
      ...errorUtil.errToObj(message)
    });
  }
  max(maxLength, message) {
    return this._addCheck({
      kind: "max",
      value: maxLength,
      ...errorUtil.errToObj(message)
    });
  }
  length(len, message) {
    return this._addCheck({
      kind: "length",
      value: len,
      ...errorUtil.errToObj(message)
    });
  }
  /**
   * Equivalent to `.min(1)`
   */
  nonempty(message) {
    return this.min(1, errorUtil.errToObj(message));
  }
  trim() {
    return new _ZodString({
      ...this._def,
      checks: [...this._def.checks, { kind: "trim" }]
    });
  }
  toLowerCase() {
    return new _ZodString({
      ...this._def,
      checks: [...this._def.checks, { kind: "toLowerCase" }]
    });
  }
  toUpperCase() {
    return new _ZodString({
      ...this._def,
      checks: [...this._def.checks, { kind: "toUpperCase" }]
    });
  }
  get isDatetime() {
    return !!this._def.checks.find((ch) => ch.kind === "datetime");
  }
  get isDate() {
    return !!this._def.checks.find((ch) => ch.kind === "date");
  }
  get isTime() {
    return !!this._def.checks.find((ch) => ch.kind === "time");
  }
  get isDuration() {
    return !!this._def.checks.find((ch) => ch.kind === "duration");
  }
  get isEmail() {
    return !!this._def.checks.find((ch) => ch.kind === "email");
  }
  get isURL() {
    return !!this._def.checks.find((ch) => ch.kind === "url");
  }
  get isEmoji() {
    return !!this._def.checks.find((ch) => ch.kind === "emoji");
  }
  get isUUID() {
    return !!this._def.checks.find((ch) => ch.kind === "uuid");
  }
  get isNANOID() {
    return !!this._def.checks.find((ch) => ch.kind === "nanoid");
  }
  get isCUID() {
    return !!this._def.checks.find((ch) => ch.kind === "cuid");
  }
  get isCUID2() {
    return !!this._def.checks.find((ch) => ch.kind === "cuid2");
  }
  get isULID() {
    return !!this._def.checks.find((ch) => ch.kind === "ulid");
  }
  get isIP() {
    return !!this._def.checks.find((ch) => ch.kind === "ip");
  }
  get isCIDR() {
    return !!this._def.checks.find((ch) => ch.kind === "cidr");
  }
  get isBase64() {
    return !!this._def.checks.find((ch) => ch.kind === "base64");
  }
  get isBase64url() {
    return !!this._def.checks.find((ch) => ch.kind === "base64url");
  }
  get minLength() {
    let min = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "min") {
        if (min === null || ch.value > min)
          min = ch.value;
      }
    }
    return min;
  }
  get maxLength() {
    let max = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "max") {
        if (max === null || ch.value < max)
          max = ch.value;
      }
    }
    return max;
  }
};
ZodString.create = (params) => {
  return new ZodString({
    checks: [],
    typeName: ZodFirstPartyTypeKind.ZodString,
    coerce: params?.coerce ?? false,
    ...processCreateParams(params)
  });
};
function floatSafeRemainder(val, step) {
  const valDecCount = (val.toString().split(".")[1] || "").length;
  const stepDecCount = (step.toString().split(".")[1] || "").length;
  const decCount = valDecCount > stepDecCount ? valDecCount : stepDecCount;
  const valInt = Number.parseInt(val.toFixed(decCount).replace(".", ""));
  const stepInt = Number.parseInt(step.toFixed(decCount).replace(".", ""));
  return valInt % stepInt / 10 ** decCount;
}
__name(floatSafeRemainder, "floatSafeRemainder");
var ZodNumber = class _ZodNumber extends ZodType {
  static {
    __name(this, "ZodNumber");
  }
  constructor() {
    super(...arguments);
    this.min = this.gte;
    this.max = this.lte;
    this.step = this.multipleOf;
  }
  _parse(input) {
    if (this._def.coerce) {
      input.data = Number(input.data);
    }
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.number) {
      const ctx2 = this._getOrReturnCtx(input);
      addIssueToContext(ctx2, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.number,
        received: ctx2.parsedType
      });
      return INVALID;
    }
    let ctx = void 0;
    const status = new ParseStatus();
    for (const check of this._def.checks) {
      if (check.kind === "int") {
        if (!util.isInteger(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_type,
            expected: "integer",
            received: "float",
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "min") {
        const tooSmall = check.inclusive ? input.data < check.value : input.data <= check.value;
        if (tooSmall) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            minimum: check.value,
            type: "number",
            inclusive: check.inclusive,
            exact: false,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "max") {
        const tooBig = check.inclusive ? input.data > check.value : input.data >= check.value;
        if (tooBig) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            maximum: check.value,
            type: "number",
            inclusive: check.inclusive,
            exact: false,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "multipleOf") {
        if (floatSafeRemainder(input.data, check.value) !== 0) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.not_multiple_of,
            multipleOf: check.value,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "finite") {
        if (!Number.isFinite(input.data)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.not_finite,
            message: check.message
          });
          status.dirty();
        }
      } else {
        util.assertNever(check);
      }
    }
    return { status: status.value, value: input.data };
  }
  gte(value, message) {
    return this.setLimit("min", value, true, errorUtil.toString(message));
  }
  gt(value, message) {
    return this.setLimit("min", value, false, errorUtil.toString(message));
  }
  lte(value, message) {
    return this.setLimit("max", value, true, errorUtil.toString(message));
  }
  lt(value, message) {
    return this.setLimit("max", value, false, errorUtil.toString(message));
  }
  setLimit(kind, value, inclusive, message) {
    return new _ZodNumber({
      ...this._def,
      checks: [
        ...this._def.checks,
        {
          kind,
          value,
          inclusive,
          message: errorUtil.toString(message)
        }
      ]
    });
  }
  _addCheck(check) {
    return new _ZodNumber({
      ...this._def,
      checks: [...this._def.checks, check]
    });
  }
  int(message) {
    return this._addCheck({
      kind: "int",
      message: errorUtil.toString(message)
    });
  }
  positive(message) {
    return this._addCheck({
      kind: "min",
      value: 0,
      inclusive: false,
      message: errorUtil.toString(message)
    });
  }
  negative(message) {
    return this._addCheck({
      kind: "max",
      value: 0,
      inclusive: false,
      message: errorUtil.toString(message)
    });
  }
  nonpositive(message) {
    return this._addCheck({
      kind: "max",
      value: 0,
      inclusive: true,
      message: errorUtil.toString(message)
    });
  }
  nonnegative(message) {
    return this._addCheck({
      kind: "min",
      value: 0,
      inclusive: true,
      message: errorUtil.toString(message)
    });
  }
  multipleOf(value, message) {
    return this._addCheck({
      kind: "multipleOf",
      value,
      message: errorUtil.toString(message)
    });
  }
  finite(message) {
    return this._addCheck({
      kind: "finite",
      message: errorUtil.toString(message)
    });
  }
  safe(message) {
    return this._addCheck({
      kind: "min",
      inclusive: true,
      value: Number.MIN_SAFE_INTEGER,
      message: errorUtil.toString(message)
    })._addCheck({
      kind: "max",
      inclusive: true,
      value: Number.MAX_SAFE_INTEGER,
      message: errorUtil.toString(message)
    });
  }
  get minValue() {
    let min = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "min") {
        if (min === null || ch.value > min)
          min = ch.value;
      }
    }
    return min;
  }
  get maxValue() {
    let max = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "max") {
        if (max === null || ch.value < max)
          max = ch.value;
      }
    }
    return max;
  }
  get isInt() {
    return !!this._def.checks.find((ch) => ch.kind === "int" || ch.kind === "multipleOf" && util.isInteger(ch.value));
  }
  get isFinite() {
    let max = null;
    let min = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "finite" || ch.kind === "int" || ch.kind === "multipleOf") {
        return true;
      } else if (ch.kind === "min") {
        if (min === null || ch.value > min)
          min = ch.value;
      } else if (ch.kind === "max") {
        if (max === null || ch.value < max)
          max = ch.value;
      }
    }
    return Number.isFinite(min) && Number.isFinite(max);
  }
};
ZodNumber.create = (params) => {
  return new ZodNumber({
    checks: [],
    typeName: ZodFirstPartyTypeKind.ZodNumber,
    coerce: params?.coerce || false,
    ...processCreateParams(params)
  });
};
var ZodBigInt = class _ZodBigInt extends ZodType {
  static {
    __name(this, "ZodBigInt");
  }
  constructor() {
    super(...arguments);
    this.min = this.gte;
    this.max = this.lte;
  }
  _parse(input) {
    if (this._def.coerce) {
      try {
        input.data = BigInt(input.data);
      } catch {
        return this._getInvalidInput(input);
      }
    }
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.bigint) {
      return this._getInvalidInput(input);
    }
    let ctx = void 0;
    const status = new ParseStatus();
    for (const check of this._def.checks) {
      if (check.kind === "min") {
        const tooSmall = check.inclusive ? input.data < check.value : input.data <= check.value;
        if (tooSmall) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            type: "bigint",
            minimum: check.value,
            inclusive: check.inclusive,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "max") {
        const tooBig = check.inclusive ? input.data > check.value : input.data >= check.value;
        if (tooBig) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            type: "bigint",
            maximum: check.value,
            inclusive: check.inclusive,
            message: check.message
          });
          status.dirty();
        }
      } else if (check.kind === "multipleOf") {
        if (input.data % check.value !== BigInt(0)) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.not_multiple_of,
            multipleOf: check.value,
            message: check.message
          });
          status.dirty();
        }
      } else {
        util.assertNever(check);
      }
    }
    return { status: status.value, value: input.data };
  }
  _getInvalidInput(input) {
    const ctx = this._getOrReturnCtx(input);
    addIssueToContext(ctx, {
      code: ZodIssueCode.invalid_type,
      expected: ZodParsedType.bigint,
      received: ctx.parsedType
    });
    return INVALID;
  }
  gte(value, message) {
    return this.setLimit("min", value, true, errorUtil.toString(message));
  }
  gt(value, message) {
    return this.setLimit("min", value, false, errorUtil.toString(message));
  }
  lte(value, message) {
    return this.setLimit("max", value, true, errorUtil.toString(message));
  }
  lt(value, message) {
    return this.setLimit("max", value, false, errorUtil.toString(message));
  }
  setLimit(kind, value, inclusive, message) {
    return new _ZodBigInt({
      ...this._def,
      checks: [
        ...this._def.checks,
        {
          kind,
          value,
          inclusive,
          message: errorUtil.toString(message)
        }
      ]
    });
  }
  _addCheck(check) {
    return new _ZodBigInt({
      ...this._def,
      checks: [...this._def.checks, check]
    });
  }
  positive(message) {
    return this._addCheck({
      kind: "min",
      value: BigInt(0),
      inclusive: false,
      message: errorUtil.toString(message)
    });
  }
  negative(message) {
    return this._addCheck({
      kind: "max",
      value: BigInt(0),
      inclusive: false,
      message: errorUtil.toString(message)
    });
  }
  nonpositive(message) {
    return this._addCheck({
      kind: "max",
      value: BigInt(0),
      inclusive: true,
      message: errorUtil.toString(message)
    });
  }
  nonnegative(message) {
    return this._addCheck({
      kind: "min",
      value: BigInt(0),
      inclusive: true,
      message: errorUtil.toString(message)
    });
  }
  multipleOf(value, message) {
    return this._addCheck({
      kind: "multipleOf",
      value,
      message: errorUtil.toString(message)
    });
  }
  get minValue() {
    let min = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "min") {
        if (min === null || ch.value > min)
          min = ch.value;
      }
    }
    return min;
  }
  get maxValue() {
    let max = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "max") {
        if (max === null || ch.value < max)
          max = ch.value;
      }
    }
    return max;
  }
};
ZodBigInt.create = (params) => {
  return new ZodBigInt({
    checks: [],
    typeName: ZodFirstPartyTypeKind.ZodBigInt,
    coerce: params?.coerce ?? false,
    ...processCreateParams(params)
  });
};
var ZodBoolean = class extends ZodType {
  static {
    __name(this, "ZodBoolean");
  }
  _parse(input) {
    if (this._def.coerce) {
      input.data = Boolean(input.data);
    }
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.boolean) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.boolean,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return OK(input.data);
  }
};
ZodBoolean.create = (params) => {
  return new ZodBoolean({
    typeName: ZodFirstPartyTypeKind.ZodBoolean,
    coerce: params?.coerce || false,
    ...processCreateParams(params)
  });
};
var ZodDate = class _ZodDate extends ZodType {
  static {
    __name(this, "ZodDate");
  }
  _parse(input) {
    if (this._def.coerce) {
      input.data = new Date(input.data);
    }
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.date) {
      const ctx2 = this._getOrReturnCtx(input);
      addIssueToContext(ctx2, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.date,
        received: ctx2.parsedType
      });
      return INVALID;
    }
    if (Number.isNaN(input.data.getTime())) {
      const ctx2 = this._getOrReturnCtx(input);
      addIssueToContext(ctx2, {
        code: ZodIssueCode.invalid_date
      });
      return INVALID;
    }
    const status = new ParseStatus();
    let ctx = void 0;
    for (const check of this._def.checks) {
      if (check.kind === "min") {
        if (input.data.getTime() < check.value) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            message: check.message,
            inclusive: true,
            exact: false,
            minimum: check.value,
            type: "date"
          });
          status.dirty();
        }
      } else if (check.kind === "max") {
        if (input.data.getTime() > check.value) {
          ctx = this._getOrReturnCtx(input, ctx);
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            message: check.message,
            inclusive: true,
            exact: false,
            maximum: check.value,
            type: "date"
          });
          status.dirty();
        }
      } else {
        util.assertNever(check);
      }
    }
    return {
      status: status.value,
      value: new Date(input.data.getTime())
    };
  }
  _addCheck(check) {
    return new _ZodDate({
      ...this._def,
      checks: [...this._def.checks, check]
    });
  }
  min(minDate, message) {
    return this._addCheck({
      kind: "min",
      value: minDate.getTime(),
      message: errorUtil.toString(message)
    });
  }
  max(maxDate, message) {
    return this._addCheck({
      kind: "max",
      value: maxDate.getTime(),
      message: errorUtil.toString(message)
    });
  }
  get minDate() {
    let min = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "min") {
        if (min === null || ch.value > min)
          min = ch.value;
      }
    }
    return min != null ? new Date(min) : null;
  }
  get maxDate() {
    let max = null;
    for (const ch of this._def.checks) {
      if (ch.kind === "max") {
        if (max === null || ch.value < max)
          max = ch.value;
      }
    }
    return max != null ? new Date(max) : null;
  }
};
ZodDate.create = (params) => {
  return new ZodDate({
    checks: [],
    coerce: params?.coerce || false,
    typeName: ZodFirstPartyTypeKind.ZodDate,
    ...processCreateParams(params)
  });
};
var ZodSymbol = class extends ZodType {
  static {
    __name(this, "ZodSymbol");
  }
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.symbol) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.symbol,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return OK(input.data);
  }
};
ZodSymbol.create = (params) => {
  return new ZodSymbol({
    typeName: ZodFirstPartyTypeKind.ZodSymbol,
    ...processCreateParams(params)
  });
};
var ZodUndefined = class extends ZodType {
  static {
    __name(this, "ZodUndefined");
  }
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.undefined) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.undefined,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return OK(input.data);
  }
};
ZodUndefined.create = (params) => {
  return new ZodUndefined({
    typeName: ZodFirstPartyTypeKind.ZodUndefined,
    ...processCreateParams(params)
  });
};
var ZodNull = class extends ZodType {
  static {
    __name(this, "ZodNull");
  }
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.null) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.null,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return OK(input.data);
  }
};
ZodNull.create = (params) => {
  return new ZodNull({
    typeName: ZodFirstPartyTypeKind.ZodNull,
    ...processCreateParams(params)
  });
};
var ZodAny = class extends ZodType {
  static {
    __name(this, "ZodAny");
  }
  constructor() {
    super(...arguments);
    this._any = true;
  }
  _parse(input) {
    return OK(input.data);
  }
};
ZodAny.create = (params) => {
  return new ZodAny({
    typeName: ZodFirstPartyTypeKind.ZodAny,
    ...processCreateParams(params)
  });
};
var ZodUnknown = class extends ZodType {
  static {
    __name(this, "ZodUnknown");
  }
  constructor() {
    super(...arguments);
    this._unknown = true;
  }
  _parse(input) {
    return OK(input.data);
  }
};
ZodUnknown.create = (params) => {
  return new ZodUnknown({
    typeName: ZodFirstPartyTypeKind.ZodUnknown,
    ...processCreateParams(params)
  });
};
var ZodNever = class extends ZodType {
  static {
    __name(this, "ZodNever");
  }
  _parse(input) {
    const ctx = this._getOrReturnCtx(input);
    addIssueToContext(ctx, {
      code: ZodIssueCode.invalid_type,
      expected: ZodParsedType.never,
      received: ctx.parsedType
    });
    return INVALID;
  }
};
ZodNever.create = (params) => {
  return new ZodNever({
    typeName: ZodFirstPartyTypeKind.ZodNever,
    ...processCreateParams(params)
  });
};
var ZodVoid = class extends ZodType {
  static {
    __name(this, "ZodVoid");
  }
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.undefined) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.void,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return OK(input.data);
  }
};
ZodVoid.create = (params) => {
  return new ZodVoid({
    typeName: ZodFirstPartyTypeKind.ZodVoid,
    ...processCreateParams(params)
  });
};
var ZodArray = class _ZodArray extends ZodType {
  static {
    __name(this, "ZodArray");
  }
  _parse(input) {
    const { ctx, status } = this._processInputParams(input);
    const def = this._def;
    if (ctx.parsedType !== ZodParsedType.array) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.array,
        received: ctx.parsedType
      });
      return INVALID;
    }
    if (def.exactLength !== null) {
      const tooBig = ctx.data.length > def.exactLength.value;
      const tooSmall = ctx.data.length < def.exactLength.value;
      if (tooBig || tooSmall) {
        addIssueToContext(ctx, {
          code: tooBig ? ZodIssueCode.too_big : ZodIssueCode.too_small,
          minimum: tooSmall ? def.exactLength.value : void 0,
          maximum: tooBig ? def.exactLength.value : void 0,
          type: "array",
          inclusive: true,
          exact: true,
          message: def.exactLength.message
        });
        status.dirty();
      }
    }
    if (def.minLength !== null) {
      if (ctx.data.length < def.minLength.value) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_small,
          minimum: def.minLength.value,
          type: "array",
          inclusive: true,
          exact: false,
          message: def.minLength.message
        });
        status.dirty();
      }
    }
    if (def.maxLength !== null) {
      if (ctx.data.length > def.maxLength.value) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_big,
          maximum: def.maxLength.value,
          type: "array",
          inclusive: true,
          exact: false,
          message: def.maxLength.message
        });
        status.dirty();
      }
    }
    if (ctx.common.async) {
      return Promise.all([...ctx.data].map((item, i) => {
        return def.type._parseAsync(new ParseInputLazyPath(ctx, item, ctx.path, i));
      })).then((result2) => {
        return ParseStatus.mergeArray(status, result2);
      });
    }
    const result = [...ctx.data].map((item, i) => {
      return def.type._parseSync(new ParseInputLazyPath(ctx, item, ctx.path, i));
    });
    return ParseStatus.mergeArray(status, result);
  }
  get element() {
    return this._def.type;
  }
  min(minLength, message) {
    return new _ZodArray({
      ...this._def,
      minLength: { value: minLength, message: errorUtil.toString(message) }
    });
  }
  max(maxLength, message) {
    return new _ZodArray({
      ...this._def,
      maxLength: { value: maxLength, message: errorUtil.toString(message) }
    });
  }
  length(len, message) {
    return new _ZodArray({
      ...this._def,
      exactLength: { value: len, message: errorUtil.toString(message) }
    });
  }
  nonempty(message) {
    return this.min(1, message);
  }
};
ZodArray.create = (schema, params) => {
  return new ZodArray({
    type: schema,
    minLength: null,
    maxLength: null,
    exactLength: null,
    typeName: ZodFirstPartyTypeKind.ZodArray,
    ...processCreateParams(params)
  });
};
function deepPartialify(schema) {
  if (schema instanceof ZodObject) {
    const newShape = {};
    for (const key in schema.shape) {
      const fieldSchema = schema.shape[key];
      newShape[key] = ZodOptional.create(deepPartialify(fieldSchema));
    }
    return new ZodObject({
      ...schema._def,
      shape: /* @__PURE__ */ __name(() => newShape, "shape")
    });
  } else if (schema instanceof ZodArray) {
    return new ZodArray({
      ...schema._def,
      type: deepPartialify(schema.element)
    });
  } else if (schema instanceof ZodOptional) {
    return ZodOptional.create(deepPartialify(schema.unwrap()));
  } else if (schema instanceof ZodNullable) {
    return ZodNullable.create(deepPartialify(schema.unwrap()));
  } else if (schema instanceof ZodTuple) {
    return ZodTuple.create(schema.items.map((item) => deepPartialify(item)));
  } else {
    return schema;
  }
}
__name(deepPartialify, "deepPartialify");
var ZodObject = class _ZodObject extends ZodType {
  static {
    __name(this, "ZodObject");
  }
  constructor() {
    super(...arguments);
    this._cached = null;
    this.nonstrict = this.passthrough;
    this.augment = this.extend;
  }
  _getCached() {
    if (this._cached !== null)
      return this._cached;
    const shape = this._def.shape();
    const keys = util.objectKeys(shape);
    this._cached = { shape, keys };
    return this._cached;
  }
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.object) {
      const ctx2 = this._getOrReturnCtx(input);
      addIssueToContext(ctx2, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.object,
        received: ctx2.parsedType
      });
      return INVALID;
    }
    const { status, ctx } = this._processInputParams(input);
    const { shape, keys: shapeKeys } = this._getCached();
    const extraKeys = [];
    if (!(this._def.catchall instanceof ZodNever && this._def.unknownKeys === "strip")) {
      for (const key in ctx.data) {
        if (!shapeKeys.includes(key)) {
          extraKeys.push(key);
        }
      }
    }
    const pairs = [];
    for (const key of shapeKeys) {
      const keyValidator = shape[key];
      const value = ctx.data[key];
      pairs.push({
        key: { status: "valid", value: key },
        value: keyValidator._parse(new ParseInputLazyPath(ctx, value, ctx.path, key)),
        alwaysSet: key in ctx.data
      });
    }
    if (this._def.catchall instanceof ZodNever) {
      const unknownKeys = this._def.unknownKeys;
      if (unknownKeys === "passthrough") {
        for (const key of extraKeys) {
          pairs.push({
            key: { status: "valid", value: key },
            value: { status: "valid", value: ctx.data[key] }
          });
        }
      } else if (unknownKeys === "strict") {
        if (extraKeys.length > 0) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.unrecognized_keys,
            keys: extraKeys
          });
          status.dirty();
        }
      } else if (unknownKeys === "strip") {
      } else {
        throw new Error(`Internal ZodObject error: invalid unknownKeys value.`);
      }
    } else {
      const catchall = this._def.catchall;
      for (const key of extraKeys) {
        const value = ctx.data[key];
        pairs.push({
          key: { status: "valid", value: key },
          value: catchall._parse(
            new ParseInputLazyPath(ctx, value, ctx.path, key)
            //, ctx.child(key), value, getParsedType(value)
          ),
          alwaysSet: key in ctx.data
        });
      }
    }
    if (ctx.common.async) {
      return Promise.resolve().then(async () => {
        const syncPairs = [];
        for (const pair of pairs) {
          const key = await pair.key;
          const value = await pair.value;
          syncPairs.push({
            key,
            value,
            alwaysSet: pair.alwaysSet
          });
        }
        return syncPairs;
      }).then((syncPairs) => {
        return ParseStatus.mergeObjectSync(status, syncPairs);
      });
    } else {
      return ParseStatus.mergeObjectSync(status, pairs);
    }
  }
  get shape() {
    return this._def.shape();
  }
  strict(message) {
    errorUtil.errToObj;
    return new _ZodObject({
      ...this._def,
      unknownKeys: "strict",
      ...message !== void 0 ? {
        errorMap: /* @__PURE__ */ __name((issue, ctx) => {
          const defaultError = this._def.errorMap?.(issue, ctx).message ?? ctx.defaultError;
          if (issue.code === "unrecognized_keys")
            return {
              message: errorUtil.errToObj(message).message ?? defaultError
            };
          return {
            message: defaultError
          };
        }, "errorMap")
      } : {}
    });
  }
  strip() {
    return new _ZodObject({
      ...this._def,
      unknownKeys: "strip"
    });
  }
  passthrough() {
    return new _ZodObject({
      ...this._def,
      unknownKeys: "passthrough"
    });
  }
  // const AugmentFactory =
  //   <Def extends ZodObjectDef>(def: Def) =>
  //   <Augmentation extends ZodRawShape>(
  //     augmentation: Augmentation
  //   ): ZodObject<
  //     extendShape<ReturnType<Def["shape"]>, Augmentation>,
  //     Def["unknownKeys"],
  //     Def["catchall"]
  //   > => {
  //     return new ZodObject({
  //       ...def,
  //       shape: () => ({
  //         ...def.shape(),
  //         ...augmentation,
  //       }),
  //     }) as any;
  //   };
  extend(augmentation) {
    return new _ZodObject({
      ...this._def,
      shape: /* @__PURE__ */ __name(() => ({
        ...this._def.shape(),
        ...augmentation
      }), "shape")
    });
  }
  /**
   * Prior to zod@1.0.12 there was a bug in the
   * inferred type of merged objects. Please
   * upgrade if you are experiencing issues.
   */
  merge(merging) {
    const merged = new _ZodObject({
      unknownKeys: merging._def.unknownKeys,
      catchall: merging._def.catchall,
      shape: /* @__PURE__ */ __name(() => ({
        ...this._def.shape(),
        ...merging._def.shape()
      }), "shape"),
      typeName: ZodFirstPartyTypeKind.ZodObject
    });
    return merged;
  }
  // merge<
  //   Incoming extends AnyZodObject,
  //   Augmentation extends Incoming["shape"],
  //   NewOutput extends {
  //     [k in keyof Augmentation | keyof Output]: k extends keyof Augmentation
  //       ? Augmentation[k]["_output"]
  //       : k extends keyof Output
  //       ? Output[k]
  //       : never;
  //   },
  //   NewInput extends {
  //     [k in keyof Augmentation | keyof Input]: k extends keyof Augmentation
  //       ? Augmentation[k]["_input"]
  //       : k extends keyof Input
  //       ? Input[k]
  //       : never;
  //   }
  // >(
  //   merging: Incoming
  // ): ZodObject<
  //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
  //   Incoming["_def"]["unknownKeys"],
  //   Incoming["_def"]["catchall"],
  //   NewOutput,
  //   NewInput
  // > {
  //   const merged: any = new ZodObject({
  //     unknownKeys: merging._def.unknownKeys,
  //     catchall: merging._def.catchall,
  //     shape: () =>
  //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
  //     typeName: ZodFirstPartyTypeKind.ZodObject,
  //   }) as any;
  //   return merged;
  // }
  setKey(key, schema) {
    return this.augment({ [key]: schema });
  }
  // merge<Incoming extends AnyZodObject>(
  //   merging: Incoming
  // ): //ZodObject<T & Incoming["_shape"], UnknownKeys, Catchall> = (merging) => {
  // ZodObject<
  //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
  //   Incoming["_def"]["unknownKeys"],
  //   Incoming["_def"]["catchall"]
  // > {
  //   // const mergedShape = objectUtil.mergeShapes(
  //   //   this._def.shape(),
  //   //   merging._def.shape()
  //   // );
  //   const merged: any = new ZodObject({
  //     unknownKeys: merging._def.unknownKeys,
  //     catchall: merging._def.catchall,
  //     shape: () =>
  //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
  //     typeName: ZodFirstPartyTypeKind.ZodObject,
  //   }) as any;
  //   return merged;
  // }
  catchall(index) {
    return new _ZodObject({
      ...this._def,
      catchall: index
    });
  }
  pick(mask) {
    const shape = {};
    for (const key of util.objectKeys(mask)) {
      if (mask[key] && this.shape[key]) {
        shape[key] = this.shape[key];
      }
    }
    return new _ZodObject({
      ...this._def,
      shape: /* @__PURE__ */ __name(() => shape, "shape")
    });
  }
  omit(mask) {
    const shape = {};
    for (const key of util.objectKeys(this.shape)) {
      if (!mask[key]) {
        shape[key] = this.shape[key];
      }
    }
    return new _ZodObject({
      ...this._def,
      shape: /* @__PURE__ */ __name(() => shape, "shape")
    });
  }
  /**
   * @deprecated
   */
  deepPartial() {
    return deepPartialify(this);
  }
  partial(mask) {
    const newShape = {};
    for (const key of util.objectKeys(this.shape)) {
      const fieldSchema = this.shape[key];
      if (mask && !mask[key]) {
        newShape[key] = fieldSchema;
      } else {
        newShape[key] = fieldSchema.optional();
      }
    }
    return new _ZodObject({
      ...this._def,
      shape: /* @__PURE__ */ __name(() => newShape, "shape")
    });
  }
  required(mask) {
    const newShape = {};
    for (const key of util.objectKeys(this.shape)) {
      if (mask && !mask[key]) {
        newShape[key] = this.shape[key];
      } else {
        const fieldSchema = this.shape[key];
        let newField = fieldSchema;
        while (newField instanceof ZodOptional) {
          newField = newField._def.innerType;
        }
        newShape[key] = newField;
      }
    }
    return new _ZodObject({
      ...this._def,
      shape: /* @__PURE__ */ __name(() => newShape, "shape")
    });
  }
  keyof() {
    return createZodEnum(util.objectKeys(this.shape));
  }
};
ZodObject.create = (shape, params) => {
  return new ZodObject({
    shape: /* @__PURE__ */ __name(() => shape, "shape"),
    unknownKeys: "strip",
    catchall: ZodNever.create(),
    typeName: ZodFirstPartyTypeKind.ZodObject,
    ...processCreateParams(params)
  });
};
ZodObject.strictCreate = (shape, params) => {
  return new ZodObject({
    shape: /* @__PURE__ */ __name(() => shape, "shape"),
    unknownKeys: "strict",
    catchall: ZodNever.create(),
    typeName: ZodFirstPartyTypeKind.ZodObject,
    ...processCreateParams(params)
  });
};
ZodObject.lazycreate = (shape, params) => {
  return new ZodObject({
    shape,
    unknownKeys: "strip",
    catchall: ZodNever.create(),
    typeName: ZodFirstPartyTypeKind.ZodObject,
    ...processCreateParams(params)
  });
};
var ZodUnion = class extends ZodType {
  static {
    __name(this, "ZodUnion");
  }
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    const options = this._def.options;
    function handleResults(results) {
      for (const result of results) {
        if (result.result.status === "valid") {
          return result.result;
        }
      }
      for (const result of results) {
        if (result.result.status === "dirty") {
          ctx.common.issues.push(...result.ctx.common.issues);
          return result.result;
        }
      }
      const unionErrors = results.map((result) => new ZodError(result.ctx.common.issues));
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_union,
        unionErrors
      });
      return INVALID;
    }
    __name(handleResults, "handleResults");
    if (ctx.common.async) {
      return Promise.all(options.map(async (option) => {
        const childCtx = {
          ...ctx,
          common: {
            ...ctx.common,
            issues: []
          },
          parent: null
        };
        return {
          result: await option._parseAsync({
            data: ctx.data,
            path: ctx.path,
            parent: childCtx
          }),
          ctx: childCtx
        };
      })).then(handleResults);
    } else {
      let dirty = void 0;
      const issues = [];
      for (const option of options) {
        const childCtx = {
          ...ctx,
          common: {
            ...ctx.common,
            issues: []
          },
          parent: null
        };
        const result = option._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: childCtx
        });
        if (result.status === "valid") {
          return result;
        } else if (result.status === "dirty" && !dirty) {
          dirty = { result, ctx: childCtx };
        }
        if (childCtx.common.issues.length) {
          issues.push(childCtx.common.issues);
        }
      }
      if (dirty) {
        ctx.common.issues.push(...dirty.ctx.common.issues);
        return dirty.result;
      }
      const unionErrors = issues.map((issues2) => new ZodError(issues2));
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_union,
        unionErrors
      });
      return INVALID;
    }
  }
  get options() {
    return this._def.options;
  }
};
ZodUnion.create = (types, params) => {
  return new ZodUnion({
    options: types,
    typeName: ZodFirstPartyTypeKind.ZodUnion,
    ...processCreateParams(params)
  });
};
var getDiscriminator = /* @__PURE__ */ __name((type) => {
  if (type instanceof ZodLazy) {
    return getDiscriminator(type.schema);
  } else if (type instanceof ZodEffects) {
    return getDiscriminator(type.innerType());
  } else if (type instanceof ZodLiteral) {
    return [type.value];
  } else if (type instanceof ZodEnum) {
    return type.options;
  } else if (type instanceof ZodNativeEnum) {
    return util.objectValues(type.enum);
  } else if (type instanceof ZodDefault) {
    return getDiscriminator(type._def.innerType);
  } else if (type instanceof ZodUndefined) {
    return [void 0];
  } else if (type instanceof ZodNull) {
    return [null];
  } else if (type instanceof ZodOptional) {
    return [void 0, ...getDiscriminator(type.unwrap())];
  } else if (type instanceof ZodNullable) {
    return [null, ...getDiscriminator(type.unwrap())];
  } else if (type instanceof ZodBranded) {
    return getDiscriminator(type.unwrap());
  } else if (type instanceof ZodReadonly) {
    return getDiscriminator(type.unwrap());
  } else if (type instanceof ZodCatch) {
    return getDiscriminator(type._def.innerType);
  } else {
    return [];
  }
}, "getDiscriminator");
var ZodDiscriminatedUnion = class _ZodDiscriminatedUnion extends ZodType {
  static {
    __name(this, "ZodDiscriminatedUnion");
  }
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.object) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.object,
        received: ctx.parsedType
      });
      return INVALID;
    }
    const discriminator = this.discriminator;
    const discriminatorValue = ctx.data[discriminator];
    const option = this.optionsMap.get(discriminatorValue);
    if (!option) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_union_discriminator,
        options: Array.from(this.optionsMap.keys()),
        path: [discriminator]
      });
      return INVALID;
    }
    if (ctx.common.async) {
      return option._parseAsync({
        data: ctx.data,
        path: ctx.path,
        parent: ctx
      });
    } else {
      return option._parseSync({
        data: ctx.data,
        path: ctx.path,
        parent: ctx
      });
    }
  }
  get discriminator() {
    return this._def.discriminator;
  }
  get options() {
    return this._def.options;
  }
  get optionsMap() {
    return this._def.optionsMap;
  }
  /**
   * The constructor of the discriminated union schema. Its behaviour is very similar to that of the normal z.union() constructor.
   * However, it only allows a union of objects, all of which need to share a discriminator property. This property must
   * have a different value for each object in the union.
   * @param discriminator the name of the discriminator property
   * @param types an array of object schemas
   * @param params
   */
  static create(discriminator, options, params) {
    const optionsMap = /* @__PURE__ */ new Map();
    for (const type of options) {
      const discriminatorValues = getDiscriminator(type.shape[discriminator]);
      if (!discriminatorValues.length) {
        throw new Error(`A discriminator value for key \`${discriminator}\` could not be extracted from all schema options`);
      }
      for (const value of discriminatorValues) {
        if (optionsMap.has(value)) {
          throw new Error(`Discriminator property ${String(discriminator)} has duplicate value ${String(value)}`);
        }
        optionsMap.set(value, type);
      }
    }
    return new _ZodDiscriminatedUnion({
      typeName: ZodFirstPartyTypeKind.ZodDiscriminatedUnion,
      discriminator,
      options,
      optionsMap,
      ...processCreateParams(params)
    });
  }
};
function mergeValues(a, b) {
  const aType = getParsedType(a);
  const bType = getParsedType(b);
  if (a === b) {
    return { valid: true, data: a };
  } else if (aType === ZodParsedType.object && bType === ZodParsedType.object) {
    const bKeys = util.objectKeys(b);
    const sharedKeys = util.objectKeys(a).filter((key) => bKeys.indexOf(key) !== -1);
    const newObj = { ...a, ...b };
    for (const key of sharedKeys) {
      const sharedValue = mergeValues(a[key], b[key]);
      if (!sharedValue.valid) {
        return { valid: false };
      }
      newObj[key] = sharedValue.data;
    }
    return { valid: true, data: newObj };
  } else if (aType === ZodParsedType.array && bType === ZodParsedType.array) {
    if (a.length !== b.length) {
      return { valid: false };
    }
    const newArray = [];
    for (let index = 0; index < a.length; index++) {
      const itemA = a[index];
      const itemB = b[index];
      const sharedValue = mergeValues(itemA, itemB);
      if (!sharedValue.valid) {
        return { valid: false };
      }
      newArray.push(sharedValue.data);
    }
    return { valid: true, data: newArray };
  } else if (aType === ZodParsedType.date && bType === ZodParsedType.date && +a === +b) {
    return { valid: true, data: a };
  } else {
    return { valid: false };
  }
}
__name(mergeValues, "mergeValues");
var ZodIntersection = class extends ZodType {
  static {
    __name(this, "ZodIntersection");
  }
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    const handleParsed = /* @__PURE__ */ __name((parsedLeft, parsedRight) => {
      if (isAborted(parsedLeft) || isAborted(parsedRight)) {
        return INVALID;
      }
      const merged = mergeValues(parsedLeft.value, parsedRight.value);
      if (!merged.valid) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_intersection_types
        });
        return INVALID;
      }
      if (isDirty(parsedLeft) || isDirty(parsedRight)) {
        status.dirty();
      }
      return { status: status.value, value: merged.data };
    }, "handleParsed");
    if (ctx.common.async) {
      return Promise.all([
        this._def.left._parseAsync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        }),
        this._def.right._parseAsync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        })
      ]).then(([left, right]) => handleParsed(left, right));
    } else {
      return handleParsed(this._def.left._parseSync({
        data: ctx.data,
        path: ctx.path,
        parent: ctx
      }), this._def.right._parseSync({
        data: ctx.data,
        path: ctx.path,
        parent: ctx
      }));
    }
  }
};
ZodIntersection.create = (left, right, params) => {
  return new ZodIntersection({
    left,
    right,
    typeName: ZodFirstPartyTypeKind.ZodIntersection,
    ...processCreateParams(params)
  });
};
var ZodTuple = class _ZodTuple extends ZodType {
  static {
    __name(this, "ZodTuple");
  }
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.array) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.array,
        received: ctx.parsedType
      });
      return INVALID;
    }
    if (ctx.data.length < this._def.items.length) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.too_small,
        minimum: this._def.items.length,
        inclusive: true,
        exact: false,
        type: "array"
      });
      return INVALID;
    }
    const rest = this._def.rest;
    if (!rest && ctx.data.length > this._def.items.length) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.too_big,
        maximum: this._def.items.length,
        inclusive: true,
        exact: false,
        type: "array"
      });
      status.dirty();
    }
    const items = [...ctx.data].map((item, itemIndex) => {
      const schema = this._def.items[itemIndex] || this._def.rest;
      if (!schema)
        return null;
      return schema._parse(new ParseInputLazyPath(ctx, item, ctx.path, itemIndex));
    }).filter((x) => !!x);
    if (ctx.common.async) {
      return Promise.all(items).then((results) => {
        return ParseStatus.mergeArray(status, results);
      });
    } else {
      return ParseStatus.mergeArray(status, items);
    }
  }
  get items() {
    return this._def.items;
  }
  rest(rest) {
    return new _ZodTuple({
      ...this._def,
      rest
    });
  }
};
ZodTuple.create = (schemas, params) => {
  if (!Array.isArray(schemas)) {
    throw new Error("You must pass an array of schemas to z.tuple([ ... ])");
  }
  return new ZodTuple({
    items: schemas,
    typeName: ZodFirstPartyTypeKind.ZodTuple,
    rest: null,
    ...processCreateParams(params)
  });
};
var ZodRecord = class _ZodRecord extends ZodType {
  static {
    __name(this, "ZodRecord");
  }
  get keySchema() {
    return this._def.keyType;
  }
  get valueSchema() {
    return this._def.valueType;
  }
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.object) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.object,
        received: ctx.parsedType
      });
      return INVALID;
    }
    const pairs = [];
    const keyType = this._def.keyType;
    const valueType = this._def.valueType;
    for (const key in ctx.data) {
      pairs.push({
        key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, key)),
        value: valueType._parse(new ParseInputLazyPath(ctx, ctx.data[key], ctx.path, key)),
        alwaysSet: key in ctx.data
      });
    }
    if (ctx.common.async) {
      return ParseStatus.mergeObjectAsync(status, pairs);
    } else {
      return ParseStatus.mergeObjectSync(status, pairs);
    }
  }
  get element() {
    return this._def.valueType;
  }
  static create(first, second, third) {
    if (second instanceof ZodType) {
      return new _ZodRecord({
        keyType: first,
        valueType: second,
        typeName: ZodFirstPartyTypeKind.ZodRecord,
        ...processCreateParams(third)
      });
    }
    return new _ZodRecord({
      keyType: ZodString.create(),
      valueType: first,
      typeName: ZodFirstPartyTypeKind.ZodRecord,
      ...processCreateParams(second)
    });
  }
};
var ZodMap = class extends ZodType {
  static {
    __name(this, "ZodMap");
  }
  get keySchema() {
    return this._def.keyType;
  }
  get valueSchema() {
    return this._def.valueType;
  }
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.map) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.map,
        received: ctx.parsedType
      });
      return INVALID;
    }
    const keyType = this._def.keyType;
    const valueType = this._def.valueType;
    const pairs = [...ctx.data.entries()].map(([key, value], index) => {
      return {
        key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, [index, "key"])),
        value: valueType._parse(new ParseInputLazyPath(ctx, value, ctx.path, [index, "value"]))
      };
    });
    if (ctx.common.async) {
      const finalMap = /* @__PURE__ */ new Map();
      return Promise.resolve().then(async () => {
        for (const pair of pairs) {
          const key = await pair.key;
          const value = await pair.value;
          if (key.status === "aborted" || value.status === "aborted") {
            return INVALID;
          }
          if (key.status === "dirty" || value.status === "dirty") {
            status.dirty();
          }
          finalMap.set(key.value, value.value);
        }
        return { status: status.value, value: finalMap };
      });
    } else {
      const finalMap = /* @__PURE__ */ new Map();
      for (const pair of pairs) {
        const key = pair.key;
        const value = pair.value;
        if (key.status === "aborted" || value.status === "aborted") {
          return INVALID;
        }
        if (key.status === "dirty" || value.status === "dirty") {
          status.dirty();
        }
        finalMap.set(key.value, value.value);
      }
      return { status: status.value, value: finalMap };
    }
  }
};
ZodMap.create = (keyType, valueType, params) => {
  return new ZodMap({
    valueType,
    keyType,
    typeName: ZodFirstPartyTypeKind.ZodMap,
    ...processCreateParams(params)
  });
};
var ZodSet = class _ZodSet extends ZodType {
  static {
    __name(this, "ZodSet");
  }
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.set) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.set,
        received: ctx.parsedType
      });
      return INVALID;
    }
    const def = this._def;
    if (def.minSize !== null) {
      if (ctx.data.size < def.minSize.value) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_small,
          minimum: def.minSize.value,
          type: "set",
          inclusive: true,
          exact: false,
          message: def.minSize.message
        });
        status.dirty();
      }
    }
    if (def.maxSize !== null) {
      if (ctx.data.size > def.maxSize.value) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_big,
          maximum: def.maxSize.value,
          type: "set",
          inclusive: true,
          exact: false,
          message: def.maxSize.message
        });
        status.dirty();
      }
    }
    const valueType = this._def.valueType;
    function finalizeSet(elements2) {
      const parsedSet = /* @__PURE__ */ new Set();
      for (const element of elements2) {
        if (element.status === "aborted")
          return INVALID;
        if (element.status === "dirty")
          status.dirty();
        parsedSet.add(element.value);
      }
      return { status: status.value, value: parsedSet };
    }
    __name(finalizeSet, "finalizeSet");
    const elements = [...ctx.data.values()].map((item, i) => valueType._parse(new ParseInputLazyPath(ctx, item, ctx.path, i)));
    if (ctx.common.async) {
      return Promise.all(elements).then((elements2) => finalizeSet(elements2));
    } else {
      return finalizeSet(elements);
    }
  }
  min(minSize, message) {
    return new _ZodSet({
      ...this._def,
      minSize: { value: minSize, message: errorUtil.toString(message) }
    });
  }
  max(maxSize, message) {
    return new _ZodSet({
      ...this._def,
      maxSize: { value: maxSize, message: errorUtil.toString(message) }
    });
  }
  size(size, message) {
    return this.min(size, message).max(size, message);
  }
  nonempty(message) {
    return this.min(1, message);
  }
};
ZodSet.create = (valueType, params) => {
  return new ZodSet({
    valueType,
    minSize: null,
    maxSize: null,
    typeName: ZodFirstPartyTypeKind.ZodSet,
    ...processCreateParams(params)
  });
};
var ZodFunction = class _ZodFunction extends ZodType {
  static {
    __name(this, "ZodFunction");
  }
  constructor() {
    super(...arguments);
    this.validate = this.implement;
  }
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.function) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.function,
        received: ctx.parsedType
      });
      return INVALID;
    }
    function makeArgsIssue(args, error) {
      return makeIssue({
        data: args,
        path: ctx.path,
        errorMaps: [ctx.common.contextualErrorMap, ctx.schemaErrorMap, getErrorMap(), en_default].filter((x) => !!x),
        issueData: {
          code: ZodIssueCode.invalid_arguments,
          argumentsError: error
        }
      });
    }
    __name(makeArgsIssue, "makeArgsIssue");
    function makeReturnsIssue(returns, error) {
      return makeIssue({
        data: returns,
        path: ctx.path,
        errorMaps: [ctx.common.contextualErrorMap, ctx.schemaErrorMap, getErrorMap(), en_default].filter((x) => !!x),
        issueData: {
          code: ZodIssueCode.invalid_return_type,
          returnTypeError: error
        }
      });
    }
    __name(makeReturnsIssue, "makeReturnsIssue");
    const params = { errorMap: ctx.common.contextualErrorMap };
    const fn = ctx.data;
    if (this._def.returns instanceof ZodPromise) {
      const me = this;
      return OK(async function(...args) {
        const error = new ZodError([]);
        const parsedArgs = await me._def.args.parseAsync(args, params).catch((e) => {
          error.addIssue(makeArgsIssue(args, e));
          throw error;
        });
        const result = await Reflect.apply(fn, this, parsedArgs);
        const parsedReturns = await me._def.returns._def.type.parseAsync(result, params).catch((e) => {
          error.addIssue(makeReturnsIssue(result, e));
          throw error;
        });
        return parsedReturns;
      });
    } else {
      const me = this;
      return OK(function(...args) {
        const parsedArgs = me._def.args.safeParse(args, params);
        if (!parsedArgs.success) {
          throw new ZodError([makeArgsIssue(args, parsedArgs.error)]);
        }
        const result = Reflect.apply(fn, this, parsedArgs.data);
        const parsedReturns = me._def.returns.safeParse(result, params);
        if (!parsedReturns.success) {
          throw new ZodError([makeReturnsIssue(result, parsedReturns.error)]);
        }
        return parsedReturns.data;
      });
    }
  }
  parameters() {
    return this._def.args;
  }
  returnType() {
    return this._def.returns;
  }
  args(...items) {
    return new _ZodFunction({
      ...this._def,
      args: ZodTuple.create(items).rest(ZodUnknown.create())
    });
  }
  returns(returnType) {
    return new _ZodFunction({
      ...this._def,
      returns: returnType
    });
  }
  implement(func) {
    const validatedFunc = this.parse(func);
    return validatedFunc;
  }
  strictImplement(func) {
    const validatedFunc = this.parse(func);
    return validatedFunc;
  }
  static create(args, returns, params) {
    return new _ZodFunction({
      args: args ? args : ZodTuple.create([]).rest(ZodUnknown.create()),
      returns: returns || ZodUnknown.create(),
      typeName: ZodFirstPartyTypeKind.ZodFunction,
      ...processCreateParams(params)
    });
  }
};
var ZodLazy = class extends ZodType {
  static {
    __name(this, "ZodLazy");
  }
  get schema() {
    return this._def.getter();
  }
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    const lazySchema = this._def.getter();
    return lazySchema._parse({ data: ctx.data, path: ctx.path, parent: ctx });
  }
};
ZodLazy.create = (getter, params) => {
  return new ZodLazy({
    getter,
    typeName: ZodFirstPartyTypeKind.ZodLazy,
    ...processCreateParams(params)
  });
};
var ZodLiteral = class extends ZodType {
  static {
    __name(this, "ZodLiteral");
  }
  _parse(input) {
    if (input.data !== this._def.value) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        received: ctx.data,
        code: ZodIssueCode.invalid_literal,
        expected: this._def.value
      });
      return INVALID;
    }
    return { status: "valid", value: input.data };
  }
  get value() {
    return this._def.value;
  }
};
ZodLiteral.create = (value, params) => {
  return new ZodLiteral({
    value,
    typeName: ZodFirstPartyTypeKind.ZodLiteral,
    ...processCreateParams(params)
  });
};
function createZodEnum(values, params) {
  return new ZodEnum({
    values,
    typeName: ZodFirstPartyTypeKind.ZodEnum,
    ...processCreateParams(params)
  });
}
__name(createZodEnum, "createZodEnum");
var ZodEnum = class _ZodEnum extends ZodType {
  static {
    __name(this, "ZodEnum");
  }
  _parse(input) {
    if (typeof input.data !== "string") {
      const ctx = this._getOrReturnCtx(input);
      const expectedValues = this._def.values;
      addIssueToContext(ctx, {
        expected: util.joinValues(expectedValues),
        received: ctx.parsedType,
        code: ZodIssueCode.invalid_type
      });
      return INVALID;
    }
    if (!this._cache) {
      this._cache = new Set(this._def.values);
    }
    if (!this._cache.has(input.data)) {
      const ctx = this._getOrReturnCtx(input);
      const expectedValues = this._def.values;
      addIssueToContext(ctx, {
        received: ctx.data,
        code: ZodIssueCode.invalid_enum_value,
        options: expectedValues
      });
      return INVALID;
    }
    return OK(input.data);
  }
  get options() {
    return this._def.values;
  }
  get enum() {
    const enumValues = {};
    for (const val of this._def.values) {
      enumValues[val] = val;
    }
    return enumValues;
  }
  get Values() {
    const enumValues = {};
    for (const val of this._def.values) {
      enumValues[val] = val;
    }
    return enumValues;
  }
  get Enum() {
    const enumValues = {};
    for (const val of this._def.values) {
      enumValues[val] = val;
    }
    return enumValues;
  }
  extract(values, newDef = this._def) {
    return _ZodEnum.create(values, {
      ...this._def,
      ...newDef
    });
  }
  exclude(values, newDef = this._def) {
    return _ZodEnum.create(this.options.filter((opt) => !values.includes(opt)), {
      ...this._def,
      ...newDef
    });
  }
};
ZodEnum.create = createZodEnum;
var ZodNativeEnum = class extends ZodType {
  static {
    __name(this, "ZodNativeEnum");
  }
  _parse(input) {
    const nativeEnumValues = util.getValidEnumValues(this._def.values);
    const ctx = this._getOrReturnCtx(input);
    if (ctx.parsedType !== ZodParsedType.string && ctx.parsedType !== ZodParsedType.number) {
      const expectedValues = util.objectValues(nativeEnumValues);
      addIssueToContext(ctx, {
        expected: util.joinValues(expectedValues),
        received: ctx.parsedType,
        code: ZodIssueCode.invalid_type
      });
      return INVALID;
    }
    if (!this._cache) {
      this._cache = new Set(util.getValidEnumValues(this._def.values));
    }
    if (!this._cache.has(input.data)) {
      const expectedValues = util.objectValues(nativeEnumValues);
      addIssueToContext(ctx, {
        received: ctx.data,
        code: ZodIssueCode.invalid_enum_value,
        options: expectedValues
      });
      return INVALID;
    }
    return OK(input.data);
  }
  get enum() {
    return this._def.values;
  }
};
ZodNativeEnum.create = (values, params) => {
  return new ZodNativeEnum({
    values,
    typeName: ZodFirstPartyTypeKind.ZodNativeEnum,
    ...processCreateParams(params)
  });
};
var ZodPromise = class extends ZodType {
  static {
    __name(this, "ZodPromise");
  }
  unwrap() {
    return this._def.type;
  }
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    if (ctx.parsedType !== ZodParsedType.promise && ctx.common.async === false) {
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.promise,
        received: ctx.parsedType
      });
      return INVALID;
    }
    const promisified = ctx.parsedType === ZodParsedType.promise ? ctx.data : Promise.resolve(ctx.data);
    return OK(promisified.then((data) => {
      return this._def.type.parseAsync(data, {
        path: ctx.path,
        errorMap: ctx.common.contextualErrorMap
      });
    }));
  }
};
ZodPromise.create = (schema, params) => {
  return new ZodPromise({
    type: schema,
    typeName: ZodFirstPartyTypeKind.ZodPromise,
    ...processCreateParams(params)
  });
};
var ZodEffects = class extends ZodType {
  static {
    __name(this, "ZodEffects");
  }
  innerType() {
    return this._def.schema;
  }
  sourceType() {
    return this._def.schema._def.typeName === ZodFirstPartyTypeKind.ZodEffects ? this._def.schema.sourceType() : this._def.schema;
  }
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    const effect = this._def.effect || null;
    const checkCtx = {
      addIssue: /* @__PURE__ */ __name((arg) => {
        addIssueToContext(ctx, arg);
        if (arg.fatal) {
          status.abort();
        } else {
          status.dirty();
        }
      }, "addIssue"),
      get path() {
        return ctx.path;
      }
    };
    checkCtx.addIssue = checkCtx.addIssue.bind(checkCtx);
    if (effect.type === "preprocess") {
      const processed = effect.transform(ctx.data, checkCtx);
      if (ctx.common.async) {
        return Promise.resolve(processed).then(async (processed2) => {
          if (status.value === "aborted")
            return INVALID;
          const result = await this._def.schema._parseAsync({
            data: processed2,
            path: ctx.path,
            parent: ctx
          });
          if (result.status === "aborted")
            return INVALID;
          if (result.status === "dirty")
            return DIRTY(result.value);
          if (status.value === "dirty")
            return DIRTY(result.value);
          return result;
        });
      } else {
        if (status.value === "aborted")
          return INVALID;
        const result = this._def.schema._parseSync({
          data: processed,
          path: ctx.path,
          parent: ctx
        });
        if (result.status === "aborted")
          return INVALID;
        if (result.status === "dirty")
          return DIRTY(result.value);
        if (status.value === "dirty")
          return DIRTY(result.value);
        return result;
      }
    }
    if (effect.type === "refinement") {
      const executeRefinement = /* @__PURE__ */ __name((acc) => {
        const result = effect.refinement(acc, checkCtx);
        if (ctx.common.async) {
          return Promise.resolve(result);
        }
        if (result instanceof Promise) {
          throw new Error("Async refinement encountered during synchronous parse operation. Use .parseAsync instead.");
        }
        return acc;
      }, "executeRefinement");
      if (ctx.common.async === false) {
        const inner = this._def.schema._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
        if (inner.status === "aborted")
          return INVALID;
        if (inner.status === "dirty")
          status.dirty();
        executeRefinement(inner.value);
        return { status: status.value, value: inner.value };
      } else {
        return this._def.schema._parseAsync({ data: ctx.data, path: ctx.path, parent: ctx }).then((inner) => {
          if (inner.status === "aborted")
            return INVALID;
          if (inner.status === "dirty")
            status.dirty();
          return executeRefinement(inner.value).then(() => {
            return { status: status.value, value: inner.value };
          });
        });
      }
    }
    if (effect.type === "transform") {
      if (ctx.common.async === false) {
        const base = this._def.schema._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
        if (!isValid(base))
          return INVALID;
        const result = effect.transform(base.value, checkCtx);
        if (result instanceof Promise) {
          throw new Error(`Asynchronous transform encountered during synchronous parse operation. Use .parseAsync instead.`);
        }
        return { status: status.value, value: result };
      } else {
        return this._def.schema._parseAsync({ data: ctx.data, path: ctx.path, parent: ctx }).then((base) => {
          if (!isValid(base))
            return INVALID;
          return Promise.resolve(effect.transform(base.value, checkCtx)).then((result) => ({
            status: status.value,
            value: result
          }));
        });
      }
    }
    util.assertNever(effect);
  }
};
ZodEffects.create = (schema, effect, params) => {
  return new ZodEffects({
    schema,
    typeName: ZodFirstPartyTypeKind.ZodEffects,
    effect,
    ...processCreateParams(params)
  });
};
ZodEffects.createWithPreprocess = (preprocess, schema, params) => {
  return new ZodEffects({
    schema,
    effect: { type: "preprocess", transform: preprocess },
    typeName: ZodFirstPartyTypeKind.ZodEffects,
    ...processCreateParams(params)
  });
};
var ZodOptional = class extends ZodType {
  static {
    __name(this, "ZodOptional");
  }
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType === ZodParsedType.undefined) {
      return OK(void 0);
    }
    return this._def.innerType._parse(input);
  }
  unwrap() {
    return this._def.innerType;
  }
};
ZodOptional.create = (type, params) => {
  return new ZodOptional({
    innerType: type,
    typeName: ZodFirstPartyTypeKind.ZodOptional,
    ...processCreateParams(params)
  });
};
var ZodNullable = class extends ZodType {
  static {
    __name(this, "ZodNullable");
  }
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType === ZodParsedType.null) {
      return OK(null);
    }
    return this._def.innerType._parse(input);
  }
  unwrap() {
    return this._def.innerType;
  }
};
ZodNullable.create = (type, params) => {
  return new ZodNullable({
    innerType: type,
    typeName: ZodFirstPartyTypeKind.ZodNullable,
    ...processCreateParams(params)
  });
};
var ZodDefault = class extends ZodType {
  static {
    __name(this, "ZodDefault");
  }
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    let data = ctx.data;
    if (ctx.parsedType === ZodParsedType.undefined) {
      data = this._def.defaultValue();
    }
    return this._def.innerType._parse({
      data,
      path: ctx.path,
      parent: ctx
    });
  }
  removeDefault() {
    return this._def.innerType;
  }
};
ZodDefault.create = (type, params) => {
  return new ZodDefault({
    innerType: type,
    typeName: ZodFirstPartyTypeKind.ZodDefault,
    defaultValue: typeof params.default === "function" ? params.default : () => params.default,
    ...processCreateParams(params)
  });
};
var ZodCatch = class extends ZodType {
  static {
    __name(this, "ZodCatch");
  }
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    const newCtx = {
      ...ctx,
      common: {
        ...ctx.common,
        issues: []
      }
    };
    const result = this._def.innerType._parse({
      data: newCtx.data,
      path: newCtx.path,
      parent: {
        ...newCtx
      }
    });
    if (isAsync(result)) {
      return result.then((result2) => {
        return {
          status: "valid",
          value: result2.status === "valid" ? result2.value : this._def.catchValue({
            get error() {
              return new ZodError(newCtx.common.issues);
            },
            input: newCtx.data
          })
        };
      });
    } else {
      return {
        status: "valid",
        value: result.status === "valid" ? result.value : this._def.catchValue({
          get error() {
            return new ZodError(newCtx.common.issues);
          },
          input: newCtx.data
        })
      };
    }
  }
  removeCatch() {
    return this._def.innerType;
  }
};
ZodCatch.create = (type, params) => {
  return new ZodCatch({
    innerType: type,
    typeName: ZodFirstPartyTypeKind.ZodCatch,
    catchValue: typeof params.catch === "function" ? params.catch : () => params.catch,
    ...processCreateParams(params)
  });
};
var ZodNaN = class extends ZodType {
  static {
    __name(this, "ZodNaN");
  }
  _parse(input) {
    const parsedType = this._getType(input);
    if (parsedType !== ZodParsedType.nan) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.nan,
        received: ctx.parsedType
      });
      return INVALID;
    }
    return { status: "valid", value: input.data };
  }
};
ZodNaN.create = (params) => {
  return new ZodNaN({
    typeName: ZodFirstPartyTypeKind.ZodNaN,
    ...processCreateParams(params)
  });
};
var BRAND = /* @__PURE__ */ Symbol("zod_brand");
var ZodBranded = class extends ZodType {
  static {
    __name(this, "ZodBranded");
  }
  _parse(input) {
    const { ctx } = this._processInputParams(input);
    const data = ctx.data;
    return this._def.type._parse({
      data,
      path: ctx.path,
      parent: ctx
    });
  }
  unwrap() {
    return this._def.type;
  }
};
var ZodPipeline = class _ZodPipeline extends ZodType {
  static {
    __name(this, "ZodPipeline");
  }
  _parse(input) {
    const { status, ctx } = this._processInputParams(input);
    if (ctx.common.async) {
      const handleAsync = /* @__PURE__ */ __name(async () => {
        const inResult = await this._def.in._parseAsync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
        if (inResult.status === "aborted")
          return INVALID;
        if (inResult.status === "dirty") {
          status.dirty();
          return DIRTY(inResult.value);
        } else {
          return this._def.out._parseAsync({
            data: inResult.value,
            path: ctx.path,
            parent: ctx
          });
        }
      }, "handleAsync");
      return handleAsync();
    } else {
      const inResult = this._def.in._parseSync({
        data: ctx.data,
        path: ctx.path,
        parent: ctx
      });
      if (inResult.status === "aborted")
        return INVALID;
      if (inResult.status === "dirty") {
        status.dirty();
        return {
          status: "dirty",
          value: inResult.value
        };
      } else {
        return this._def.out._parseSync({
          data: inResult.value,
          path: ctx.path,
          parent: ctx
        });
      }
    }
  }
  static create(a, b) {
    return new _ZodPipeline({
      in: a,
      out: b,
      typeName: ZodFirstPartyTypeKind.ZodPipeline
    });
  }
};
var ZodReadonly = class extends ZodType {
  static {
    __name(this, "ZodReadonly");
  }
  _parse(input) {
    const result = this._def.innerType._parse(input);
    const freeze = /* @__PURE__ */ __name((data) => {
      if (isValid(data)) {
        data.value = Object.freeze(data.value);
      }
      return data;
    }, "freeze");
    return isAsync(result) ? result.then((data) => freeze(data)) : freeze(result);
  }
  unwrap() {
    return this._def.innerType;
  }
};
ZodReadonly.create = (type, params) => {
  return new ZodReadonly({
    innerType: type,
    typeName: ZodFirstPartyTypeKind.ZodReadonly,
    ...processCreateParams(params)
  });
};
function cleanParams(params, data) {
  const p = typeof params === "function" ? params(data) : typeof params === "string" ? { message: params } : params;
  const p2 = typeof p === "string" ? { message: p } : p;
  return p2;
}
__name(cleanParams, "cleanParams");
function custom(check, _params = {}, fatal) {
  if (check)
    return ZodAny.create().superRefine((data, ctx) => {
      const r = check(data);
      if (r instanceof Promise) {
        return r.then((r2) => {
          if (!r2) {
            const params = cleanParams(_params, data);
            const _fatal = params.fatal ?? fatal ?? true;
            ctx.addIssue({ code: "custom", ...params, fatal: _fatal });
          }
        });
      }
      if (!r) {
        const params = cleanParams(_params, data);
        const _fatal = params.fatal ?? fatal ?? true;
        ctx.addIssue({ code: "custom", ...params, fatal: _fatal });
      }
      return;
    });
  return ZodAny.create();
}
__name(custom, "custom");
var late = {
  object: ZodObject.lazycreate
};
var ZodFirstPartyTypeKind;
(function(ZodFirstPartyTypeKind2) {
  ZodFirstPartyTypeKind2["ZodString"] = "ZodString";
  ZodFirstPartyTypeKind2["ZodNumber"] = "ZodNumber";
  ZodFirstPartyTypeKind2["ZodNaN"] = "ZodNaN";
  ZodFirstPartyTypeKind2["ZodBigInt"] = "ZodBigInt";
  ZodFirstPartyTypeKind2["ZodBoolean"] = "ZodBoolean";
  ZodFirstPartyTypeKind2["ZodDate"] = "ZodDate";
  ZodFirstPartyTypeKind2["ZodSymbol"] = "ZodSymbol";
  ZodFirstPartyTypeKind2["ZodUndefined"] = "ZodUndefined";
  ZodFirstPartyTypeKind2["ZodNull"] = "ZodNull";
  ZodFirstPartyTypeKind2["ZodAny"] = "ZodAny";
  ZodFirstPartyTypeKind2["ZodUnknown"] = "ZodUnknown";
  ZodFirstPartyTypeKind2["ZodNever"] = "ZodNever";
  ZodFirstPartyTypeKind2["ZodVoid"] = "ZodVoid";
  ZodFirstPartyTypeKind2["ZodArray"] = "ZodArray";
  ZodFirstPartyTypeKind2["ZodObject"] = "ZodObject";
  ZodFirstPartyTypeKind2["ZodUnion"] = "ZodUnion";
  ZodFirstPartyTypeKind2["ZodDiscriminatedUnion"] = "ZodDiscriminatedUnion";
  ZodFirstPartyTypeKind2["ZodIntersection"] = "ZodIntersection";
  ZodFirstPartyTypeKind2["ZodTuple"] = "ZodTuple";
  ZodFirstPartyTypeKind2["ZodRecord"] = "ZodRecord";
  ZodFirstPartyTypeKind2["ZodMap"] = "ZodMap";
  ZodFirstPartyTypeKind2["ZodSet"] = "ZodSet";
  ZodFirstPartyTypeKind2["ZodFunction"] = "ZodFunction";
  ZodFirstPartyTypeKind2["ZodLazy"] = "ZodLazy";
  ZodFirstPartyTypeKind2["ZodLiteral"] = "ZodLiteral";
  ZodFirstPartyTypeKind2["ZodEnum"] = "ZodEnum";
  ZodFirstPartyTypeKind2["ZodEffects"] = "ZodEffects";
  ZodFirstPartyTypeKind2["ZodNativeEnum"] = "ZodNativeEnum";
  ZodFirstPartyTypeKind2["ZodOptional"] = "ZodOptional";
  ZodFirstPartyTypeKind2["ZodNullable"] = "ZodNullable";
  ZodFirstPartyTypeKind2["ZodDefault"] = "ZodDefault";
  ZodFirstPartyTypeKind2["ZodCatch"] = "ZodCatch";
  ZodFirstPartyTypeKind2["ZodPromise"] = "ZodPromise";
  ZodFirstPartyTypeKind2["ZodBranded"] = "ZodBranded";
  ZodFirstPartyTypeKind2["ZodPipeline"] = "ZodPipeline";
  ZodFirstPartyTypeKind2["ZodReadonly"] = "ZodReadonly";
})(ZodFirstPartyTypeKind || (ZodFirstPartyTypeKind = {}));
var instanceOfType = /* @__PURE__ */ __name((cls, params = {
  message: `Input not instance of ${cls.name}`
}) => custom((data) => data instanceof cls, params), "instanceOfType");
var stringType = ZodString.create;
var numberType = ZodNumber.create;
var nanType = ZodNaN.create;
var bigIntType = ZodBigInt.create;
var booleanType = ZodBoolean.create;
var dateType = ZodDate.create;
var symbolType = ZodSymbol.create;
var undefinedType = ZodUndefined.create;
var nullType = ZodNull.create;
var anyType = ZodAny.create;
var unknownType = ZodUnknown.create;
var neverType = ZodNever.create;
var voidType = ZodVoid.create;
var arrayType = ZodArray.create;
var objectType = ZodObject.create;
var strictObjectType = ZodObject.strictCreate;
var unionType = ZodUnion.create;
var discriminatedUnionType = ZodDiscriminatedUnion.create;
var intersectionType = ZodIntersection.create;
var tupleType = ZodTuple.create;
var recordType = ZodRecord.create;
var mapType = ZodMap.create;
var setType = ZodSet.create;
var functionType = ZodFunction.create;
var lazyType = ZodLazy.create;
var literalType = ZodLiteral.create;
var enumType = ZodEnum.create;
var nativeEnumType = ZodNativeEnum.create;
var promiseType = ZodPromise.create;
var effectsType = ZodEffects.create;
var optionalType = ZodOptional.create;
var nullableType = ZodNullable.create;
var preprocessType = ZodEffects.createWithPreprocess;
var pipelineType = ZodPipeline.create;
var ostring = /* @__PURE__ */ __name(() => stringType().optional(), "ostring");
var onumber = /* @__PURE__ */ __name(() => numberType().optional(), "onumber");
var oboolean = /* @__PURE__ */ __name(() => booleanType().optional(), "oboolean");
var coerce = {
  string: /* @__PURE__ */ __name(((arg) => ZodString.create({ ...arg, coerce: true })), "string"),
  number: /* @__PURE__ */ __name(((arg) => ZodNumber.create({ ...arg, coerce: true })), "number"),
  boolean: /* @__PURE__ */ __name(((arg) => ZodBoolean.create({
    ...arg,
    coerce: true
  })), "boolean"),
  bigint: /* @__PURE__ */ __name(((arg) => ZodBigInt.create({ ...arg, coerce: true })), "bigint"),
  date: /* @__PURE__ */ __name(((arg) => ZodDate.create({ ...arg, coerce: true })), "date")
};
var NEVER = INVALID;

// ../../src/shared/listingHistoricalReplay.ts
var HISTORICAL_MOVE_SCALE = 1e6;
var HISTORICAL_MAX_CLIP_HOURS = 2400;
var HISTORICAL_MAX_TOTAL_HOURS = 4800;
var HISTORICAL_SOURCES = ["BTC/USDT", "ETH/USDT", "SOL/USDT"];
function utcHour(text) {
  if (!/^\d{4}-\d{2}-\d{2}T\d{2}:00:00\.000Z$/.test(text)) throw new Error("\u041E\u0436\u0438\u0434\u0430\u0435\u0442\u0441\u044F \u0442\u043E\u0447\u043D\u043E\u0435 \u0432\u0440\u0435\u043C\u044F UTC \u0441 \u043D\u0430\u0447\u0430\u043B\u043E\u043C \u0447\u0430\u0441\u0430");
  const time = Date.parse(text);
  if (!Number.isSafeInteger(time) || new Date(time).toISOString() !== text) throw new Error("\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u0430\u044F \u0434\u0430\u0442\u0430 UTC");
  return time;
}
__name(utcHour, "utcHour");
function validateHistoricalMoveProgram2(program) {
  if (!program || program.version !== 1 || !Array.isArray(program.clips) || program.clips.length < 1 || program.clips.length > 3)
    throw new Error("\u0414\u043E\u0431\u0430\u0432\u044C\u0442\u0435 \u043E\u0442 \u043E\u0434\u043D\u043E\u0433\u043E \u0434\u043E \u0442\u0440\u0451\u0445 \u0438\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u043E\u0442\u0440\u0435\u0437\u043A\u043E\u0432");
  let total = 0;
  for (const clip of program.clips) {
    if (!HISTORICAL_SOURCES.includes(clip.source) || clip.resolution !== "1h" || clip.provenance !== "USER_SUPPLIED_UNVERIFIED") throw new Error("\u041D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u043E\u0435 \u0438\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u043E\u0435 \u0434\u0432\u0438\u0436\u0435\u043D\u0438\u0435 \u0438\u043B\u0438 \u0438\u0441\u0442\u043E\u0447\u043D\u0438\u043A");
    utcHour(clip.sourceStart);
    if (!Array.isArray(clip.bars) || clip.bars.length < 24 || clip.bars.length > HISTORICAL_MAX_CLIP_HOURS)
      throw new Error("\u041E\u0442\u0440\u0435\u0437\u043E\u043A \u0434\u043E\u043B\u0436\u0435\u043D \u0441\u043E\u0434\u0435\u0440\u0436\u0430\u0442\u044C \u043E\u0442 24 \u0434\u043E 2400 \u043F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u044B\u0445 \u0447\u0430\u0441\u043E\u0432");
    total += clip.bars.length;
    for (const bar of clip.bars) {
      if (!Array.isArray(bar) || bar.length !== 3 || bar.some((n) => !Number.isSafeInteger(n)))
        throw new Error("\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u044B\u0435 \u0438\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u043A\u043E\u044D\u0444\u0444\u0438\u0446\u0438\u0435\u043D\u0442\u044B OHLC");
      const [hi, lo, close] = bar;
      if (hi < Math.max(0, close) || lo > Math.min(0, close) || lo <= -HISTORICAL_MOVE_SCALE || hi > 4 * HISTORICAL_MOVE_SCALE || close <= -HISTORICAL_MOVE_SCALE || close > 4 * HISTORICAL_MOVE_SCALE)
        throw new Error("\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0435 \u0433\u0440\u0430\u043D\u0438\u0446\u044B \u0438\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u043E\u0439 \u0441\u0432\u0435\u0447\u0438");
    }
  }
  if (total > HISTORICAL_MAX_TOTAL_HOURS) throw new Error("\u041D\u0435 \u0431\u043E\u043B\u0435\u0435 4800 \u0447\u0430\u0441\u043E\u0432 \u0432 \u0446\u0435\u043F\u043E\u0447\u043A\u0435 \u0438\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u043E\u0442\u0440\u0435\u0437\u043A\u043E\u0432");
}
__name(validateHistoricalMoveProgram2, "validateHistoricalMoveProgram");
function freezeHistoricalMoveProgram(program) {
  validateHistoricalMoveProgram2(program);
  const clips = program.clips.map((clip) => {
    const bars = clip.bars.map(([h, l, c]) => {
      const bar = [h, l, c];
      Object.freeze(bar);
      return bar;
    });
    Object.freeze(bars);
    return Object.freeze({ ...clip, bars });
  });
  Object.freeze(clips);
  return Object.freeze({ version: 1, clips });
}
__name(freezeHistoricalMoveProgram, "freezeHistoricalMoveProgram");
function historicalSerializedBytes(value) {
  return new TextEncoder().encode(JSON.stringify(value)).byteLength;
}
__name(historicalSerializedBytes, "historicalSerializedBytes");

// ../../src/services/listings/simulationContour.ts
var HISTORICAL_DEMO_NO_LEDGER = "HISTORICAL_DEMO_NO_LEDGER";
function isHistoricalDemoConfig(config) {
  const program = config.simulationProgram;
  return program?.kind === "scenario-controls-v2" && program.afterGrowth === "historical";
}
__name(isHistoricalDemoConfig, "isHistoricalDemoConfig");

// ../../src/services/listings/listingConfig.ts
var LISTING_QUOTE = "USDT";
var LISTING_SCHEMA_VERSION = 1;
var RESERVED_LISTING_SYMBOLS = /* @__PURE__ */ new Set([
  "USDT",
  "USDC",
  "USD",
  "EUR",
  "DAI",
  "BUSD",
  "TUSD",
  "FDUSD",
  "VTA",
  "NRX",
  "BTC",
  "ETH",
  "BNB",
  "SOL",
  "XRP",
  "TON",
  "TRX",
  "ADA",
  "DOGE",
  "AVAX",
  "DOT",
  "LINK",
  "MATIC",
  "POL",
  "LTC",
  "BCH",
  "XAU",
  "XAG"
]);
var LISTING_SYMBOL_PATTERN = /^[A-Z][A-Z0-9]{1,9}$/;
var LISTING_ID_PATTERN = /^[a-z0-9][a-z0-9-]{2,62}$/;
var LISTING_SEED_PATTERN = /^[a-z0-9][a-z0-9-]{7,63}$/;
var DECIMAL = /^(0|[1-9]\d{0,11})(\.\d{1,10})?$/;
var QUANTITY = /^(0|[1-9]\d{0,17})(\.\d{1,8})?$/;
var LOGO_MAX_BYTES = 64 * 1024;
var LOGO_DATA_URL = /^data:image\/(png|jpeg|webp|svg\+xml);base64,[A-Za-z0-9+/]+={0,2}$/;
var MIN_LEAD_MS = 6e4;
var MIN_LEAD_FLOOR_MS = 5e3;
var MAX_LEAD_MS = 366 * 24 * 60 * 6e4;
var MAX_INITIAL_PRICE = 1e6;
var trimmed = /* @__PURE__ */ __name((min, max) => external_exports.string().trim().min(min).max(max).refine((v) => !/[\u0000-\u001f\u007f<>]/.test(v), "invalid characters"), "trimmed");
var scenarioDecimal = external_exports.string().trim().regex(/^\d{1,12}(?:[.,]\d{1,10})?$/, "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u0447\u0438\u0441\u043B\u043E, \u043D\u0435 \u0431\u043E\u043B\u0435\u0435 10 \u0437\u043D\u0430\u043A\u043E\u0432 \u043F\u043E\u0441\u043B\u0435 \u0437\u0430\u043F\u044F\u0442\u043E\u0439").transform(normalizeScenarioDecimal);
var frequency = external_exports.enum(["rare", "moderate", "often"]);
var scenarioControlsSchema = external_exports.object({
terminalPeak: external_exports.literal('bounded-v1').optional(),
  kind: external_exports.literal("scenario-controls-v2"),
  scenario: external_exports.enum(["AUTO", ...LISTING_SCENARIOS]),
  first24hGainPercent: scenarioDecimal,
  maxPrice: scenarioDecimal,
  stages: external_exports.array(external_exports.object({
    type: external_exports.enum(["growth", "range", "pullback", "recovery"]),
    durationHours: external_exports.number().int().min(1).max(720),
    targetPrice: scenarioDecimal
  }).strict()).min(1).max(24),
  afterGrowth: external_exports.enum(["range", "historical"]),
  historical: external_exports.object({
    version: external_exports.literal(1),
    clips: external_exports.array(external_exports.object({
      source: external_exports.enum(["BTC/USDT", "ETH/USDT", "SOL/USDT"]),
      sourceStart: external_exports.string().max(30),
      resolution: external_exports.literal("1h"),
      provenance: external_exports.literal("USER_SUPPLIED_UNVERIFIED"),
      bars: external_exports.array(external_exports.tuple([external_exports.number().int(), external_exports.number().int(), external_exports.number().int()])).min(24).max(2400)
    }).strict()).min(1).max(3)
  }).strict().optional(),
  pullbacks: external_exports.object({ frequency, minDepthPercent: scenarioDecimal.refine((v) => Number(v) <= 60, "\u0413\u043B\u0443\u0431\u0438\u043D\u0430 \u043E\u0442\u043A\u0430\u0442\u0430 \u0434\u043E\u043B\u0436\u043D\u0430 \u0431\u044B\u0442\u044C \u043D\u0435 \u0432\u044B\u0448\u0435 60%"), maxDepthPercent: scenarioDecimal.refine((v) => Number(v) <= 60, "\u0413\u043B\u0443\u0431\u0438\u043D\u0430 \u043E\u0442\u043A\u0430\u0442\u0430 \u0434\u043E\u043B\u0436\u043D\u0430 \u0431\u044B\u0442\u044C \u043D\u0435 \u0432\u044B\u0448\u0435 60%"), durationMinutes: external_exports.number().int().min(5).max(360) }).strict(),
  candles: external_exports.object({ intensity: external_exports.enum(["low", "medium", "high"]), diversity: external_exports.number().min(0).max(1), pauseFrequency: frequency }).strict(),
  wicks: external_exports.object({ length: external_exports.enum(["short", "normal", "pronounced"]), longFrequency: frequency }).strict()
}).strict();
var listingConfigSchema = external_exports.object({
  schemaVersion: external_exports.literal(LISTING_SCHEMA_VERSION),
  symbol: external_exports.string().trim().toUpperCase().regex(LISTING_SYMBOL_PATTERN, "ticker: 2\u201310 latin letters/digits, starting with a letter"),
  name: trimmed(2, 40),
  /** A small inline image. `null` falls back to the generic coin mark. */
  logo: external_exports.string().max(Math.ceil(LOGO_MAX_BYTES * 4 / 3) + 64).regex(LOGO_DATA_URL, "logo must be a PNG, JPEG, WebP or SVG data URL").nullable(),
  initialPrice: external_exports.preprocess((value) => typeof value === "string" ? value.trim().replace(",", ".") : value, external_exports.string().regex(DECIMAL, "initial price: a plain decimal with at most 10 decimals").refine((v) => Number(v) > 0 && Number(v) <= MAX_INITIAL_PRICE, `initial price must be > 0 and \u2264 ${MAX_INITIAL_PRICE}`)),
  /** UTC instant of the first simulated tick, ISO-8601 with an explicit `Z`. */
  listingAt: external_exports.string().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(:\d{2}(\.\d{1,3})?)?Z$/, "listing time must be an ISO UTC instant").refine((v) => {
    const instant = Date.parse(v);
    return Number.isFinite(instant) && new Date(instant).toISOString().slice(0, 16) === v.slice(0, 16);
  }, "invalid listing time"),
  /** How the admin saw and entered the time. Display only; `listingAt` is the instant. */
  displayTimeZone: external_exports.string().min(1).max(64).regex(/^[A-Za-z_]+(\/[A-Za-z0-9_+-]+){0,2}$|^UTC$/, "invalid time zone").refine((timeZone) => {
    try {
      new Intl.DateTimeFormat("en", { timeZone }).format(0);
      return true;
    } catch {
      return false;
    }
  }, "invalid time zone"),
  /** Owner inventory to allocate LATER, in a separate audited step. Never credited by create/preview/publish. */
  ownerAllocation: external_exports.string().regex(QUANTITY, "owner allocation: a plain quantity with at most 8 decimals"),
  seedMode: external_exports.enum(["auto", "manual"]),
  seed: external_exports.string().regex(LISTING_SEED_PATTERN, "seed: 8\u201364 lowercase letters, digits or hyphens"),
  /** After listing, ordinary Spot orders may be placed (matched only against real resting orders). */
  tradable: external_exports.boolean(),
  /**
   * Candle character, assigned by the store when the listing is created
   * (`withStableProfile`) and never changed afterwards. Absent on listings
   * created before profiles existed: they keep the original candles.
   */
  simulationProfile: external_exports.enum(SIMULATION_PROFILES).optional(),
  /** Persisted range model assigned on new INSERT; absent means the original shadows. */
  wickModel: external_exports.literal("NATURAL_V1").optional(),
  /** Optional immutable bounded lifecycle; only non-executable demo listings. */
  simulationProgram: external_exports.union([external_exports.object({
    kind: external_exports.literal("capped-growth-range-v1"),
    first24hGainPercent: external_exports.number().finite().positive().max(1e5),
    maxGainPercent: external_exports.number().finite().positive().max(1e5),
    peakAfterHours: external_exports.number().int().min(48).max(720),
    rangeFraction: external_exports.number().min(0.02).max(0.3)
  }).strict().refine((p) => p.maxGainPercent * 0.94 > p.first24hGainPercent, "cap must exceed day-one target"), scenarioControlsSchema]).optional()
}).strict();
var ListingValidationError = class extends Error {
  constructor(code, message) {
    super(message);
    this.code = code;
  }
  static {
    __name(this, "ListingValidationError");
  }
};
var listingPair = /* @__PURE__ */ __name((symbol) => `${symbol.toUpperCase()}/${LISTING_QUOTE}`, "listingPair");
var listingSlug = /* @__PURE__ */ __name((symbol) => `${symbol.toUpperCase()}-${LISTING_QUOTE}`, "listingSlug");
function logoBytes(logo) {
  if (!logo) return 0;
  const payload = logo.slice(logo.indexOf(",") + 1);
  return Math.floor(payload.length * 3 / 4) - (payload.endsWith("==") ? 2 : payload.endsWith("=") ? 1 : 0);
}
__name(logoBytes, "logoBytes");
function parseListingConfig(input) {
  const parsed = listingConfigSchema.safeParse(input);
  if (!parsed.success) {
    const issue = parsed.error.issues[0];
    throw new ListingValidationError("INVALID_CONFIG", `${issue.path.join(".") || "config"}: ${issue.message}`);
  }
  const config = parsed.data;
if(config.simulationProgram?.terminalPeak && (config.tradable || Number(config.ownerAllocation)!==0))throw new ListingValidationError('DEMO_ONLY','Terminal models require non-tradable zero allocation');
  if (config.simulationProgram?.kind === "scenario-controls-v2") {
    if (Date.parse(config.listingAt) % 1e4 !== 0) throw new ListingValidationError("INVALID_SCENARIO", "\u0412\u0440\u0435\u043C\u044F \u0437\u0430\u043F\u0443\u0441\u043A\u0430 \u0434\u043E\u043B\u0436\u043D\u043E \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0442\u044C \u0441 \u0433\u0440\u0430\u043D\u0438\u0446\u0435\u0439 10 \u0441\u0435\u043A\u0443\u043D\u0434");
    if (config.simulationProgram.afterGrowth === "historical" && historicalSerializedBytes(config) > 80 * 1024)
      throw new ListingValidationError("HISTORICAL_DATA_TOO_LARGE", "\u0424\u0430\u0439\u043B \u0434\u0432\u0438\u0436\u0435\u043D\u0438\u044F \u0441\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0439 \u0434\u043B\u044F \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044F \u0432 \u043B\u0438\u0441\u0442\u0438\u043D\u0433\u0435 (80 \u041A\u0411 \u0441 \u043B\u043E\u0433\u043E\u0442\u0438\u043F\u043E\u043C)");
    try {
      validateScenarioControls(config.simulationProgram, config.initialPrice);
    } catch (error) {
      throw new ListingValidationError("INVALID_SCENARIO", error instanceof Error ? error.message : "\u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 \u0434\u0432\u0438\u0436\u0435\u043D\u0438\u044F \u0446\u0435\u043D\u044B");
    }
  }
  if (config.simulationProgram && config.tradable) throw new ListingValidationError("DEMO_ONLY", "Bounded scenarios require a non-tradable demo listing");
  if (isHistoricalDemoConfig(config) && Number(config.ownerAllocation) !== 0)
    throw new ListingValidationError(HISTORICAL_DEMO_NO_LEDGER, "\u0418\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u0441\u0438\u043C\u0443\u043B\u044F\u0446\u0438\u044F \u043D\u0435 \u0432\u044B\u0434\u0430\u0451\u0442 \u0430\u043A\u0442\u0438\u0432: \u0440\u0430\u0441\u043F\u0440\u0435\u0434\u0435\u043B\u0435\u043D\u0438\u0435 \u0432\u043B\u0430\u0434\u0435\u043B\u044C\u0446\u0443 \u0434\u043E\u043B\u0436\u043D\u043E \u0431\u044B\u0442\u044C 0");
  if (RESERVED_LISTING_SYMBOLS.has(config.symbol)) throw new ListingValidationError("RESERVED_TICKER", `Ticker ${config.symbol} is reserved`);
  if (logoBytes(config.logo) > LOGO_MAX_BYTES) throw new ListingValidationError("LOGO_TOO_LARGE", `Logo must be at most ${LOGO_MAX_BYTES / 1024} KB`);
  return config;
}
__name(parseListingConfig, "parseListingConfig");
function withStableSeed(next, previous) {
  if (next.seedMode === "auto" && previous) return { ...next, seed: previous.seed };
  return next;
}
__name(withStableSeed, "withStableSeed");
function withStableProfile(next, previous, creationOrdinal) {
  const { simulationProfile: _requested, wickModel: _requestedWicks, simulationProgram: requestedProgram, ...rest } = next;
  if (previous?.simulationProgram && next.tradable) throw new ListingValidationError("DEMO_ONLY", "A bounded demo cannot enable real trading");
  if (previous?.simulationProgram?.kind === "scenario-controls-v2" && requestedProgram?.kind !== "scenario-controls-v2") throw new ListingValidationError("HISTORY_LOCKED", "\u041D\u0435\u043B\u044C\u0437\u044F \u0443\u0434\u0430\u043B\u0438\u0442\u044C \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u044B\u0435 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 \u0434\u0432\u0438\u0436\u0435\u043D\u0438\u044F \u0446\u0435\u043D\u044B");
  if (previous?.simulationProgram?.kind === "capped-growth-range-v1" && requestedProgram?.kind === "scenario-controls-v2") throw new ListingValidationError("HISTORY_LOCKED", "\u041F\u0440\u0435\u0436\u043D\u0438\u0439 \u0441\u0446\u0435\u043D\u0430\u0440\u0438\u0439 \u043D\u0435\u043B\u044C\u0437\u044F \u0437\u0430\u043C\u0435\u043D\u0438\u0442\u044C \u043D\u043E\u0432\u043E\u0439 \u0432\u0435\u0440\u0441\u0438\u0435\u0439");
  const v2 = requestedProgram?.kind === "scenario-controls-v2" ? {
    ...requestedProgram,
    scenario: requestedProgram.scenario === "AUTO" ? LISTING_SCENARIOS[Array.from(next.seed).reduce((sum, char) => sum * 31 + char.charCodeAt(0) >>> 0, 0) % LISTING_SCENARIOS.length] : requestedProgram.scenario
  } : void 0;
  if (previous) return {
    ...rest,
    ...previous.simulationProfile ? { simulationProfile: previous.simulationProfile } : {},
    ...previous.wickModel ? { wickModel: previous.wickModel } : {},
    ...v2 ? { simulationProgram: v2 } : previous.simulationProgram ? { simulationProgram: previous.simulationProgram } : {}
  };
  const created = { ...rest, ...v2 ? { simulationProgram: v2 } : requestedProgram ? { simulationProgram: requestedProgram } : {} };
  return creationOrdinal === null ? created : { ...created, simulationProfile: profileForOrdinal(creationOrdinal), wickModel: "NATURAL_V1" };
}
__name(withStableProfile, "withStableProfile");
function checkPublishable(next, active, now, minLeadMs = MIN_LEAD_MS, opened = active !== null && Date.parse(active.listingAt) <= now) {
  if (next.simulationProgram?.kind === "scenario-controls-v2" && next.simulationProgram.afterGrowth === "historical")
    throw new ListingValidationError(
      "HISTORICAL_RIGHTS_UNVERIFIED",
      "\u0418\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u043E\u0435 \u0434\u0432\u0438\u0436\u0435\u043D\u0438\u0435 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u043E \u0434\u043B\u044F \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u043E\u0433\u043E \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A\u0430 \u0438 \u043F\u0440\u0438\u0432\u0430\u0442\u043D\u043E\u0433\u043E \u043F\u0440\u0435\u0434\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440\u0430. \u041F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u044F \u0437\u0430\u043F\u0440\u0435\u0449\u0435\u043D\u0430 \u0434\u043E \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0438 \u043F\u0440\u0430\u0432 \u043D\u0430 \u0434\u0430\u043D\u043D\u044B\u0435 \u0438 \u0438\u0437\u043E\u043B\u044F\u0446\u0438\u0438 \u0442\u043E\u0440\u0433\u043E\u0432\u043B\u0438."
    );
  const at = Date.parse(next.listingAt);
  if (!active) {
    if (at < now + minLeadMs) throw new ListingValidationError("LISTING_TIME_PAST", "The listing time must be at least one minute in the future");
    if (at > now + MAX_LEAD_MS) throw new ListingValidationError("LISTING_TIME_TOO_FAR", "The listing time must be within one year");
    return;
  }
  if (next.symbol !== active.symbol) throw new ListingValidationError("TICKER_LOCKED", "The ticker of a published listing cannot change");
  if (next.seed !== active.seed) throw new ListingValidationError("HISTORY_LOCKED", "The seed of a published listing cannot change");
  if (next.initialPrice !== active.initialPrice) throw new ListingValidationError("HISTORY_LOCKED", "The initial price of a published listing cannot change");
  if (next.simulationProfile !== active.simulationProfile) throw new ListingValidationError("HISTORY_LOCKED", "The simulation profile of a published listing cannot change");
  if (next.wickModel !== active.wickModel) throw new ListingValidationError("HISTORY_LOCKED", "The wick model of a published listing cannot change");
  if (JSON.stringify(next.simulationProgram) !== JSON.stringify(active.simulationProgram)) throw new ListingValidationError("HISTORY_LOCKED", "The bounded program of a published listing cannot change");
  if (next.listingAt !== active.listingAt) {
    const activeAt = Date.parse(active.listingAt);
    if (opened) throw new ListingValidationError("HISTORY_LOCKED", "The listing already opened; its time cannot change");
    if (at < now + minLeadMs) throw new ListingValidationError("LISTING_TIME_PAST", "The new listing time must be at least one minute in the future");
    if (at > now + MAX_LEAD_MS) throw new ListingValidationError("LISTING_TIME_TOO_FAR", "The listing time must be within one year");
  }
}
__name(checkPublishable, "checkPublishable");
function listingSimulationConfig(config) {
  return {
    symbol: config.symbol,
    name: config.name,
    quote: LISTING_QUOTE,
    pair: listingPair(config.symbol),
    isTestAsset: true,
    isTradable: config.tradable,
    listingArmed: true,
    listingAt: Date.parse(config.listingAt),
    initialPrice: Number(config.initialPrice),
    seed: config.seed,
    ...config.simulationProgram?.kind === "scenario-controls-v2" ? { scheduledScenario: {
      mode: "scenario-controls-v2",
      version: 2,
      from: Date.parse(config.listingAt),
      initialPrice: config.initialPrice,
      // Own a frozen snapshot for bounded O(1) historical lookups; leave the
      // caller's draft and every legacy non-historical scenario untouched.
      controls: config.simulationProgram.afterGrowth === "historical" && config.simulationProgram.historical ? { ...config.simulationProgram, historical: freezeHistoricalMoveProgram(config.simulationProgram.historical) } : config.simulationProgram
    } } : config.simulationProgram ? { scheduledScenario: {
      mode: "capped-growth-range",
      version: 1,
      from: Date.parse(config.listingAt),
      firstTargetAt: Date.parse(config.listingAt) + 24 * 36e5,
      peakAt: Date.parse(config.listingAt) + config.simulationProgram.peakAfterHours * 36e5,
      firstGainPercent: config.simulationProgram.first24hGainPercent,
      maxGainPercent: config.simulationProgram.maxGainPercent,
      rangeFraction: config.simulationProgram.rangeFraction
    } } : {},
    ...config.simulationProfile ? { simulationProfile: config.simulationProfile } : {},
    ...config.simulationProfile && config.wickModel === "NATURAL_V1" ? { naturalWicks: { futureFrom: Date.parse(config.listingAt) } } : {}
  };
}
__name(listingSimulationConfig, "listingSimulationConfig");
var LISTING_COUNTDOWN_ACTIONS = ["start", "pause", "stop"];
var listingCountdownSchema = external_exports.object({
  state: external_exports.enum(["staged", "running", "paused"]),
  updatedAt: external_exports.number().int().nonnegative(),
  updatedBy: external_exports.string().max(64),
  startedAt: external_exports.number().int().nonnegative().optional()
}).strict();
var publishedListingSchema = external_exports.object({
  id: external_exports.string().regex(LISTING_ID_PATTERN),
  version: external_exports.number().int().positive(),
  publishedAt: external_exports.string(),
  config: listingConfigSchema,
  readLease: external_exports.object({
    protocol: external_exports.literal("aith-prelisting-v1"),
    generation: external_exports.number().int().positive(),
    issuedAt: external_exports.number().int().nonnegative(),
    expiresAt: external_exports.number().int().positive()
  }).strict().optional(),
  countdown: listingCountdownSchema.optional()
}).strict();
var listingCountdownArmed = /* @__PURE__ */ __name((listing) => !listing.countdown || listing.countdown.state === "running", "listingCountdownArmed");
function publishedListingAsset(listing) {
  return { ...listingSimulationConfig(listing.config), listingArmed: listingCountdownArmed(listing) };
}
__name(publishedListingAsset, "publishedListingAsset");
function listingOpened(listing, now) {
  return listingCountdownArmed(listing) && Date.parse(listing.config.listingAt) <= now;
}
__name(listingOpened, "listingOpened");
function nextListingCountdown(listing, action, now) {
  if (listingOpened(listing, now)) throw new ListingValidationError("MARKET_OPEN", "The market already opened; its timer cannot change");
  if (action === "start") {
    if (Date.parse(listing.config.listingAt) <= now) {
      throw new ListingValidationError("LISTING_TIME_PAST", "The listing time has passed; set a new listing time before starting the timer");
    }
    return "running";
  }
  return action === "pause" ? "paused" : "staged";
}
__name(nextListingCountdown, "nextListingCountdown");

// ../../src/shared/aithPublication.ts
var AITH_READ_LEASE_MS = 45e3;
var AITH_LEASE_SAFETY_MS = 1e3;
var AITH_PUBLICATION_PROTOCOL = "aith-prelisting-v1";
function isAith(value) {
  return typeof value === "string" && ["AITH", "AITH/USDT", "AITH-USDT"].includes(value.toUpperCase());
}
__name(isAith, "isAith");
function validAithLease(lease, version, now) {
  return !!lease && lease.protocol === AITH_PUBLICATION_PROTOCOL && lease.generation === version && Number.isSafeInteger(lease.issuedAt) && Number.isSafeInteger(lease.expiresAt) && lease.expiresAt > lease.issuedAt && lease.expiresAt - lease.issuedAt <= AITH_READ_LEASE_MS && now >= lease.issuedAt - AITH_LEASE_SAFETY_MS && now < lease.expiresAt - AITH_LEASE_SAFETY_MS;
}
__name(validAithLease, "validAithLease");

// ../../src/services/listings/listingPublic.ts
var headers2 = {
  "content-type": "application/json; charset=utf-8",
  "cache-control": "no-store",
  "access-control-allow-origin": "*",
  "access-control-allow-methods": "GET, HEAD, OPTIONS"
};
function publicListingAsset(listing, now) {
  const asset = publishedListingAsset(listing);
  return {
...(listing.config.simulationProgram?.terminalPeak === 'bounded-v1' ? {provenance:{mode:'DEMO_MODEL',withdrawable:false,label:'DEMO · SIMULATED · NO REAL TRADING'}} : {}),

    ...publicTestAsset(asset, now),
    managed: true,
    listingId: listing.id,
    version: listing.version,
    ...listing.readLease ? { readLease: listing.readLease } : {},
    logo: listing.config.logo,
    displayTimeZone: listing.config.displayTimeZone,
    // The public timer: anything but `running` shows the date without a countdown (the market stays frozen).
    // A staged listing never reaches this edge; if one ever did, it would read as paused, never as counting.
    countdown: !listing.countdown || listing.countdown.state === "running" ? "running" : "paused"
  };
}
__name(publicListingAsset, "publicListingAsset");
var PUBLIC_CATALOGUE_PATH = "/market/listings";
function listingForPath(pathname, listings) {
  const match = /^\/(?:market\/(?:test-assets|external\/(?:candles|orderbook|trades|tickers)|display\/spot-(?:book|trades|candles)|ticker)|orderbook)\/([A-Z0-9]+-USDT)(?:\/candles)?$/i.exec(pathname);
  if (!match) return null;
  const slug = match[1].toUpperCase();
  return listings.find((listing) => listingSlug(listing.config.symbol) === slug) ?? null;
}
__name(listingForPath, "listingForPath");
function managedListingResponse(request, listings, now, revision) {
  listings = listings.filter((item) => !isAith(item.config.symbol) || validAithLease(item.readLease, item.version, now));
  const url = new URL(request.url);
  const path = url.pathname;
  const isCatalogue = path === PUBLIC_CATALOGUE_PATH;
  const listing = isCatalogue ? null : listingForPath(path, listings);
  if (!isCatalogue && !listing) return null;
  const respond = /* @__PURE__ */ __name((body, status = 200) => new Response(
    request.method === "HEAD" ? null : JSON.stringify(body),
    { status, headers: headers2 }
  ), "respond");
  if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: headers2 });
  if (!["GET", "HEAD"].includes(request.method)) return respond({ error: "method_not_allowed" }, 405);
  if (isCatalogue) {
    return respond({ serverTime: now, revision, assets: listings.map((item) => publicListingAsset(item, now)) });
  }
  const current = listing;
  if (isAith(current.config.symbol) && url.searchParams.has("listingVersion") && url.searchParams.get("listingVersion") !== String(current.version)) {
    return respond({ error: "listing_version_changed", version: current.version }, 409);
  }
  const asset = publishedListingAsset(current);
  const simulation = simulationFor(asset);
  const marketNow = effectiveTestMarketNow(asset, now);
  const slug = listingSlug(current.config.symbol);
  const upper = path.toUpperCase();
  if (upper === `/MARKET/TEST-ASSETS/${slug}`) return respond(publicListingAsset(current, now));
  if (upper.endsWith("/CANDLES") || upper.startsWith("/MARKET/EXTERNAL/CANDLES/") || upper.startsWith("/MARKET/DISPLAY/SPOT-CANDLES/")) {
    const interval = url.searchParams.get("interval") ?? "5m";
    try {
      return respond({
        source: "simulation",
        pair: listingPair(current.config.symbol),
        interval,
        serverTime: now,
        candles: testMarketCandles(asset, interval, now, Number(url.searchParams.get("limit")) || 300)
      });
    } catch (error) {
      if (error instanceof UnsupportedTestIntervalError) return respond({ error: "unsupported_interval" }, 400);
      throw error;
    }
  }
  if (upper.startsWith("/MARKET/DISPLAY/SPOT-BOOK/") || upper.startsWith("/MARKET/EXTERNAL/ORDERBOOK/") || upper.startsWith("/ORDERBOOK/")) {
    return respond(testMarketDepth(simulation, marketNow));
  }
  if (upper.startsWith("/MARKET/DISPLAY/SPOT-TRADES/") || upper.startsWith("/MARKET/EXTERNAL/TRADES/")) {
    return respond({
      source: "simulation",
      pair: asset.pair,
      trades: simulation.recentTrades(marketNow).map((trade) => ({ ...trade, time: trade.timestamp })),
      serverTime: now
    });
  }
  const { state } = publicTestAsset(asset, now);
  if (state.lastPrice === null) return respond({ error: "not_listed", listingAt: asset.listingAt }, 404);
  const book = testMarketDepth(simulation, marketNow);
  return respond({ source: "simulation", ticker: {
    pair: asset.pair,
    lastPrice: String(state.lastPrice),
    bidPrice: book.bids[0].price,
    askPrice: book.asks[0].price,
    high24h: String(state.high24h),
    low24h: String(state.low24h),
    volume24h: String(state.volume24h),
    quoteVolume24h: String(state.quoteVolume24h),
    changePercent24h: String(state.change24hPercent)
  }, serverTime: now });
}
__name(managedListingResponse, "managedListingResponse");

// ../../src/services/listings/aithReplacement.ts
function aithReplacementConfig(active, input, now) {
  const next = parseListingConfig(input);
  const reject = /* @__PURE__ */ __name((code, message) => {
    throw new ListingValidationError(code, message);
  }, "reject");
  if (!isAith(active.symbol) || next.symbol !== active.symbol) reject("REPLACEMENT_NOT_SUPPORTED", "Replacement is restricted to AITH");
  if (Date.parse(active.listingAt) <= now + 6e4) reject("HISTORY_LOCKED", "The listing has started or its replacement window has closed");
  if (active.tradable || next.tradable || Number(active.ownerAllocation) !== 0 || Number(next.ownerAllocation) !== 0) {
    reject("HISTORY_LOCKED", "Only a non-tradable, unallocated publication can be replaced");
  }
  if (active.simulationProgram?.kind !== "capped-growth-range-v1" || next.simulationProgram?.kind !== "capped-growth-range-v1") {
    reject("HISTORY_LOCKED", "The existing bounded program must be preserved");
  }
  if (Number(next.initialPrice) !== 2 || next.simulationProfile !== "COMPRESSION_BREAKOUT") {
    reject("INVALID_REPLACEMENT", "Expected AITH initial price 2.00 and COMPRESSION_BREAKOUT");
  }
  const preserved = { ...next, initialPrice: active.initialPrice, simulationProfile: active.simulationProfile };
  if (Object.keys(active).length !== Object.keys(preserved).length || Object.keys(active).some((key) => JSON.stringify(active[key]) !== JSON.stringify(preserved[key]))) {
    reject("HISTORY_LOCKED", "Replacement must preserve every other published field");
  }
  return { ...next, initialPrice: "2.00" };
}
__name(aithReplacementConfig, "aithReplacementConfig");

// src/listingsStore.ts
var MAX_BODY_BYTES = 160 * 1024;
var OBJECT_NAME = "voltex-managed-listings-v1";
var ACTOR = /^[A-Za-z0-9_-]{1,64}$/;
var PUBLISH_KEY = /^[A-Za-z0-9-]{16,64}$/;
function envMs(value, fallback, floor) {
  const parsed = Number(value);
  return value !== void 0 && Number.isFinite(parsed) ? Math.max(floor, Math.floor(parsed)) : fallback;
}
__name(envMs, "envMs");
var reply = /* @__PURE__ */ __name((body, status = 200) => new Response(JSON.stringify(body), {
  status,
  headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store", "x-content-type-options": "nosniff" }
}), "reply");
async function authorizeListingsAdmin(request, env) {
  const secret = env.LISTINGS_STORE_TOKEN;
  if (typeof secret !== "string" || secret.length < 32) return reply({ error: "store_not_configured" }, 503);
  if (request.headers.has("Origin")) return reply({ error: "forbidden" }, 403);
  const auth = request.headers.get("Authorization") || "";
  if (auth.length > 4096) return reply({ error: "unauthorized" }, 401);
  const digest = /* @__PURE__ */ __name((value) => crypto.subtle.digest("SHA-256", new TextEncoder().encode(value)), "digest");
  const [a, b] = await Promise.all([digest(auth), digest(`Bearer ${secret}`)]);
  const left = new Uint8Array(a), right = new Uint8Array(b);
  let diff = 0;
  for (let i = 0; i < left.length; i++) diff |= left[i] ^ right[i];
  return diff === 0 ? null : reply({ error: "unauthorized" }, 401);
}
__name(authorizeListingsAdmin, "authorizeListingsAdmin");
async function readJson(request) {
  if (!request.headers.get("Content-Type")?.toLowerCase().startsWith("application/json")) return { error: reply({ error: "expected_json" }, 415) };
  const reader = request.body?.getReader();
  if (!reader) return { error: reply({ error: "invalid_body" }, 400) };
  let bytes = 0, text = "";
  const decoder = new TextDecoder("utf-8", { fatal: true });
  try {
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      bytes += value.byteLength;
      if (bytes > MAX_BODY_BYTES) {
        await reader.cancel();
        return { error: reply({ error: "body_too_large" }, 413) };
      }
      text += decoder.decode(value, { stream: true });
    }
    text += decoder.decode();
    return { value: JSON.parse(text) };
  } catch {
    return { error: reply({ error: "invalid_body" }, 400) };
  }
}
__name(readJson, "readJson");
var validationReply = /* @__PURE__ */ __name((error) => error instanceof ListingValidationError ? reply({ error: error.code, message: error.message }, 422) : reply({ error: "store_unavailable" }, 503), "validationReply");
var ManagedListingsDO = class {
  constructor(state, env) {
    this.state = state;
    this.env = env;
    this.sql = state.storage.sql;
    this.sql.exec(`CREATE TABLE IF NOT EXISTS listing (
      id TEXT PRIMARY KEY, symbol TEXT NOT NULL UNIQUE,
      draft TEXT NOT NULL, draft_revision INTEGER NOT NULL, draft_updated_at INTEGER NOT NULL, draft_updated_by TEXT NOT NULL,
      active_version INTEGER, created_at INTEGER NOT NULL)`);
    this.sql.exec(`CREATE TABLE IF NOT EXISTS listing_version (
      listing_id TEXT NOT NULL, version INTEGER NOT NULL, config TEXT NOT NULL,
      publish_key TEXT NOT NULL, published_at INTEGER NOT NULL, published_by TEXT NOT NULL,
      PRIMARY KEY (listing_id, version), UNIQUE (listing_id, publish_key))`);
    this.sql.exec("CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT NOT NULL)");
  }
  static {
    __name(this, "ManagedListingsDO");
  }
  catalogueRevision() {
    return String(this.sql.exec("SELECT v FROM meta WHERE k = 'catalogue_revision'").toArray()[0]?.v ?? "0");
  }
  /** How many listings have been created with a simulation profile: the next one's ordinal. */
  profileOrdinal() {
    return Number(this.sql.exec("SELECT v FROM meta WHERE k = 'simulation_profile_ordinal'").toArray()[0]?.v ?? "0");
  }
  version(id, version) {
    return this.sql.exec("SELECT version, config, published_at, published_by FROM listing_version WHERE listing_id = ? AND version = ?", id, version).toArray()[0];
  }
  replacement() {
    const row = this.sql.exec("SELECT v FROM meta WHERE k = 'aith_replacement_pending'").toArray()[0];
    return row ? JSON.parse(String(row.v)) : null;
  }
  setMeta(key, value) {
    this.sql.exec("INSERT INTO meta (k, v) VALUES (?, ?) ON CONFLICT(k) DO UPDATE SET v = excluded.v", key, value);
  }
  bumpCatalogueRevision() {
    const revision = String(BigInt(this.catalogueRevision()) + 1n);
    this.setMeta("catalogue_revision", revision);
    return revision;
  }
  /** The pre-listing timer of a published listing (listingConfig.ListingCountdown); absent before the timer existed. */
  countdownOf(id) {
    const row = this.sql.exec("SELECT v FROM meta WHERE k = ?", `countdown:${id}`).toArray()[0];
    return row ? JSON.parse(String(row.v)) : null;
  }
  /**
   * Start, pause or stop the public timer of a published listing. Operational
   * state only: no new version, the listing time never moves. Idempotent: the
   * same action twice answers the same state and bumps nothing.
   */
  countdown(id, input, actor, now) {
    const action = input?.action;
    if (typeof action !== "string" || !LISTING_COUNTDOWN_ACTIONS.includes(action)) return reply({ error: "invalid_countdown_request" }, 400);
    if (this.replacement()?.id === id) return reply({ error: "replacement_in_progress" }, 409);
    return this.state.storage.transactionSync(() => {
      const row = this.sql.exec("SELECT * FROM listing WHERE id = ?", id).toArray()[0];
      if (!row) return reply({ error: "not_found" }, 404);
      if (row.active_version === null) return reply({ error: "NOT_PUBLISHED", message: "Publish the listing before starting its timer" }, 422);
      const config = JSON.parse(String(this.version(id, Number(row.active_version)).config));
      const current = this.countdownOf(id);
      let state;
      try {
        state = nextListingCountdown({ config, countdown: current ?? void 0 }, action, now);
      } catch (error) {
        return validationReply(error);
      }
      if (current?.state === state) return reply({ id, countdown: current, changed: false });
      const next = {
        state,
        updatedAt: now,
        updatedBy: actor,
        ...state === "running" ? { startedAt: now } : current?.startedAt !== void 0 ? { startedAt: current.startedAt } : {}
      };
      this.setMeta(`countdown:${id}`, JSON.stringify(next));
      this.bumpCatalogueRevision();
      return reply({ id, countdown: next, changed: true });
    });
  }
  deleteListing(id, input) {
    const symbol = input?.symbol, revision = input?.draftRevision, activeVersion = input?.activeVersion;
    if (typeof symbol !== "string" || !/^[A-Z0-9]{2,10}$/.test(symbol) || !Number.isSafeInteger(revision) || Number(revision) < 1 || activeVersion !== null && (!Number.isSafeInteger(activeVersion) || Number(activeVersion) < 1) || input?.confirmation !== `\u0423\u0414\u0410\u041B\u0418\u0422\u042C ${symbol}`)
      return reply({ error: "DELETE_CONFIRMATION_REQUIRED" }, 400);
    if (this.replacement()?.id === id) return reply({ error: "replacement_in_progress" }, 409);
    return this.state.storage.transactionSync(() => {
      const row = this.sql.exec("SELECT id, symbol, draft_revision, draft, active_version FROM listing WHERE id = ?", id).toArray()[0];
      if (!row) return reply({ error: "not_found" }, 404);
      if (row.symbol !== symbol || Number(row.draft_revision) !== revision || (row.active_version === null ? null : Number(row.active_version)) !== activeVersion)
        return reply({ error: "LISTING_CHANGED", message: "Reload the listing before deleting it" }, 409);
      const draft = JSON.parse(String(row.draft));
      const version = activeVersion === null ? null : this.version(id, Number(activeVersion));
      if (activeVersion !== null && !version) return reply({ error: "LISTING_CHANGED" }, 409);
      const active = version ? JSON.parse(String(version.config)) : null;
      if (draft.tradable || active?.tradable)
        return reply({ error: "LISTING_TRADABLE", message: "Disable actual trading before deletion" }, 422);
      this.sql.exec("DELETE FROM listing_version WHERE listing_id = ?", id);
      this.sql.exec("DELETE FROM meta WHERE k = ?", `countdown:${id}`);
      this.sql.exec("DELETE FROM listing WHERE id = ? AND symbol = ?", id, symbol);
      return reply({ id, symbol, deleted: true, catalogueRevision: this.bumpCatalogueRevision() });
    });
  }
  replaceAith(id, input, actor, now) {
    const key = input?.operationKey;
    if (!input || typeof key !== "string" || !PUBLISH_KEY.test(key) || !["prepare", "commit", "cancel"].includes(String(input.phase))) return reply({ error: "invalid_replacement_request" }, 400);
    return this.state.storage.transactionSync(() => {
      const receiptKey = `aith_replacement_receipt:${key}`;
      const receipt = this.sql.exec("SELECT v FROM meta WHERE k = ?", receiptKey).toArray()[0];
      if (receipt) {
        const result2 = JSON.parse(String(receipt.v));
        return result2.id === id ? reply({ ...result2, replayed: true }) : reply({ error: "replacement_key_conflict" }, 409);
      }
      const row = this.sql.exec("SELECT * FROM listing WHERE id = ?", id).toArray()[0];
      if (!row || row.active_version === null || !isAith(row.symbol)) return reply({ error: "replacement_not_supported" }, 422);
      const active = JSON.parse(String(this.version(id, Number(row.active_version)).config));
      const pending = this.replacement();
      if (pending && (pending.id !== id || pending.operationKey !== key)) return reply({ error: "replacement_in_progress" }, 409);
      if (input.phase === "cancel") {
        if (!pending) return reply({ error: "replacement_not_prepared" }, 409);
        const result2 = { id, operationKey: key, phase: "CANCELLED", version: Number(row.active_version), requestedAt: pending.requestedAt, requestedBy: pending.requestedBy, cancelledAt: now, cancelledBy: actor };
        this.setMeta(receiptKey, JSON.stringify(result2));
        this.sql.exec("DELETE FROM meta WHERE k = 'aith_replacement_pending'");
        this.setMeta("catalogue_revision", String(BigInt(this.catalogueRevision()) + 1n));
        return reply(result2);
      }
      if (this.sql.exec("SELECT v FROM meta WHERE k = 'aith_public_history_started'").toArray().length) return reply({ error: "HISTORY_LOCKED" }, 422);
      if (input?.phase === "prepare") {
        if (pending) return reply(pending);
        if (input.expectedVersion !== Number(row.active_version) || input.draftRevision !== Number(row.draft_revision)) return reply({ error: "revision_conflict" }, 409);
        let next2;
        try {
          next2 = aithReplacementConfig(active, input.config, now);
        } catch (error) {
          return validationReply(error);
        }
        if (JSON.stringify(next2) === JSON.stringify(active)) return reply({ error: "replacement_already_active" }, 409);
        const lastLease = Number(this.sql.exec("SELECT v FROM meta WHERE k = 'aith_last_read_lease'").toArray()[0]?.v ?? 0);
        const prepared = {
          id,
          operationKey: key,
          phase: "PREPARED",
          expectedVersion: Number(row.active_version),
          draftRevision: Number(row.draft_revision),
          config: next2,
          requestedAt: now,
          requestedBy: actor,
          notBefore: Math.max(now + AITH_READ_LEASE_MS, lastLease) + AITH_LEASE_SAFETY_MS
        };
        this.setMeta("aith_replacement_pending", JSON.stringify(prepared));
        this.setMeta("catalogue_revision", String(BigInt(this.catalogueRevision()) + 1n));
        return reply(prepared);
      }
      if (!pending) return reply({ error: "replacement_not_prepared" }, 409);
      if (now < Number(pending.notBefore)) return reply({ error: "replacement_leases_active", notBefore: pending.notBefore }, 409);
      if (Number(row.active_version) !== pending.expectedVersion || Number(row.draft_revision) !== pending.draftRevision) return reply({ error: "revision_conflict" }, 409);
      let next;
      try {
        next = aithReplacementConfig(active, pending.config, now);
      } catch (error) {
        return validationReply(error);
      }
      const version = Number(this.sql.exec("SELECT MAX(version) AS v FROM listing_version WHERE listing_id = ?", id).toArray()[0].v) + 1;
      this.sql.exec("INSERT INTO listing_version (listing_id, version, config, publish_key, published_at, published_by) VALUES (?, ?, ?, ?, ?, ?)", id, version, JSON.stringify(next), key, now, actor);
      this.sql.exec("UPDATE listing SET active_version = ?, draft = ?, draft_revision = draft_revision + 1, draft_updated_at = ?, draft_updated_by = ? WHERE id = ?", version, JSON.stringify(next), now, actor, id);
      const result = { id, operationKey: key, phase: "COMMITTED", version, replacedVersion: pending.expectedVersion, requestedAt: pending.requestedAt, requestedBy: pending.requestedBy, publishedAt: new Date(now).toISOString(), publishedBy: actor };
      this.setMeta(receiptKey, JSON.stringify(result));
      this.sql.exec("DELETE FROM meta WHERE k = 'aith_replacement_pending'");
      this.setMeta("catalogue_revision", String(BigInt(this.catalogueRevision()) + 1n));
      return reply(result);
    });
  }
  /**
   * Every active version, as the public catalogue and Render's trading
   * registry read it. A staged listing (timer never started, or stopped) is
   * not public: only Render learns it, with the timer state, so its ticker
   * stays restricted everywhere.
   */
  published(includeStaged = false) {
    const rows = this.sql.exec(`SELECT l.id, v.version, v.config, v.published_at FROM listing l
      JOIN listing_version v ON v.listing_id = l.id AND v.version = l.active_version ORDER BY v.published_at, l.id`).toArray();
    const now = Date.now();
    const pending = this.replacement();
    const listings = [];
    for (const row of rows) {
      const config = JSON.parse(String(row.config));
      const countdown = this.countdownOf(String(row.id));
      if (countdown?.state === "staged" && !includeStaged) continue;
      const listing = {
        id: String(row.id),
        version: Number(row.version),
        publishedAt: new Date(Number(row.published_at)).toISOString(),
        config,
        ...countdown ? { countdown } : {}
      };
      if (isAith(config.symbol)) {
        if (pending) continue;
        if (now >= Date.parse(config.listingAt) && listingCountdownArmed(listing)) this.setMeta("aith_public_history_started", String(now));
        const expiresAt = now + AITH_READ_LEASE_MS;
        this.setMeta("aith_last_read_lease", String(Math.max(expiresAt, Number(this.sql.exec("SELECT v FROM meta WHERE k = 'aith_last_read_lease'").toArray()[0]?.v ?? 0))));
        listing.readLease = { protocol: AITH_PUBLICATION_PROTOCOL, generation: listing.version, issuedAt: now, expiresAt };
      }
      listings.push(listing);
    }
    return {
      revision: this.catalogueRevision(),
      listings
    };
  }
  /** The admin view: drafts, active configuration and version history. */
  adminList() {
    const listings = this.sql.exec("SELECT * FROM listing ORDER BY created_at, id").toArray().map((row) => {
      const id = String(row.id);
      const active = row.active_version === null ? null : this.version(id, Number(row.active_version));
      const versions = this.sql.exec("SELECT version, published_at, published_by FROM listing_version WHERE listing_id = ? ORDER BY version DESC", id).toArray().map((v) => ({ version: Number(v.version), publishedAt: new Date(Number(v.published_at)).toISOString(), publishedBy: String(v.published_by) }));
      return {
        id,
        symbol: String(row.symbol),
        draft: JSON.parse(String(row.draft)),
        draftRevision: Number(row.draft_revision),
        draftUpdatedAt: new Date(Number(row.draft_updated_at)).toISOString(),
        draftUpdatedBy: String(row.draft_updated_by),
        activeVersion: row.active_version === null ? null : Number(row.active_version),
        active: active ? JSON.parse(String(active.config)) : null,
        versions,
        countdown: this.countdownOf(id)
      };
    });
    return { revision: this.catalogueRevision(), serverTime: Date.now(), listings };
  }
  saveDraft(id, ifMatch, input, actor, now) {
    if (this.replacement()?.id === id) return reply({ error: "replacement_in_progress" }, 409);
    let config;
    try {
      config = parseListingConfig(input);
    } catch (error) {
      return validationReply(error);
    }
    return this.state.storage.transactionSync(() => {
      const row = this.sql.exec("SELECT * FROM listing WHERE id = ?", id).toArray()[0];
      const current = row ? String(row.draft_revision) : "0";
      if (current !== ifMatch) return reply({ error: "revision_conflict", draftRevision: Number(current) }, 409);
      const previous = row ? JSON.parse(String(row.draft)) : null;
      const active = row && row.active_version !== null ? JSON.parse(String(this.version(id, Number(row.active_version)).config)) : null;
      const ordinal = row ? null : this.profileOrdinal();
      let next;
      try {
        next = withStableProfile(withStableSeed(config, previous), previous, ordinal);
      } catch (error) {
        return validationReply(error);
      }
      if (active && (next.simulationProgram?.kind === "scenario-controls-v2" || active.simulationProgram?.kind === "scenario-controls-v2")) {
        try {
          checkPublishable(next, active, now);
        } catch (error) {
          return validationReply(error);
        }
      }
      if (active && (next.symbol !== active.symbol || next.seed !== active.seed || next.initialPrice !== active.initialPrice)) {
        return reply({ error: "HISTORY_LOCKED", message: "The ticker, seed and initial price of a published listing cannot change" }, 422);
      }
      const clash = this.sql.exec("SELECT id FROM listing WHERE symbol = ? AND id <> ?", next.symbol, id).toArray()[0];
      if (clash) return reply({ error: "DUPLICATE_TICKER", message: `Ticker ${next.symbol} is already used by another listing` }, 409);
      const revision = Number(current) + 1;
      if (row) {
        this.sql.exec(
          "UPDATE listing SET symbol = ?, draft = ?, draft_revision = ?, draft_updated_at = ?, draft_updated_by = ? WHERE id = ?",
          next.symbol,
          JSON.stringify(next),
          revision,
          now,
          actor,
          id
        );
      } else {
        this.sql.exec(
          "INSERT INTO listing (id, symbol, draft, draft_revision, draft_updated_at, draft_updated_by, active_version, created_at) VALUES (?, ?, ?, ?, ?, ?, NULL, ?)",
          id,
          next.symbol,
          JSON.stringify(next),
          revision,
          now,
          actor,
          now
        );
        this.sql.exec("INSERT INTO meta (k, v) VALUES ('simulation_profile_ordinal', ?) ON CONFLICT(k) DO UPDATE SET v = excluded.v", String(ordinal + 1));
      }
      return reply({ id, draftRevision: revision, draft: next });
    });
  }
  /**
   * `countdown: 'staged'` on a FIRST publication keeps the listing off the
   * public edge until the admin starts its timer; omitted (or `'running'`),
   * the countdown is public at once, as before the timer existed.
   */
  publish(id, draftRevision, publishKey, countdown, actor, now) {
    if (this.replacement()?.id === id) return reply({ error: "replacement_in_progress" }, 409);
    if (!Number.isSafeInteger(draftRevision) || typeof publishKey !== "string" || !PUBLISH_KEY.test(publishKey)) return reply({ error: "invalid_publish_request" }, 400);
    if (countdown !== void 0 && countdown !== "staged" && countdown !== "running") return reply({ error: "invalid_publish_request" }, 400);
    return this.state.storage.transactionSync(() => {
      const row = this.sql.exec("SELECT * FROM listing WHERE id = ?", id).toArray()[0];
      if (!row) return reply({ error: "not_found" }, 404);
      const receipt = /* @__PURE__ */ __name((version2, publishedAt) => reply({ id, version: version2, replayed: true, publishedAt: new Date(publishedAt).toISOString(), countdown: this.countdownOf(id) }), "receipt");
      const replay = this.sql.exec("SELECT version, published_at FROM listing_version WHERE listing_id = ? AND publish_key = ?", id, publishKey).toArray()[0];
      if (replay) return receipt(Number(replay.version), Number(replay.published_at));
      if (Number(row.draft_revision) !== draftRevision) return reply({ error: "revision_conflict", draftRevision: Number(row.draft_revision) }, 409);
      let config;
      try {
        config = parseListingConfig(JSON.parse(String(row.draft)));
        const active = row.active_version === null ? null : JSON.parse(String(this.version(id, Number(row.active_version)).config));
        if (active && JSON.stringify(config) === JSON.stringify(active)) {
          const current = this.version(id, Number(row.active_version));
          return receipt(Number(row.active_version), Number(current.published_at));
        }
        const opened = active !== null && listingOpened({ config: active, countdown: this.countdownOf(id) ?? void 0 }, now);
        checkPublishable(config, active, now, envMs(this.env.LISTINGS_MIN_LEAD_MS, MIN_LEAD_MS, MIN_LEAD_FLOOR_MS), opened);
      } catch (error) {
        return validationReply(error);
      }
      const version = (row.active_version === null ? 0 : Number(this.sql.exec("SELECT MAX(version) AS v FROM listing_version WHERE listing_id = ?", id).toArray()[0].v)) + 1;
      this.sql.exec(
        "INSERT INTO listing_version (listing_id, version, config, publish_key, published_at, published_by) VALUES (?, ?, ?, ?, ?, ?)",
        id,
        version,
        JSON.stringify(config),
        publishKey,
        now,
        actor
      );
      this.sql.exec("UPDATE listing SET active_version = ? WHERE id = ?", version, id);
      if (row.active_version === null && countdown === "staged") this.setMeta(`countdown:${id}`, JSON.stringify({ state: "staged", updatedAt: now, updatedBy: actor }));
      const revision = this.bumpCatalogueRevision();
      return reply({ id, version, replayed: false, publishedAt: new Date(now).toISOString(), catalogueRevision: revision, countdown: this.countdownOf(id) });
    });
  }
  async fetch(request) {
    const url = new URL(request.url);
    try {
      if (url.pathname === "/published" && request.method === "GET") return reply(this.published());
      const denied = await authorizeListingsAdmin(request, this.env);
      if (denied) return denied;
      const actor = request.headers.get("X-Voltex-Admin-Id") ?? "";
      if (url.pathname === "/internal/listings" && request.method === "GET") return reply(this.adminList());
      if (url.pathname === "/internal/listings/published" && request.method === "GET") return reply(this.published(true));
      const history = /^\/internal\/listings\/([^/]+)\/versions\/([1-9]\d{0,8})$/.exec(url.pathname);
      if (history && request.method === "GET" && LISTING_ID_PATTERN.test(history[1])) {
        const row = this.version(history[1], Number(history[2]));
        return row ? reply({
          id: history[1],
          version: Number(row.version),
          config: JSON.parse(String(row.config)),
          publishedAt: new Date(Number(row.published_at)).toISOString(),
          publishedBy: String(row.published_by)
        }) : reply({ error: "not_found" }, 404);
      }
      const match = /^\/internal\/listings\/([^/]+)\/(draft|publish|replace-prelisting|countdown|delete|reschedule)$/.exec(url.pathname);
      if (!match || !LISTING_ID_PATTERN.test(match[1])) return reply({ error: "not_found" }, 404);
      if (!ACTOR.test(actor)) return reply({ error: "actor_required" }, 400);
      const body = await readJson(request);
      if (body.error) return body.error;
if(match[2]==='reschedule' && request.method==='POST')return this.reschedule(match[1],body.value,actor,Date.now());
      if (match[2] === "delete" && request.method === "POST") return this.deleteListing(match[1], body.value);
      if (match[2] === "replace-prelisting" && request.method === "POST") {
        if (request.headers.get("X-Voltex-Listing-Protocol") !== AITH_PUBLICATION_PROTOCOL) return reply({ error: "replacement_protocol_required" }, 428);
        return this.replaceAith(match[1], body.value, actor, Date.now());
      }
      if (match[2] === "draft" && request.method === "PUT") {
        const ifMatch = request.headers.get("If-Match");
        if (!ifMatch) return reply({ error: "if_match_required" }, 428);
        if (!/^(0|[1-9]\d{0,15})$/.test(ifMatch)) return reply({ error: "invalid_revision" }, 400);
        return this.saveDraft(match[1], ifMatch, body.value?.config, actor, Date.now());
      }
      if (match[2] === "publish" && request.method === "POST") {
        return this.publish(match[1], body.value?.draftRevision, body.value?.publishKey, body.value?.countdown, actor, Date.now());
      }
      if (match[2] === "countdown" && request.method === "POST") {
        return this.countdown(match[1], body.value, actor, Date.now());
      }
      return reply({ error: "method_not_allowed" }, 405);
    } catch {
      return reply({ error: "store_unavailable" }, 503);
    }
  }

reschedule(id, body, actor, now) {
    if (!body || Object.keys(body).sort().join(",") !== "activeVersion,days,draftRevision,operationKey" || ![1, 2, 3].includes(Number(body.days)) || typeof body.days !== "number" || !Number.isSafeInteger(body.draftRevision) || Number(body.draftRevision) < 1 || !(body.activeVersion === null || Number.isSafeInteger(body.activeVersion) && Number(body.activeVersion) > 0) || typeof body.operationKey !== "string" || !PUBLISH_KEY.test(body.operationKey)) return reply({ error: "INVALID_RESCHEDULE_REQUEST" }, 400);
    if (this.replacement()?.id === id) return reply({ error: "replacement_in_progress" }, 409);
    return this.state.storage.transactionSync(() => {
      const receiptKey = `reschedule:${id}:${body.operationKey}`;
      const previous = this.sql.exec("SELECT v FROM meta WHERE k = ?", receiptKey).toArray()[0];
      const signature = JSON.stringify([body.days, body.draftRevision, body.activeVersion, actor]);
      if (previous) {
        const saved = JSON.parse(String(previous.v));
        return saved.signature === signature ? reply({ ...saved.receipt, replayed: true }) : reply({ error: "OPERATION_KEY_CONFLICT" }, 409);
      }
      const row = this.sql.exec("SELECT * FROM listing WHERE id = ?", id).toArray()[0];
      if (!row) return reply({ error: "not_found" }, 404);
      const activeVersion = row.active_version === null ? null : Number(row.active_version);
      if (Number(row.draft_revision) !== body.draftRevision || activeVersion !== body.activeVersion)
        return reply({ error: "revision_conflict", draftRevision: Number(row.draft_revision) }, 409);
      const draft = parseListingConfig(JSON.parse(String(row.draft)));
      const active = activeVersion === null ? null : parseListingConfig(JSON.parse(String(this.version(id, activeVersion).config)));
      if (active && JSON.stringify(active) !== JSON.stringify(draft)) return reply({ error: "DRAFT_DIFFERS_FROM_ACTIVE" }, 409);
      const source = active ?? draft;
      if (source.tradable || Number(source.ownerAllocation) !== 0 || source.privateTest || isAith(source.symbol))
        return reply({ error: "RESCHEDULE_DEMO_ONLY" }, 422);
      if (Date.parse(source.listingAt) <= now + MIN_LEAD_MS) return reply({ error: "HISTORY_LOCKED" }, 422);
      const listingAt = AiListingSchedule.shiftListingDate(source.listingAt, source.displayTimeZone, body.days);
      if (!listingAt) return reply({ error: "AMBIGUOUS_LISTING_TIME" }, 422);
      const next = parseListingConfig({ ...source, listingAt });
      try {
        checkPublishable(next, active, now);
      } catch (error) {
        return validationReply(error);
      }
      let version = activeVersion;
      if (version !== null) {
        version = Number(this.sql.exec("SELECT MAX(version) AS v FROM listing_version WHERE listing_id = ?", id).toArray()[0].v) + 1;
        this.sql.exec(
          "INSERT INTO listing_version (listing_id, version, config, publish_key, published_at, published_by) VALUES (?, ?, ?, ?, ?, ?)",
          id,
          version,
          JSON.stringify(next),
          `reschedule-${body.operationKey}`,
          now,
          actor
        );
      }
      const draftRevision = Number(row.draft_revision) + 1;
      this.sql.exec(
        "UPDATE listing SET draft = ?, draft_revision = ?, draft_updated_at = ?, draft_updated_by = ?, active_version = ? WHERE id = ?",
        JSON.stringify(next),
        draftRevision,
        now,
        actor,
        version,
        id
      );
      this.bumpCatalogueRevision();
      const receipt = {
        id,
        draftRevision,
        activeVersion: version,
        previousListingAt: source.listingAt,
        listingAt,
        operationKey: body.operationKey,
        replayed: false,
        countdown: this.countdownOf(id)
      };
      this.setMeta(receiptKey, JSON.stringify({ signature, receipt, changedAt: now, changedBy: actor }));
      return reply(receipt);
    });
  }
};
function listingsStub(env) {
  if (!env.LISTINGS) return null;
  return env.LISTINGS.get(env.LISTINGS.idFromName(OBJECT_NAME));
}
__name(listingsStub, "listingsStub");
var PUBLISHED_CACHE_MS = 15e3;
var cache = null;
var inFlight = null;
function usablePublished(snapshot, now) {
  return snapshot && { ...snapshot, listings: snapshot.listings.filter((item) => !isAith(item.config.symbol) || validAithLease(item.readLease, item.version, now)) };
}
__name(usablePublished, "usablePublished");
async function publishedListings(env, now = Date.now()) {
  if (cache && now - cache.at < envMs(env.LISTINGS_PUBLIC_CACHE_MS, PUBLISHED_CACHE_MS, 0)) return usablePublished(cache, now);
  const stub = listingsStub(env);
  if (!stub) return usablePublished(cache, now);
  if (!inFlight) {
    inFlight = stub.fetch(new Request("https://listings.internal/published")).then(async (response) => {
      if (!response.ok) throw new Error(`store ${response.status}`);
      const body = await response.json();
      const listings = body.listings.filter((item) => {
        try {
          parseListingConfig(item.config);
          return true;
        } catch {
          return false;
        }
      });
      cache = { at: Date.now(), revision: String(body.revision), listings };
      return cache;
    }).catch(() => cache).finally(() => {
      inFlight = null;
    });
  }
  return usablePublished(await inFlight, Date.now());
}
__name(publishedListings, "publishedListings");

// src/worker.ts
var unavailable = /* @__PURE__ */ __name(() => new Response(JSON.stringify({ error: "listings_unavailable" }), {
  status: 503,
  headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store", "access-control-allow-origin": "*" }
}), "unavailable");
var worker_default = {
  async fetch(request, env = {}) {
    if (new URL(request.url).pathname === "/market/simulations/status" && ["GET", "HEAD"].includes(request.method)) {
      return new Response(request.method === "HEAD" ? null : JSON.stringify({
        source: "simulation",
        boundedDemoProgram: "capped-growth-range-v1"
      }), { headers: { "content-type": "application/json", "cache-control": "no-store", "access-control-allow-origin": "*" } });
    }
    const nrx = nrxPublicResponse(request);
    if (nrx) return nrx;
    const url = new URL(request.url);
    if (url.pathname === "/internal/listings" || url.pathname.startsWith("/internal/listings/")) {
      const denied = await authorizeListingsAdmin(request, env);
      if (denied) return denied;
      const stub = listingsStub(env);
      return stub ? stub.fetch(request) : unavailable();
    }
    const isCatalogue = url.pathname === PUBLIC_CATALOGUE_PATH;
    const isAithPath = /(?:^|\/)AITH-USDT(?:\/|$)/i.test(url.pathname);
    if (isCatalogue || /^\/(market|orderbook)\//.test(url.pathname)) {
      const published = await publishedListings(env);
      if (!published) {
        if (isCatalogue || isAithPath) return unavailable();
      } else if (isCatalogue || listingForPath(url.pathname, published.listings)) {
        const response = managedListingResponse(request, published.listings, Date.now(), published.revision);
        if (response) return response;
      }
      if (isAithPath) return unavailable();
    }
    return index_default.fetch(request);
  }
};
export {
  ManagedListingsDO,
  worker_default as default
};
// Source: existing live Worker + reviewed ECLV two-function terminal-peak patch; previous map omitted.

"use strict";
var AiListingScenarioControls = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // src/shared/listingScenarioControls.ts
  var listingScenarioControls_exports = {};
  __export(listingScenarioControls_exports, {
    HISTORICAL_GROWTH_LIMITS: () => HISTORICAL_GROWTH_LIMITS,
    LISTING_SCENARIOS: () => LISTING_SCENARIOS,
    defaultScenarioControls: () => defaultScenarioControls,
    exactGainFromPrice: () => exactGainFromPrice,
    exactPriceFraction: () => exactPriceFraction,
    exactPriceFromGain: () => exactPriceFromGain,
    normalizeScenarioDecimal: () => normalizeScenarioDecimal,
    validateHistoricalGrowthStructure: () => validateHistoricalGrowthStructure,
    validateScenarioControls: () => validateScenarioControls
  });
  var LISTING_SCENARIOS = ["CALM", "WAVES", "FREQUENT_PULLBACKS", "COMPRESSION_BREAKOUT", "STAIRCASE", "SLOW_START", "FAST_START", "FALSE_BREAKOUT", "DEEP_RECOVERY", "LONG_WICKS"];
  function validateHistoricalMoveProgram(program) {
    if (!program || program.version !== 1 || !Array.isArray(program.clips) || program.clips.length < 1 || program.clips.length > 3)
      throw new Error("\u0414\u043E\u0431\u0430\u0432\u044C\u0442\u0435 \u043E\u0442 \u043E\u0434\u043D\u043E\u0433\u043E \u0434\u043E \u0442\u0440\u0451\u0445 \u0438\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u043E\u0442\u0440\u0435\u0437\u043A\u043E\u0432");
    let count = 0;
    for (const clip of program.clips) {
      if (!["BTC/USDT", "ETH/USDT", "SOL/USDT"].includes(clip.source) || clip.resolution !== "1h" || clip.provenance !== "USER_SUPPLIED_UNVERIFIED" || !/^\d{4}-\d\d-\d\dT\d\d:00:00\.000Z$/.test(clip.sourceStart) || !Number.isFinite(Date.parse(clip.sourceStart)) || new Date(clip.sourceStart).toISOString() !== clip.sourceStart)
        throw new Error("\u041D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u043E\u0435 \u0438\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u043E\u0435 \u0434\u0432\u0438\u0436\u0435\u043D\u0438\u0435 \u0438\u043B\u0438 \u0438\u0441\u0442\u043E\u0447\u043D\u0438\u043A");
      if (!Array.isArray(clip.bars) || clip.bars.length < 24 || clip.bars.length > 2400)
        throw new Error("\u041E\u0442\u0440\u0435\u0437\u043E\u043A \u0434\u043E\u043B\u0436\u0435\u043D \u0441\u043E\u0434\u0435\u0440\u0436\u0430\u0442\u044C \u043E\u0442 24 \u0434\u043E 2400 \u043F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u044B\u0445 \u0447\u0430\u0441\u043E\u0432");
      count += clip.bars.length;
      for (const bar of clip.bars) {
        if (!Array.isArray(bar) || bar.length !== 3 || !bar.every(Number.isSafeInteger))
          throw new Error("\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u044B\u0435 \u0438\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u043A\u043E\u044D\u0444\u0444\u0438\u0446\u0438\u0435\u043D\u0442\u044B OHLC");
        const [hi, lo, close] = bar;
        if (hi < Math.max(0, close) || lo > Math.min(0, close) || lo <= -1e6 || hi > 4e6 || close <= -1e6 || close > 4e6)
          throw new Error("\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0435 \u0433\u0440\u0430\u043D\u0438\u0446\u044B \u0438\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u043E\u0439 \u0441\u0432\u0435\u0447\u0438");
      }
    }
    if (count > 4800) throw new Error("\u041D\u0435 \u0431\u043E\u043B\u0435\u0435 4800 \u0447\u0430\u0441\u043E\u0432 \u0432 \u0446\u0435\u043F\u043E\u0447\u043A\u0435");
  }
  function historicalReplayBounds(program, anchor) {
    validateHistoricalMoveProgram(program);
    if (!(anchor > 0) || !Number.isFinite(anchor)) throw new Error("\u041D\u0435\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u043D\u0430\u044F \u0446\u0435\u043D\u0430 \u0441\u043E\u0435\u0434\u0438\u043D\u0435\u043D\u0438\u044F");
    let close = anchor, min = anchor, max = anchor;
    for (const clip of program.clips) for (const [h, l, c] of clip.bars) {
      min = Math.min(min, close * (1 + l / 1e6));
      max = Math.max(max, close * (1 + h / 1e6));
      close *= 1 + c / 1e6;
      if (!Number.isFinite(close) || close < 1e-8 || close > 1e9)
        throw new Error("\u0418\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u0438\u0439 \u043E\u0442\u0440\u0435\u0437\u043E\u043A \u0432\u044B\u0445\u043E\u0434\u0438\u0442 \u0437\u0430 \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u043C\u0443\u044E \u0442\u043E\u0447\u043D\u043E\u0441\u0442\u044C \u0446\u0435\u043D\u044B");
    }
    return { min, max, close };
  }
  function normalizeScenarioDecimal(input) {
    const text = input.trim().replace(",", ".");
    if (!/^\d{1,18}(?:\.\d{1,10})?$/.test(text)) throw new RangeError("\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u043F\u043E\u043B\u043E\u0436\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0435 \u0447\u0438\u0441\u043B\u043E, \u043D\u0435 \u0431\u043E\u043B\u0435\u0435 10 \u0437\u043D\u0430\u043A\u043E\u0432 \u043F\u043E\u0441\u043B\u0435 \u0437\u0430\u043F\u044F\u0442\u043E\u0439");
    const [whole, fraction = ""] = text.split(".");
    const clean = fraction.replace(/0+$/, "");
    return `${BigInt(whole)}${clean ? `.${clean}` : ""}`;
  }
  var SCALE = 10000000000n;
  function units(input) {
    const [whole, fraction = ""] = normalizeScenarioDecimal(input).split(".");
    return BigInt(whole) * SCALE + BigInt(fraction.padEnd(10, "0"));
  }
  function decimal(value) {
    const negative = value < 0n;
    const absolute = negative ? -value : value;
    const fraction = (absolute % SCALE).toString().padStart(10, "0").replace(/0+$/, "");
    return `${negative ? "-" : ""}${absolute / SCALE}${fraction ? `.${fraction}` : ""}`;
  }
  function exactPriceFromGain(initialPrice, gainPercent) {
    return decimal(units(initialPrice) * (100n * SCALE + units(gainPercent)) / (100n * SCALE));
  }
  function exactGainFromPrice(initialPrice, price) {
    const initial = units(initialPrice);
    if (initial <= 0n) throw new RangeError("\u041D\u0430\u0447\u0430\u043B\u044C\u043D\u0430\u044F \u0446\u0435\u043D\u0430 \u0434\u043E\u043B\u0436\u043D\u0430 \u0431\u044B\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435 \u043D\u0443\u043B\u044F");
    return decimal((units(price) - initial) * 100n * SCALE / initial);
  }
  function exactPriceFraction(price, numerator, denominator = 100) {
    return decimal(units(price) * BigInt(numerator) / BigInt(denominator));
  }
  function defaultScenarioControls(initialPrice, scenario = "CALM", first24hGainPercent = "1725", maxPrice = exactPriceFromGain(initialPrice, "9247"), growthHours = 168) {
    const calm = scenario === "CALM", frequent = scenario === "FREQUENT_PULLBACKS", deep = scenario === "DEEP_RECOVERY", shadows = scenario === "LONG_WICKS";
    return {
      kind: "scenario-controls-v2",
      scenario,
      first24hGainPercent: normalizeScenarioDecimal(first24hGainPercent),
      maxPrice: normalizeScenarioDecimal(maxPrice),
      stages: [
        { type: "growth", durationHours: 24, targetPrice: exactPriceFromGain(initialPrice, first24hGainPercent) },
        ...growthHours > 24 ? [{ type: "growth", durationHours: growthHours - 24, targetPrice: exactPriceFraction(maxPrice, 86) }] : []
      ],
      afterGrowth: "range",
      pullbacks: { frequency: calm ? "rare" : frequent || deep ? "often" : "moderate", minDepthPercent: calm ? "0.5" : deep ? "8" : frequent ? "3" : "2", maxDepthPercent: calm ? "3" : deep ? "22" : frequent ? "12" : "8", durationMinutes: 45 },
      candles: { intensity: calm ? "low" : shadows ? "high" : "medium", diversity: calm ? 0.3 : shadows ? 0.9 : 0.65, pauseFrequency: calm ? "rare" : "moderate" },
      wicks: { length: calm ? "short" : shadows ? "pronounced" : "normal", longFrequency: calm ? "rare" : shadows ? "often" : "moderate" }
    };
  }
  var HISTORICAL_GROWTH_LIMITS = { minRows: 30, maxRows: 1500, minPeakPercent: 7248, maxPeakPercent: 15324, logScale: 1e8, maxAbsLog: 2e9 };
  function validateHistoricalGrowthStructure(program) {
    const L = HISTORICAL_GROWTH_LIMITS;
    if (!program || program.format !== "voltex.historical-growth.v1" || program.scenarioVersion !== 1 || typeof program.scenarioId !== "string" || !/^VHX-\d{2}-[A-Z0-9]{2,10}$/.test(program.scenarioId) || program.rights !== "HISTORICAL_RIGHTS_UNVERIFIED")
      throw new RangeError("\u041D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u044B\u0439 \u0444\u043E\u0440\u043C\u0430\u0442 \u0438\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u043E\u0433\u043E \u043E\u043A\u043D\u0430 \u0440\u043E\u0441\u0442\u0430");
    const s = program.source;
    const reference = !!s && s.dataKind === "daily_reference" && s.provider === "Coin Metrics" && s.quote === "USD" && s.metric === "PriceUSD" && s.license === "CC-BY-NC-4.0";
    const ohlc = !!s && s.dataKind === "exchange_ohlcv" && s.provider === "Binance Vision" && s.quote === "USDT" && s.metric === "spot daily OHLCV" && s.license === "CC-BY-NC-SA-4.0 plus Binance Vision Dataset Terms";
    if (!s || !reference && !ohlc || typeof s.asset !== "string" || !/^[A-Z0-9]{2,10}$/.test(s.asset) || s.timeframe !== "1d" || typeof s.sliceSha256 !== "string" || !/^[a-f0-9]{64}$/.test(s.sliceSha256))
      throw new RangeError("\u0418\u0441\u0442\u043E\u0447\u043D\u0438\u043A \u0438\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u043E\u0433\u043E \u043E\u043A\u043D\u0430 \u043E\u043F\u0438\u0441\u0430\u043D \u043D\u0435 \u043F\u043E\u043B\u043D\u043E\u0441\u0442\u044C\u044E");
    const c = program.clock;
    if (!c || c.mode !== "REAL_TIME" || c.sourceStepSeconds !== 86400 || c.scenarioStepSeconds !== 86400)
      throw new RangeError("\u0418\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u043E\u0435 \u043E\u043A\u043D\u043E \u0440\u0430\u0431\u043E\u0442\u0430\u0435\u0442 \u0442\u043E\u043B\u044C\u043A\u043E \u0432 \u0440\u0435\u0430\u043B\u044C\u043D\u043E\u043C \u0432\u0440\u0435\u043C\u0435\u043D\u0438: \u0441\u0443\u0442\u043A\u0438 \u0438\u0441\u0442\u043E\u0447\u043D\u0438\u043A\u0430 = \u0441\u0443\u0442\u043A\u0438 \u0441\u0446\u0435\u043D\u0430\u0440\u0438\u044F");
    if (ohlc ? program.intrabar !== "SEEDED_OHLC_PATH_V1" && program.intrabar !== "SEEDED_BRIDGE_OHLC_V2" : program.intrabar !== "LOG_LINEAR_REFERENCE_V1" && program.intrabar !== "SEEDED_BRIDGE_REFERENCE_V2")
      throw new RangeError("\u041C\u043E\u0434\u0435\u043B\u044C \u0432\u043D\u0443\u0442\u0440\u0438 \u0441\u0443\u0442\u043E\u043A \u043D\u0435 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u0442\u0438\u043F\u0443 \u0434\u0430\u043D\u043D\u044B\u0445");
    const target = program.targetPeakGrowthPercent;
    if (typeof target !== "string" || !/^\d{4,5}(?:\.\d{1,2})?$/.test(target) || Number(target) < L.minPeakPercent || Number(target) > L.maxPeakPercent)
      throw new RangeError("\u041F\u0438\u043A \u0441\u0446\u0435\u043D\u0430\u0440\u0438\u044F \u0434\u043E\u043B\u0436\u0435\u043D \u0431\u044B\u0442\u044C \u043E\u0442 +7248% \u0434\u043E +15324% \u043E\u0442 \u043D\u0430\u0447\u0430\u043B\u044C\u043D\u043E\u0439 \u0446\u0435\u043D\u044B");
    const n = program.targetNormalization;
    if (n !== void 0 && (n.version !== 1 || n.method !== "LOG_AMPLITUDE_OWNER_CAP" || n.sourceTargetPeakGrowthPercent !== "15324" || n.maxTargetPeakGrowthPercent !== "15000" || Object.keys(n).sort().join(",") !== "maxTargetPeakGrowthPercent,method,sourceTargetPeakGrowthPercent,version" || target !== "15000" || program.scenarioId !== "VHX-09-MATIC" || s.asset !== "MATIC" || s.sliceSha256 !== "82ff2bd811e39eed37f01d72c3c204e46b7d9d9a7775a788c6a1710a351615eb"))
      throw new RangeError("\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u0432\u0435\u0440\u0441\u0438\u044F \u043D\u043E\u0440\u043C\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u0438 \u0446\u0435\u043B\u0438 History20");
    const rows = program.logs, width = ohlc ? 4 : 1;
    if (!Array.isArray(rows) || rows.length < L.minRows || rows.length > L.maxRows)
      throw new RangeError("\u0418\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u043E\u0435 \u043E\u043A\u043D\u043E: \u043E\u0442 30 \u0434\u043E 1500 \u0441\u0443\u0442\u043E\u043A \u0438\u0441\u0442\u043E\u0447\u043D\u0438\u043A\u0430");
    const day = (text) => {
      if (typeof text !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(text)) return NaN;
      const at = Date.parse(text + "T00:00:00.000Z");
      return Number.isFinite(at) && new Date(at).toISOString().slice(0, 10) === text ? at : NaN;
    };
    const first = day(s.firstDate), last = day(s.lastDate);
    if (!Number.isFinite(first) || !Number.isFinite(last) || last - first !== (rows.length - 1) * 864e5)
      throw new RangeError("\u0414\u0430\u0442\u044B \u0438\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u043E\u0433\u043E \u043E\u043A\u043D\u0430 \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u044E\u0442 \u0441 \u0447\u0438\u0441\u043B\u043E\u043C \u0441\u0443\u0442\u043E\u043A: \u043F\u0440\u043E\u043F\u0443\u0441\u043A\u0438 \u043D\u0435 \u0434\u043E\u043F\u0443\u0441\u043A\u0430\u044E\u0442\u0441\u044F");
    let max = -Infinity;
    for (const row of rows) {
      if (!Array.isArray(row) || row.length !== width || !row.every((v) => Number.isSafeInteger(v) && Math.abs(v) <= L.maxAbsLog))
        throw new RangeError("\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u0438\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u043E\u0433\u043E \u043E\u043A\u043D\u0430");
      if (ohlc && (row[1] < Math.max(row[0], row[3]) || row[2] > Math.min(row[0], row[3]))) throw new RangeError("\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u0441\u0432\u0435\u0447\u0430 OHLC \u0432 \u0438\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u043E\u043C \u043E\u043A\u043D\u0435");
      max = Math.max(max, ohlc ? row[1] : row[0]);
    }
    if (rows[0][0] !== 0) throw new RangeError("\u041F\u0435\u0440\u0432\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u043E\u043A\u043D\u0430 \u0434\u043E\u043B\u0436\u043D\u043E \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0442\u044C \u0441 \u043E\u043F\u043E\u0440\u043D\u043E\u0439 \u0446\u0435\u043D\u043E\u0439");
    if (!(max > 0)) throw new RangeError("\u041C\u0430\u043A\u0441\u0438\u043C\u0443\u043C \u043E\u043A\u043D\u0430 \u0434\u043E\u043B\u0436\u0435\u043D \u0431\u044B\u0442\u044C \u0432\u044B\u0448\u0435 \u043F\u0435\u0440\u0432\u043E\u0439 \u0446\u0435\u043D\u044B");
  }
  function validateHistoricalWindowControls(program, initialPrice) {
    if (program.growth !== "historical-window" || !program.historicalGrowth)
      throw new RangeError("\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0438\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u043E\u0435 \u043E\u043A\u043D\u043E \u0440\u043E\u0441\u0442\u0430 \u0438\u043B\u0438 \u0432\u0435\u0440\u043D\u0438\u0442\u0435\u0441\u044C \u043A \u044D\u0442\u0430\u043F\u0430\u043C");
    if (program.stages.length !== 0 || program.afterGrowth !== "range" || program.historical !== void 0 || program.first24hGainPercent !== "0")
      throw new RangeError("\u0418\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u043E\u0435 \u043E\u043A\u043D\u043E \u0437\u0430\u043C\u0435\u043D\u044F\u0435\u0442 \u044D\u0442\u0430\u043F\u044B: \u044D\u0442\u0430\u043F\u044B, \u043F\u0440\u043E\u0434\u043E\u043B\u0436\u0435\u043D\u0438\u0435 \u043F\u043E \u0447\u0430\u0441\u043E\u0432\u044B\u043C \u0441\u0432\u0435\u0447\u0430\u043C \u0438 \u0440\u043E\u0441\u0442 \u0437\u0430 \u043F\u0435\u0440\u0432\u044B\u0435 \u0441\u0443\u0442\u043A\u0438 \u043D\u0435 \u0437\u0430\u0434\u0430\u044E\u0442\u0441\u044F");
    validateHistoricalGrowthStructure(program.historicalGrowth);
    const canonical = normalizeScenarioDecimal(initialPrice);
    if (Number(initialPrice) < 1e-8 || Number(initialPrice) > 1e9 || normalizeScenarioDecimal(Number(initialPrice).toFixed(10)) !== canonical)
      throw new RangeError("\u0426\u0435\u043D\u0430 \u043D\u0435 \u043F\u043E\u043C\u0435\u0449\u0430\u0435\u0442\u0441\u044F \u0432 \u0442\u043E\u0447\u043D\u043E\u0441\u0442\u044C \u0430\u043A\u0442\u0438\u0432\u0430: \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u043E\u0442 0,00000001 \u0434\u043E 1000000000 \u0441 \u043C\u0435\u043D\u044C\u0448\u0438\u043C \u0447\u0438\u0441\u043B\u043E\u043C \u0437\u043D\u0430\u043A\u043E\u0432");
    if (normalizeScenarioDecimal(program.maxPrice) !== exactPriceFromGain(initialPrice, program.historicalGrowth.targetPeakGrowthPercent))
      throw new RangeError("\u041C\u0430\u043A\u0441\u0438\u043C\u0430\u043B\u044C\u043D\u0430\u044F \u0446\u0435\u043D\u0430 \u0438\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u043E\u0433\u043E \u043E\u043A\u043D\u0430 \u0434\u043E\u043B\u0436\u043D\u0430 \u0431\u044B\u0442\u044C \u0440\u043E\u0432\u043D\u043E P0 \xB7 (1 + G/100)");
    if (Number(program.maxPrice) > 1e9) throw new RangeError("\u041F\u0438\u043A \u0438\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u043E\u0433\u043E \u043E\u043A\u043D\u0430 \u0432\u044B\u0445\u043E\u0434\u0438\u0442 \u0437\u0430 \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u043C\u0443\u044E \u0442\u043E\u0447\u043D\u043E\u0441\u0442\u044C \u0446\u0435\u043D\u044B");
    const g = program.historicalGrowth, ohlc = g.source.dataKind === "exchange_ohlcv";
    let max = -Infinity, min = Infinity;
    for (const row of g.logs) {
      max = Math.max(max, ohlc ? row[1] : row[0]);
      min = Math.min(min, ohlc ? row[2] : row[0]);
    }
    const alpha = Math.log(1 + Number(g.targetPeakGrowthPercent) / 100) / (max / HISTORICAL_GROWTH_LIMITS.logScale);
    if (!(alpha > 0) || !Number.isFinite(alpha) || Number(initialPrice) * Math.exp(alpha * min / HISTORICAL_GROWTH_LIMITS.logScale) < 1e-8)
      throw new RangeError("\u0418\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u043E\u0435 \u043E\u043A\u043D\u043E \u0432\u044B\u0445\u043E\u0434\u0438\u0442 \u0437\u0430 \u0442\u043E\u0447\u043D\u043E\u0441\u0442\u044C \u0430\u043A\u0442\u0438\u0432\u0430");
  }
  function validateScenarioControls(program, initialPrice) {
    if (program.terminalPeak && (program.afterGrowth !== "range" || program.growth || program.historical || !["WAVES", "DEEP_RECOVERY", "COMPRESSION_BREAKOUT"].includes(program.scenario) || !["growth", "recovery"].includes(program.stages[program.stages.length - 1]?.type ?? "") || units(program.stages[program.stages.length - 1]?.targetPrice ?? "0") !== units(program.maxPrice)))
      throw new RangeError("Terminal peak requires a final growth/recovery at the cap and bounded continuation");
    if (program.growth !== void 0 || program.historicalGrowth !== void 0) {
      validateHistoricalWindowControls(program, initialPrice);
      return;
    }
    const initial = units(initialPrice), cap = units(program.maxPrice), first = units(exactPriceFromGain(initialPrice, program.first24hGainPercent));
    for (const value of [initialPrice, program.maxPrice, ...program.stages.map((stage) => stage.targetPrice)]) {
      const canonical = normalizeScenarioDecimal(value);
      if (Number(value) < 1e-8 || Number(value) > 1e9 || normalizeScenarioDecimal(Number(value).toFixed(10)) !== canonical) {
        throw new RangeError("\u0426\u0435\u043D\u0430 \u043D\u0435 \u043F\u043E\u043C\u0435\u0449\u0430\u0435\u0442\u0441\u044F \u0432 \u0442\u043E\u0447\u043D\u043E\u0441\u0442\u044C \u0430\u043A\u0442\u0438\u0432\u0430: \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u044F \u043E\u0442 0,00000001 \u0434\u043E 1000000000 \u0441 \u043C\u0435\u043D\u044C\u0448\u0438\u043C \u0447\u0438\u0441\u043B\u043E\u043C \u0437\u043D\u0430\u043A\u043E\u0432");
      }
    }
    if (initial <= 0n || cap <= initial) throw new RangeError("\u041C\u0430\u043A\u0441\u0438\u043C\u0430\u043B\u044C\u043D\u0430\u044F \u0446\u0435\u043D\u0430 \u0434\u043E\u043B\u0436\u043D\u0430 \u0431\u044B\u0442\u044C \u0432\u044B\u0448\u0435 \u043D\u0430\u0447\u0430\u043B\u044C\u043D\u043E\u0439 \u0446\u0435\u043D\u044B");
    if (first >= cap) throw new RangeError("\u0426\u0435\u043B\u044C \u0437\u0430 \u043F\u0435\u0440\u0432\u044B\u0435 \u0441\u0443\u0442\u043A\u0438 \u0432\u044B\u0448\u0435 \u043C\u0430\u043A\u0441\u0438\u043C\u0430\u043B\u044C\u043D\u043E\u0439 \u0446\u0435\u043D\u044B");
    if (Number(program.first24hGainPercent) <= 0 || Number(program.first24hGainPercent) > 1e5) throw new RangeError("\u0420\u043E\u0441\u0442 \u0437\u0430 \u043F\u0435\u0440\u0432\u044B\u0435 \u0441\u0443\u0442\u043A\u0438 \u0434\u043E\u043B\u0436\u0435\u043D \u0431\u044B\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435 \u043D\u0443\u043B\u044F \u0438 \u043D\u0435 \u0432\u044B\u0448\u0435 100000%");
    if (units(program.pullbacks.minDepthPercent) > units(program.pullbacks.maxDepthPercent)) throw new RangeError("\u041C\u0438\u043D\u0438\u043C\u0430\u043B\u044C\u043D\u0430\u044F \u0433\u043B\u0443\u0431\u0438\u043D\u0430 \u043E\u0442\u043A\u0430\u0442\u0430 \u043D\u0435 \u043C\u043E\u0436\u0435\u0442 \u0431\u044B\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435 \u043C\u0430\u043A\u0441\u0438\u043C\u0430\u043B\u044C\u043D\u043E\u0439");
    let elapsed = 0, previous = initial, foundDayOne = false;
    for (const [index, stage] of program.stages.entries()) {
      elapsed += stage.durationHours;
      const target = units(stage.targetPrice);
      const terminal = program.terminalPeak === "bounded-v1" && index === program.stages.length - 1 && target === cap;
      if (!terminal && (target <= 0n || target > cap * 97n / 100n || target + 2n >= cap)) throw new RangeError("\u0426\u0435\u043B\u044C \u044D\u0442\u0430\u043F\u0430 \u0434\u043E\u043B\u0436\u043D\u0430 \u043E\u0441\u0442\u0430\u0432\u043B\u044F\u0442\u044C \u043D\u0435 \u043C\u0435\u043D\u0435\u0435 3% \u0434\u043E \u043C\u0430\u043A\u0441\u0438\u043C\u0430\u043B\u044C\u043D\u043E\u0439 \u0446\u0435\u043D\u044B \u0434\u043B\u044F \u043A\u043E\u043B\u0435\u0431\u0430\u043D\u0438\u0439 \u0438 \u0442\u0435\u043D\u0435\u0439");
      if ((stage.type === "growth" || stage.type === "recovery") && target <= previous) throw new RangeError("\u0426\u0435\u043D\u0430 \u0432 \u043A\u043E\u043D\u0446\u0435 \u0440\u043E\u0441\u0442\u0430 \u0438\u043B\u0438 \u0432\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u0438\u044F \u0434\u043E\u043B\u0436\u043D\u0430 \u0431\u044B\u0442\u044C \u0432\u044B\u0448\u0435 \u0446\u0435\u043D\u044B \u0432 \u043D\u0430\u0447\u0430\u043B\u0435 \u044D\u0442\u0430\u043F\u0430");
      if (stage.type === "range" && target !== previous) throw new RangeError("\u0414\u043B\u044F \u0431\u043E\u043A\u043E\u0432\u0438\u043A\u0430 \u0446\u0435\u043D\u0430 \u0432 \u043D\u0430\u0447\u0430\u043B\u0435 \u0438 \u043A\u043E\u043D\u0446\u0435 \u044D\u0442\u0430\u043F\u0430 \u0434\u043E\u043B\u0436\u043D\u0430 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0442\u044C");
      if (stage.type === "pullback" && target >= previous) throw new RangeError("\u0426\u0435\u043D\u0430 \u0432 \u043A\u043E\u043D\u0446\u0435 \u043E\u0442\u043A\u0430\u0442\u0430 \u0434\u043E\u043B\u0436\u043D\u0430 \u0431\u044B\u0442\u044C \u043D\u0438\u0436\u0435 \u0446\u0435\u043D\u044B \u0432 \u043D\u0430\u0447\u0430\u043B\u0435 \u044D\u0442\u0430\u043F\u0430");
      if (elapsed === 24) {
        foundDayOne = true;
        if (target !== first) throw new RangeError("\u0426\u0435\u043B\u044C \u044D\u0442\u0430\u043F\u0430 \u0432 \u043A\u043E\u043D\u0446\u0435 \u043F\u0435\u0440\u0432\u044B\u0445 \u0441\u0443\u0442\u043E\u043A \u043D\u0435 \u0441\u043E\u0432\u043F\u0430\u0434\u0430\u0435\u0442 \u0441 \u0440\u043E\u0441\u0442\u043E\u043C \u0437\u0430 \u043F\u0435\u0440\u0432\u044B\u0435 24 \u0447\u0430\u0441\u0430");
      }
      previous = target;
    }
    if (!foundDayOne) throw new RangeError("\u041E\u0434\u0438\u043D \u0438\u0437 \u044D\u0442\u0430\u043F\u043E\u0432 \u0434\u043E\u043B\u0436\u0435\u043D \u0437\u0430\u043A\u0430\u043D\u0447\u0438\u0432\u0430\u0442\u044C\u0441\u044F \u0440\u043E\u0432\u043D\u043E \u0447\u0435\u0440\u0435\u0437 24 \u0447\u0430\u0441\u0430 \u0441 \u0446\u0435\u043B\u044C\u044E \u043F\u0435\u0440\u0432\u044B\u0445 \u0441\u0443\u0442\u043E\u043A");
    if (elapsed < 24 || elapsed > 720) throw new RangeError("\u041E\u0431\u0449\u0430\u044F \u043F\u0440\u043E\u0434\u043E\u043B\u0436\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0440\u043E\u0441\u0442\u0430 \u0434\u043E\u043B\u0436\u043D\u0430 \u0431\u044B\u0442\u044C \u043E\u0442 24 \u0434\u043E 720 \u0447\u0430\u0441\u043E\u0432");
    if (program.afterGrowth === "historical") {
      if (!program.historical) throw new RangeError("\u0414\u043B\u044F \u0438\u0441\u0442\u043E\u0440\u0438\u0438 \u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u0435 CSV \u0441 \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u044B\u043C\u0438 \u0447\u0430\u0441\u043E\u0432\u044B\u043C\u0438 \u0441\u0432\u0435\u0447\u0430\u043C\u0438");
      validateHistoricalMoveProgram(program.historical);
      if (program.stages[program.stages.length - 1]?.type !== "pullback")
        throw new RangeError("\u041F\u0435\u0440\u0435\u0434 \u0438\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u0438\u043C \u0441\u0446\u0435\u043D\u0430\u0440\u0438\u0435\u043C \u043D\u0435\u043E\u0431\u0445\u043E\u0434\u0438\u043C \u0437\u0430\u043A\u043B\u044E\u0447\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0439 \u044D\u0442\u0430\u043F \u043F\u0430\u0434\u0435\u043D\u0438\u044F");
      const bounds = historicalReplayBounds(program.historical, Number(program.stages[program.stages.length - 1].targetPrice));
      if (bounds.max >= Number(program.maxPrice) * 0.995)
        throw new RangeError("\u0418\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u0438\u0439 \u043E\u0442\u0440\u0435\u0437\u043E\u043A \u043F\u0440\u0435\u0432\u044B\u0448\u0430\u0435\u0442 \u043E\u0431\u0449\u0438\u0439 \u043B\u0438\u043C\u0438\u0442 \u0446\u0435\u043D\u044B: \u0432\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0434\u0440\u0443\u0433\u043E\u0439 \u0444\u0440\u0430\u0433\u043C\u0435\u043D\u0442");
      if (bounds.min < 1e-8)
        throw new RangeError("\u0418\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u043E\u0435 \u0434\u0432\u0438\u0436\u0435\u043D\u0438\u0435 \u0432\u044B\u0445\u043E\u0434\u0438\u0442 \u0437\u0430 \u0442\u043E\u0447\u043D\u043E\u0441\u0442\u044C \u0430\u043A\u0442\u0438\u0432\u0430");
    } else if (program.historical) {
      throw new RangeError("\u0418\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u0441\u0432\u0435\u0447\u0438 \u0434\u043E\u043B\u0436\u043D\u044B \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u0442\u044C\u0441\u044F \u0442\u043E\u043B\u044C\u043A\u043E \u0432 \u0438\u0441\u0442\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u043E\u043C \u0440\u0435\u0436\u0438\u043C\u0435");
    }
  }
  return __toCommonJS(listingScenarioControls_exports);
})();

"use strict";
var AiListingSchedule = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // src/shared/listingSchedule.ts
  var listingSchedule_exports = {};
  __export(listingSchedule_exports, {
    shiftListingDate: () => shiftListingDate,
    utcToZonedWallTime: () => utcToZonedWallTime,
    zoneOffsetMs: () => zoneOffsetMs,
    zonedWallTimeToUtc: () => zonedWallTimeToUtc
  });
  function zoneOffsetMs(instant, timeZone) {
    const parts = Object.fromEntries(new Intl.DateTimeFormat("en-US", {
      timeZone,
      hourCycle: "h23",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit"
    }).formatToParts(new Date(instant)).map((p) => [p.type, p.value]));
    return Date.UTC(+parts.year, +parts.month - 1, +parts.day, +parts.hour, +parts.minute, +parts.second) - Math.floor(instant / 1e3) * 1e3;
  }
  function utcToZonedWallTime(iso, timeZone) {
    const instant = Date.parse(iso);
    return Number.isFinite(instant) ? new Date(instant + zoneOffsetMs(instant, timeZone)).toISOString().slice(0, 16) : "";
  }
  function zonedWallTimeToUtc(wall, timeZone) {
    const m = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})$/.exec(wall);
    if (!m) return null;
    const guess = Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5]);
    if (!Number.isFinite(guess) || new Date(guess).toISOString().slice(0, 16) !== wall) return null;
    try {
      const offsets = /* @__PURE__ */ new Set();
      for (let h = -48; h <= 48; h += 6) offsets.add(zoneOffsetMs(guess + h * 36e5, timeZone));
      const candidates = [...offsets].map((offset) => guess - offset).filter((at) => utcToZonedWallTime(new Date(at).toISOString(), timeZone) === wall);
      return candidates.length === 1 ? new Date(candidates[0]).toISOString().replace(".000Z", "Z") : null;
    } catch {
      return null;
    }
  }
  function shiftListingDate(iso, zone, days) {
    if (![1, 2, 3].includes(days) || !Number.isFinite(Date.parse(iso))) return null;
    try {
      const wall = utcToZonedWallTime(iso, zone);
      const date = /* @__PURE__ */ new Date(wall + ":00Z");
      date.setUTCDate(date.getUTCDate() + days);
      const next = zonedWallTimeToUtc(date.toISOString().slice(0, 16), zone);
      if (!next) return null;
      const remainder = (Date.parse(iso) % 6e4 + 6e4) % 6e4;
      return new Date(Date.parse(next) + remainder).toISOString().replace(".000Z", "Z");
    } catch {
      return null;
    }
  }
  return __toCommonJS(listingSchedule_exports);
})();

function validateScenarioControls(program, initialPrice){return program.terminalPeak==='bounded-v1'?AiListingScenarioControls.validateScenarioControls(program,initialPrice):legacyValidateScenarioControls(program,initialPrice);}
